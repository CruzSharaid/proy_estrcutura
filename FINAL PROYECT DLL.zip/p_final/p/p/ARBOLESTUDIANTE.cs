﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p
{
    class Arbol_ESTUDIANTE
    {
        NodoArbol_ESTUDIANTE raiz, nuevo;

        public Arbol_ESTUDIANTE()
        {
            raiz = null;
            nuevo = null;
        }

        public void crear_nodo(string codigo_est, string nombre_est, string apat_est, string amat_est, int ci_est, string correo_est, string cod_sem, string cod_carr)
        {
            nuevo = new NodoArbol_ESTUDIANTE(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr, null, null);
            nuevo.enl_der = null;
            nuevo.enl_izq = null;
        }

        public void insertar_nodo(string codigo_est, string nombre_est, string apat_est, string amat_est, int ci_est, string correo_est, string cod_sem, string cod_carr, NodoArbol_ESTUDIANTE punt)
        {
            if (string.Compare(codigo_est, punt.codigo_est) < 0)
            {
                if (punt.enl_izq == null)
                {
                    crear_nodo(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr);
                    punt.enl_izq = nuevo;
                }
                else
                {
                    insertar_nodo(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr, punt.enl_izq);
                }
            }
            else
            {
                if (punt.enl_der == null)
                {
                    crear_nodo(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr);
                    punt.enl_der = nuevo;
                }
                else
                {
                    insertar_nodo(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr, punt.enl_der);
                }
            }
        }

        public void insertar_arbol(string codigo_est, string nombre_est, string apat_est, string amat_est, int ci_est, string correo_est, string cod_sem, string cod_carr)
        {
            if (raiz == null)
            {
                crear_nodo(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr);
                raiz = nuevo;
            }
            else
            {
                NodoArbol_ESTUDIANTE punt;
                punt = raiz;
                insertar_nodo(codigo_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr, punt);
            }
        }

        public NodoArbol_ESTUDIANTE devolver_raíz()
        {
            return raiz;
        }

        public void Llenar(DataGridView dgv, NodoArbol_ESTUDIANTE nodo)
        {
            if (nodo != null)
            {

                Llenar(dgv, nodo.enl_izq);
                dgv.Rows.Add(nodo.codigo_est, nodo.nombre_est, nodo.apat_est, nodo.amat_est, nodo.ci_est, nodo.correo_est, nodo.cod_sem, nodo.cod_carr);
                Llenar(dgv, nodo.enl_der);
            }
        }


        public bool Modificar_EST(int ci_est, string nuevoNombre, string nuevoApat, string nuevoAmat, string nuevoCorreo, string nuevoCodSem, string nuevoCodCarr)
        {

            NodoArbol_ESTUDIANTE nodo = Buscar_EST_CI(ci_est, raiz);

            if (nodo != null)
            {
                // Actualizar los datos del nodo
                nodo.nombre_est = nuevoNombre;
                nodo.apat_est = nuevoApat;
                nodo.amat_est = nuevoAmat;
                nodo.correo_est = nuevoCorreo;
                nodo.cod_sem = nuevoCodSem;
                nodo.cod_carr = nuevoCodCarr;

                return true; // Modificación exitosa
            }
            else
            {
                return false; // Nodo no encontrado
            }
        }
        public NodoArbol_ESTUDIANTE Buscar_EST_CI(int ci_est, NodoArbol_ESTUDIANTE punt)
        {
            if (punt == null)
            {
                return null; // No se encontró
            }

            if (punt.ci_est == ci_est)
            {
                return punt; // Nodo encontrado
            }

            if (ci_est < punt.ci_est)
            {
                // Buscar en el subárbol izquierdo
                return Buscar_EST_CI(ci_est, punt.enl_izq);
            }
            else
            {
                // Buscar en el subárbol derecho
                return Buscar_EST_CI(ci_est, punt.enl_der);
            }
        }

    }
}
