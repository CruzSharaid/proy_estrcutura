﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p
{
    public partial class FrmESTUDIANTE : Form
    {
        private string codigoEstudiante;
        public FrmESTUDIANTE(string codigoEstudiante)
        {
            InitializeComponent();
            this.codigoEstudiante = codigoEstudiante;
        }


        private void cERRARSESIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 opcion = new Form1();
            opcion.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmInformePrincipal opcion = new FrmInformePrincipal(codigoEstudiante);
            opcion.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmSOLICITUD_PERMISO opcion = new FrmSOLICITUD_PERMISO(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void btnCerrarSesionEstudiante_Click(object sender, EventArgs e)
        {
            Form1 opcion = new Form1();
            opcion.Show();
            this.Hide();
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }

        private void FrmESTUDIANTE_Load(object sender, EventArgs e)
        {

        }

        private void btnInforPerso_Click(object sender, EventArgs e)
        {
            FrmInformePrincipal opcion = new FrmInformePrincipal(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void btnSoliciPermiso_Click(object sender, EventArgs e)
        {
            FrmSOLICITUD_PERMISO opcion = new FrmSOLICITUD_PERMISO(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }
    }
}
