﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    internal class NodoArbol_ESTUDIANTE
    {
        string Codigo_est;
        string Nombre_est;
        string Apat_est;
        string Amat_est;
        int CI_est;
        string Correo_est;
        string Cod_sem;
        string Cod_carr;
        NodoArbol_ESTUDIANTE Enl_izq;
        NodoArbol_ESTUDIANTE Enl_der;

        public NodoArbol_ESTUDIANTE(string codigo_est, string nombre_est, string apat_est, string amat_est, int cI_est, string correo_est, string cod_sem, string cod_carr, NodoArbol_ESTUDIANTE enl_izq, NodoArbol_ESTUDIANTE enl_der)
        {
            Codigo_est = codigo_est;
            Nombre_est = nombre_est;
            Apat_est = apat_est;
            Amat_est = amat_est;
            CI_est = cI_est;
            Correo_est = correo_est;
            Cod_sem = cod_sem;
            Cod_carr = cod_carr;
            Enl_izq = enl_izq;
            Enl_der = enl_der;
        }

        public string codigo_est { get => Codigo_est; set => Codigo_est = value; }
        public string nombre_est { get => Nombre_est; set => Nombre_est = value; }
        public string apat_est { get => Apat_est; set => Apat_est = value; }
        public string amat_est { get => Amat_est; set => Amat_est = value; }
        public int ci_est { get => CI_est; set => CI_est = value; }
        public string correo_est { get => Correo_est; set => Correo_est = value; }
        public string cod_sem { get => Cod_sem; set => Cod_sem = value; }
        public string cod_carr { get => Cod_carr; set => Cod_carr = value; }
        internal NodoArbol_ESTUDIANTE enl_izq { get => Enl_izq; set => Enl_izq = value; }
        internal NodoArbol_ESTUDIANTE enl_der { get => Enl_der; set => Enl_der = value; }
    }
}