﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    class Cola_JEFATURA
    {
        NodoCola_Jefatura Frente, Final, nuevo;

        public Cola_JEFATURA()
        {
            Frente = null;
            Final = null;
            nuevo = null;
        }

        public void CrearNodo(int cod_jef, string nombre_jef, string cargo_jef, int cod_carr, int cod_usuario)
        {
            nuevo = new NodoCola_Jefatura(cod_jef, nombre_jef, cargo_jef, cod_carr, cod_usuario, null);
        }

        public void Encolar(int cod_jef, string nombre_jef, string cargo_jef, int cod_carr, int cod_usuario)
        {
            CrearNodo(cod_jef, nombre_jef, cargo_jef, cod_carr, cod_usuario);

            if (Frente == null)
            {
                Frente = nuevo;
                Final = nuevo;
            }
            else
            {
                Final.enl = nuevo;
                Final = nuevo;
            }
        }

        public NodoCola_Jefatura Desencolar()
        {
            if (Frente != null)
            {
                NodoCola_Jefatura temp = Frente;
                Frente = Frente.enl;
                if (Frente == null)
                {
                    Final = null;
                }
                return temp;
            }
            else
            {
                return null;
            }
        }

        public bool ColaVacia()
        {
            return Frente == null;
        }

        public NodoCola_Jefatura DevolverFrente()
        {
            return Frente;
        }
    }
}