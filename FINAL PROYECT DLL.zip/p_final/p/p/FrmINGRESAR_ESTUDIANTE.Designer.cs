﻿namespace p
{
    partial class FrmINGRESAR_ESTUDIANTE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmINGRESAR_ESTUDIANTE));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvNUEVOESTUDIANTE = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.txtApat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAmat = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbSem = new System.Windows.Forms.ComboBox();
            this.cmbCarrera = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.btnVolver = new System.Windows.Forms.PictureBox();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.btnMOSTRAR = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnMODIFICAR = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnELIMINAR = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnINGRESAR = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUEVOESTUDIANTE)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnVolver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(17, 234);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(209, 23);
            this.label16.TabIndex = 44;
            this.label16.Text = "Correo Institucional:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(17, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 23);
            this.label6.TabIndex = 36;
            this.label6.Text = "CI:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(17, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(191, 23);
            this.label2.TabIndex = 32;
            this.label2.Text = "Nombre Completo:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(214, 54);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(354, 20);
            this.txtNombre.TabIndex = 45;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(232, 234);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(336, 20);
            this.txtCorreo.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 19);
            this.label1.TabIndex = 55;
            this.label1.Text = "INGRESAR UN NUEVO ESTUDIANTE";
            // 
            // dgvNUEVOESTUDIANTE
            // 
            this.dgvNUEVOESTUDIANTE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUEVOESTUDIANTE.Location = new System.Drawing.Point(12, 321);
            this.dgvNUEVOESTUDIANTE.Name = "dgvNUEVOESTUDIANTE";
            this.dgvNUEVOESTUDIANTE.Size = new System.Drawing.Size(948, 274);
            this.dgvNUEVOESTUDIANTE.TabIndex = 57;
            this.dgvNUEVOESTUDIANTE.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUEVOESTUDIANTE_CellClick_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(17, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 23);
            this.label3.TabIndex = 58;
            this.label3.Text = "Apellido Paterno:";
            // 
            // txtApat
            // 
            this.txtApat.Location = new System.Drawing.Point(214, 94);
            this.txtApat.Name = "txtApat";
            this.txtApat.Size = new System.Drawing.Size(354, 20);
            this.txtApat.TabIndex = 59;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(17, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 23);
            this.label4.TabIndex = 60;
            this.label4.Text = "Apellido Materno:";
            // 
            // txtAmat
            // 
            this.txtAmat.Location = new System.Drawing.Point(214, 131);
            this.txtAmat.Name = "txtAmat";
            this.txtAmat.Size = new System.Drawing.Size(354, 20);
            this.txtAmat.TabIndex = 61;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(17, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 23);
            this.label5.TabIndex = 62;
            this.label5.Text = "Semestre:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(300, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 23);
            this.label7.TabIndex = 63;
            this.label7.Text = "Carrera:";
            // 
            // cmbSem
            // 
            this.cmbSem.FormattingEnabled = true;
            this.cmbSem.Location = new System.Drawing.Point(138, 161);
            this.cmbSem.Name = "cmbSem";
            this.cmbSem.Size = new System.Drawing.Size(156, 21);
            this.cmbSem.TabIndex = 64;
            // 
            // cmbCarrera
            // 
            this.cmbCarrera.FormattingEnabled = true;
            this.cmbCarrera.Location = new System.Drawing.Point(393, 163);
            this.cmbCarrera.Name = "cmbCarrera";
            this.cmbCarrera.Size = new System.Drawing.Size(175, 21);
            this.cmbCarrera.TabIndex = 65;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(278, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 23);
            this.label8.TabIndex = 67;
            this.label8.Text = "CODIGO:";
            // 
            // txtCod
            // 
            this.txtCod.Location = new System.Drawing.Point(393, 201);
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(175, 20);
            this.txtCod.TabIndex = 68;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.label9);
            this.bunifuGradientPanel1.Controls.Add(this.txtFiltro);
            this.bunifuGradientPanel1.Controls.Add(this.txtCI);
            this.bunifuGradientPanel1.Controls.Add(this.btnVolver);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.btnMOSTRAR);
            this.bunifuGradientPanel1.Controls.Add(this.btnMODIFICAR);
            this.bunifuGradientPanel1.Controls.Add(this.btnELIMINAR);
            this.bunifuGradientPanel1.Controls.Add(this.btnINGRESAR);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.dgvNUEVOESTUDIANTE);
            this.bunifuGradientPanel1.Controls.Add(this.txtCod);
            this.bunifuGradientPanel1.Controls.Add(this.label8);
            this.bunifuGradientPanel1.Controls.Add(this.txtCorreo);
            this.bunifuGradientPanel1.Controls.Add(this.label2);
            this.bunifuGradientPanel1.Controls.Add(this.cmbCarrera);
            this.bunifuGradientPanel1.Controls.Add(this.label3);
            this.bunifuGradientPanel1.Controls.Add(this.label7);
            this.bunifuGradientPanel1.Controls.Add(this.cmbSem);
            this.bunifuGradientPanel1.Controls.Add(this.txtAmat);
            this.bunifuGradientPanel1.Controls.Add(this.label4);
            this.bunifuGradientPanel1.Controls.Add(this.txtApat);
            this.bunifuGradientPanel1.Controls.Add(this.label5);
            this.bunifuGradientPanel1.Controls.Add(this.label6);
            this.bunifuGradientPanel1.Controls.Add(this.label16);
            this.bunifuGradientPanel1.Controls.Add(this.txtNombre);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Yellow;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(967, 607);
            this.bunifuGradientPanel1.TabIndex = 69;
            this.bunifuGradientPanel1.Click += new System.EventHandler(this.bunifuGradientPanel1_Click);
            // 
            // txtCI
            // 
            this.txtCI.Location = new System.Drawing.Point(62, 198);
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(175, 20);
            this.txtCI.TabIndex = 75;
            // 
            // btnVolver
            // 
            this.btnVolver.Image = ((System.Drawing.Image)(resources.GetObject("btnVolver.Image")));
            this.btnVolver.Location = new System.Drawing.Point(919, 0);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(48, 36);
            this.btnVolver.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnVolver.TabIndex = 74;
            this.btnVolver.TabStop = false;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click_1);
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.AutoSizeHeight = true;
            this.bunifuPictureBox1.BorderRadius = 105;
            this.bunifuPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuPictureBox1.Image")));
            this.bunifuPictureBox1.IsCircle = true;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(588, 54);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(211, 211);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 73;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            // 
            // btnMOSTRAR
            // 
            this.btnMOSTRAR.AllowAnimations = true;
            this.btnMOSTRAR.AllowMouseEffects = true;
            this.btnMOSTRAR.AllowToggling = false;
            this.btnMOSTRAR.AnimationSpeed = 200;
            this.btnMOSTRAR.AutoGenerateColors = false;
            this.btnMOSTRAR.AutoRoundBorders = true;
            this.btnMOSTRAR.AutoSizeLeftIcon = true;
            this.btnMOSTRAR.AutoSizeRightIcon = true;
            this.btnMOSTRAR.BackColor = System.Drawing.Color.Transparent;
            this.btnMOSTRAR.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMOSTRAR.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMOSTRAR.BackgroundImage")));
            this.btnMOSTRAR.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMOSTRAR.ButtonText = "CANCELAR";
            this.btnMOSTRAR.ButtonTextMarginLeft = 0;
            this.btnMOSTRAR.ColorContrastOnClick = 45;
            this.btnMOSTRAR.ColorContrastOnHover = 45;
            this.btnMOSTRAR.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnMOSTRAR.CustomizableEdges = borderEdges1;
            this.btnMOSTRAR.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnMOSTRAR.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnMOSTRAR.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnMOSTRAR.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnMOSTRAR.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnMOSTRAR.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnMOSTRAR.ForeColor = System.Drawing.Color.White;
            this.btnMOSTRAR.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMOSTRAR.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnMOSTRAR.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnMOSTRAR.IconMarginLeft = 11;
            this.btnMOSTRAR.IconPadding = 10;
            this.btnMOSTRAR.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMOSTRAR.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnMOSTRAR.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnMOSTRAR.IconSize = 25;
            this.btnMOSTRAR.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnMOSTRAR.IdleBorderRadius = 53;
            this.btnMOSTRAR.IdleBorderThickness = 1;
            this.btnMOSTRAR.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMOSTRAR.IdleIconLeftImage = null;
            this.btnMOSTRAR.IdleIconRightImage = null;
            this.btnMOSTRAR.IndicateFocus = false;
            this.btnMOSTRAR.Location = new System.Drawing.Point(820, 249);
            this.btnMOSTRAR.Name = "btnMOSTRAR";
            this.btnMOSTRAR.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnMOSTRAR.OnDisabledState.BorderRadius = 1;
            this.btnMOSTRAR.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMOSTRAR.OnDisabledState.BorderThickness = 1;
            this.btnMOSTRAR.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnMOSTRAR.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnMOSTRAR.OnDisabledState.IconLeftImage = null;
            this.btnMOSTRAR.OnDisabledState.IconRightImage = null;
            this.btnMOSTRAR.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnMOSTRAR.onHoverState.BorderRadius = 1;
            this.btnMOSTRAR.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMOSTRAR.onHoverState.BorderThickness = 1;
            this.btnMOSTRAR.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnMOSTRAR.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnMOSTRAR.onHoverState.IconLeftImage = null;
            this.btnMOSTRAR.onHoverState.IconRightImage = null;
            this.btnMOSTRAR.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnMOSTRAR.OnIdleState.BorderRadius = 1;
            this.btnMOSTRAR.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMOSTRAR.OnIdleState.BorderThickness = 1;
            this.btnMOSTRAR.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMOSTRAR.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnMOSTRAR.OnIdleState.IconLeftImage = null;
            this.btnMOSTRAR.OnIdleState.IconRightImage = null;
            this.btnMOSTRAR.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnMOSTRAR.OnPressedState.BorderRadius = 1;
            this.btnMOSTRAR.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMOSTRAR.OnPressedState.BorderThickness = 1;
            this.btnMOSTRAR.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnMOSTRAR.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnMOSTRAR.OnPressedState.IconLeftImage = null;
            this.btnMOSTRAR.OnPressedState.IconRightImage = null;
            this.btnMOSTRAR.Size = new System.Drawing.Size(140, 55);
            this.btnMOSTRAR.TabIndex = 72;
            this.btnMOSTRAR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMOSTRAR.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMOSTRAR.TextMarginLeft = 0;
            this.btnMOSTRAR.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnMOSTRAR.UseDefaultRadiusAndThickness = true;
            this.btnMOSTRAR.Click += new System.EventHandler(this.bunifuButton4_Click);
            // 
            // btnMODIFICAR
            // 
            this.btnMODIFICAR.AllowAnimations = true;
            this.btnMODIFICAR.AllowMouseEffects = true;
            this.btnMODIFICAR.AllowToggling = false;
            this.btnMODIFICAR.AnimationSpeed = 200;
            this.btnMODIFICAR.AutoGenerateColors = false;
            this.btnMODIFICAR.AutoRoundBorders = true;
            this.btnMODIFICAR.AutoSizeLeftIcon = true;
            this.btnMODIFICAR.AutoSizeRightIcon = true;
            this.btnMODIFICAR.BackColor = System.Drawing.Color.Transparent;
            this.btnMODIFICAR.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMODIFICAR.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMODIFICAR.BackgroundImage")));
            this.btnMODIFICAR.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMODIFICAR.ButtonText = "EDITAR";
            this.btnMODIFICAR.ButtonTextMarginLeft = 0;
            this.btnMODIFICAR.ColorContrastOnClick = 45;
            this.btnMODIFICAR.ColorContrastOnHover = 45;
            this.btnMODIFICAR.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnMODIFICAR.CustomizableEdges = borderEdges2;
            this.btnMODIFICAR.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnMODIFICAR.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnMODIFICAR.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnMODIFICAR.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnMODIFICAR.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnMODIFICAR.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnMODIFICAR.ForeColor = System.Drawing.Color.White;
            this.btnMODIFICAR.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMODIFICAR.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnMODIFICAR.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnMODIFICAR.IconMarginLeft = 11;
            this.btnMODIFICAR.IconPadding = 10;
            this.btnMODIFICAR.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMODIFICAR.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnMODIFICAR.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnMODIFICAR.IconSize = 25;
            this.btnMODIFICAR.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnMODIFICAR.IdleBorderRadius = 53;
            this.btnMODIFICAR.IdleBorderThickness = 1;
            this.btnMODIFICAR.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMODIFICAR.IdleIconLeftImage = null;
            this.btnMODIFICAR.IdleIconRightImage = null;
            this.btnMODIFICAR.IndicateFocus = false;
            this.btnMODIFICAR.Location = new System.Drawing.Point(820, 188);
            this.btnMODIFICAR.Name = "btnMODIFICAR";
            this.btnMODIFICAR.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnMODIFICAR.OnDisabledState.BorderRadius = 1;
            this.btnMODIFICAR.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMODIFICAR.OnDisabledState.BorderThickness = 1;
            this.btnMODIFICAR.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnMODIFICAR.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnMODIFICAR.OnDisabledState.IconLeftImage = null;
            this.btnMODIFICAR.OnDisabledState.IconRightImage = null;
            this.btnMODIFICAR.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnMODIFICAR.onHoverState.BorderRadius = 1;
            this.btnMODIFICAR.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMODIFICAR.onHoverState.BorderThickness = 1;
            this.btnMODIFICAR.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnMODIFICAR.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnMODIFICAR.onHoverState.IconLeftImage = null;
            this.btnMODIFICAR.onHoverState.IconRightImage = null;
            this.btnMODIFICAR.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnMODIFICAR.OnIdleState.BorderRadius = 1;
            this.btnMODIFICAR.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMODIFICAR.OnIdleState.BorderThickness = 1;
            this.btnMODIFICAR.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMODIFICAR.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnMODIFICAR.OnIdleState.IconLeftImage = null;
            this.btnMODIFICAR.OnIdleState.IconRightImage = null;
            this.btnMODIFICAR.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnMODIFICAR.OnPressedState.BorderRadius = 1;
            this.btnMODIFICAR.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnMODIFICAR.OnPressedState.BorderThickness = 1;
            this.btnMODIFICAR.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnMODIFICAR.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnMODIFICAR.OnPressedState.IconLeftImage = null;
            this.btnMODIFICAR.OnPressedState.IconRightImage = null;
            this.btnMODIFICAR.Size = new System.Drawing.Size(140, 55);
            this.btnMODIFICAR.TabIndex = 71;
            this.btnMODIFICAR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMODIFICAR.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMODIFICAR.TextMarginLeft = 0;
            this.btnMODIFICAR.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnMODIFICAR.UseDefaultRadiusAndThickness = true;
            this.btnMODIFICAR.Click += new System.EventHandler(this.btnMODIFICAR_Click_1);
            // 
            // btnELIMINAR
            // 
            this.btnELIMINAR.AllowAnimations = true;
            this.btnELIMINAR.AllowMouseEffects = true;
            this.btnELIMINAR.AllowToggling = false;
            this.btnELIMINAR.AnimationSpeed = 200;
            this.btnELIMINAR.AutoGenerateColors = false;
            this.btnELIMINAR.AutoRoundBorders = true;
            this.btnELIMINAR.AutoSizeLeftIcon = true;
            this.btnELIMINAR.AutoSizeRightIcon = true;
            this.btnELIMINAR.BackColor = System.Drawing.Color.Transparent;
            this.btnELIMINAR.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnELIMINAR.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnELIMINAR.BackgroundImage")));
            this.btnELIMINAR.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnELIMINAR.ButtonText = "ELIMINAR";
            this.btnELIMINAR.ButtonTextMarginLeft = 0;
            this.btnELIMINAR.ColorContrastOnClick = 45;
            this.btnELIMINAR.ColorContrastOnHover = 45;
            this.btnELIMINAR.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnELIMINAR.CustomizableEdges = borderEdges3;
            this.btnELIMINAR.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnELIMINAR.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnELIMINAR.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnELIMINAR.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnELIMINAR.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnELIMINAR.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnELIMINAR.ForeColor = System.Drawing.Color.White;
            this.btnELIMINAR.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnELIMINAR.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnELIMINAR.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnELIMINAR.IconMarginLeft = 11;
            this.btnELIMINAR.IconPadding = 10;
            this.btnELIMINAR.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnELIMINAR.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnELIMINAR.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnELIMINAR.IconSize = 25;
            this.btnELIMINAR.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnELIMINAR.IdleBorderRadius = 53;
            this.btnELIMINAR.IdleBorderThickness = 1;
            this.btnELIMINAR.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnELIMINAR.IdleIconLeftImage = null;
            this.btnELIMINAR.IdleIconRightImage = null;
            this.btnELIMINAR.IndicateFocus = false;
            this.btnELIMINAR.Location = new System.Drawing.Point(820, 127);
            this.btnELIMINAR.Name = "btnELIMINAR";
            this.btnELIMINAR.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnELIMINAR.OnDisabledState.BorderRadius = 1;
            this.btnELIMINAR.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnELIMINAR.OnDisabledState.BorderThickness = 1;
            this.btnELIMINAR.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnELIMINAR.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnELIMINAR.OnDisabledState.IconLeftImage = null;
            this.btnELIMINAR.OnDisabledState.IconRightImage = null;
            this.btnELIMINAR.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnELIMINAR.onHoverState.BorderRadius = 1;
            this.btnELIMINAR.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnELIMINAR.onHoverState.BorderThickness = 1;
            this.btnELIMINAR.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnELIMINAR.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnELIMINAR.onHoverState.IconLeftImage = null;
            this.btnELIMINAR.onHoverState.IconRightImage = null;
            this.btnELIMINAR.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnELIMINAR.OnIdleState.BorderRadius = 1;
            this.btnELIMINAR.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnELIMINAR.OnIdleState.BorderThickness = 1;
            this.btnELIMINAR.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnELIMINAR.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnELIMINAR.OnIdleState.IconLeftImage = null;
            this.btnELIMINAR.OnIdleState.IconRightImage = null;
            this.btnELIMINAR.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnELIMINAR.OnPressedState.BorderRadius = 1;
            this.btnELIMINAR.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnELIMINAR.OnPressedState.BorderThickness = 1;
            this.btnELIMINAR.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnELIMINAR.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnELIMINAR.OnPressedState.IconLeftImage = null;
            this.btnELIMINAR.OnPressedState.IconRightImage = null;
            this.btnELIMINAR.Size = new System.Drawing.Size(140, 55);
            this.btnELIMINAR.TabIndex = 70;
            this.btnELIMINAR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnELIMINAR.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnELIMINAR.TextMarginLeft = 0;
            this.btnELIMINAR.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnELIMINAR.UseDefaultRadiusAndThickness = true;
            this.btnELIMINAR.Click += new System.EventHandler(this.btnELIMINAR_Click);
            // 
            // btnINGRESAR
            // 
            this.btnINGRESAR.AllowAnimations = true;
            this.btnINGRESAR.AllowMouseEffects = true;
            this.btnINGRESAR.AllowToggling = false;
            this.btnINGRESAR.AnimationSpeed = 200;
            this.btnINGRESAR.AutoGenerateColors = false;
            this.btnINGRESAR.AutoRoundBorders = true;
            this.btnINGRESAR.AutoSizeLeftIcon = true;
            this.btnINGRESAR.AutoSizeRightIcon = true;
            this.btnINGRESAR.BackColor = System.Drawing.Color.Transparent;
            this.btnINGRESAR.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnINGRESAR.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnINGRESAR.BackgroundImage")));
            this.btnINGRESAR.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnINGRESAR.ButtonText = "REGISTRAR";
            this.btnINGRESAR.ButtonTextMarginLeft = 0;
            this.btnINGRESAR.ColorContrastOnClick = 45;
            this.btnINGRESAR.ColorContrastOnHover = 45;
            this.btnINGRESAR.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.btnINGRESAR.CustomizableEdges = borderEdges4;
            this.btnINGRESAR.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnINGRESAR.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnINGRESAR.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnINGRESAR.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnINGRESAR.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnINGRESAR.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnINGRESAR.ForeColor = System.Drawing.Color.White;
            this.btnINGRESAR.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnINGRESAR.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnINGRESAR.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnINGRESAR.IconMarginLeft = 11;
            this.btnINGRESAR.IconPadding = 10;
            this.btnINGRESAR.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnINGRESAR.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnINGRESAR.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnINGRESAR.IconSize = 25;
            this.btnINGRESAR.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnINGRESAR.IdleBorderRadius = 53;
            this.btnINGRESAR.IdleBorderThickness = 1;
            this.btnINGRESAR.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnINGRESAR.IdleIconLeftImage = null;
            this.btnINGRESAR.IdleIconRightImage = null;
            this.btnINGRESAR.IndicateFocus = false;
            this.btnINGRESAR.Location = new System.Drawing.Point(820, 66);
            this.btnINGRESAR.Name = "btnINGRESAR";
            this.btnINGRESAR.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnINGRESAR.OnDisabledState.BorderRadius = 1;
            this.btnINGRESAR.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnINGRESAR.OnDisabledState.BorderThickness = 1;
            this.btnINGRESAR.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnINGRESAR.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnINGRESAR.OnDisabledState.IconLeftImage = null;
            this.btnINGRESAR.OnDisabledState.IconRightImage = null;
            this.btnINGRESAR.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnINGRESAR.onHoverState.BorderRadius = 1;
            this.btnINGRESAR.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnINGRESAR.onHoverState.BorderThickness = 1;
            this.btnINGRESAR.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnINGRESAR.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnINGRESAR.onHoverState.IconLeftImage = null;
            this.btnINGRESAR.onHoverState.IconRightImage = null;
            this.btnINGRESAR.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnINGRESAR.OnIdleState.BorderRadius = 1;
            this.btnINGRESAR.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnINGRESAR.OnIdleState.BorderThickness = 1;
            this.btnINGRESAR.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnINGRESAR.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnINGRESAR.OnIdleState.IconLeftImage = null;
            this.btnINGRESAR.OnIdleState.IconRightImage = null;
            this.btnINGRESAR.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnINGRESAR.OnPressedState.BorderRadius = 1;
            this.btnINGRESAR.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnINGRESAR.OnPressedState.BorderThickness = 1;
            this.btnINGRESAR.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnINGRESAR.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnINGRESAR.OnPressedState.IconLeftImage = null;
            this.btnINGRESAR.OnPressedState.IconRightImage = null;
            this.btnINGRESAR.Size = new System.Drawing.Size(140, 55);
            this.btnINGRESAR.TabIndex = 69;
            this.btnINGRESAR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnINGRESAR.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnINGRESAR.TextMarginLeft = 0;
            this.btnINGRESAR.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnINGRESAR.UseDefaultRadiusAndThickness = true;
            this.btnINGRESAR.Click += new System.EventHandler(this.btnINGRESAR_Click_1);
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(232, 281);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(336, 20);
            this.txtFiltro.TabIndex = 76;
            this.txtFiltro.TextChanged += new System.EventHandler(this.txtFiltro_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(-1, 276);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(227, 23);
            this.label9.TabIndex = 77;
            this.label9.Text = "BUSCAR ESTUDIANTE:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // FrmINGRESAR_ESTUDIANTE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(967, 607);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmINGRESAR_ESTUDIANTE";
            this.Text = "REGISTRAR ESTUDIANTE";
            this.Load += new System.EventHandler(this.FrmINGRESAR_ESTUDIANTE_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUEVOESTUDIANTE)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnVolver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvNUEVOESTUDIANTE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtApat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAmat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbSem;
        private System.Windows.Forms.ComboBox cmbCarrera;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCod;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnMOSTRAR;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnMODIFICAR;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnELIMINAR;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnINGRESAR;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
        private System.Windows.Forms.PictureBox btnVolver;
        private System.Windows.Forms.TextBox txtCI;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtFiltro;
    }
}