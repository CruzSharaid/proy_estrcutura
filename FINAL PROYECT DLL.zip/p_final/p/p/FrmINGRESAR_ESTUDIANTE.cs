﻿using System;
using System.Collections.Generic;
using Npgsql; // Importar la librería Npgsql para conectarse a PostgreSQL
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bunifu.UI.WinForms.BunifuButton;

namespace p
{

    public partial class FrmINGRESAR_ESTUDIANTE : Form
    {
        private int codJef;
        // Cadena de conexión a la base de datos PostgreSQL
        string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";

        private NpgsqlConnection conexion = new NpgsqlConnection("Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA");
        private Arbol_ESTUDIANTE arbolEstudiantes = new Arbol_ESTUDIANTE();

        public FrmINGRESAR_ESTUDIANTE(int codJef)
        {
            InitializeComponent();
            txtFiltro.TextChanged += new EventHandler(txtFiltro_TextChanged);
            this.codJef = codJef;
        }

        private void FrmINGRESAR_ESTUDIANTE_Load(object sender, EventArgs e)
        {
            CargarCarreras();
            CargarSemestres();
            GenerarCodigoEstudiante();
            ActualizarTablaEstudiantes(); // Cargar los estudiantes al inicio
            dgvNUEVOESTUDIANTE.AllowUserToAddRows = false;
            txtCod.Enabled = false;
            txtCorreo.Enabled
                = false;
            // Suscribir eventos TextChanged
            txtNombre.TextChanged += GenerarCorreoAutomatico;
            txtApat.TextChanged += GenerarCorreoAutomatico;
            txtAmat.TextChanged += GenerarCorreoAutomatico;
        }
        private void GenerarCorreoAutomatico(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string apellidoPaterno = txtApat.Text.Trim();

            // Solo generar el correo si hay datos en nombre y apellido paterno
            if (!string.IsNullOrEmpty(nombre) && !string.IsNullOrEmpty(apellidoPaterno))
            {
                txtCorreo.Text = GenerarCorreo(nombre, apellidoPaterno);
            }
            else
            {
                txtCorreo.Clear();
            }
        }
        private void CargarCarreras()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT cod_carr, descrip_carr FROM carrera", conexion);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    cmbCarrera.Items.Add(new KeyValuePair<int, string>((int)reader["cod_carr"], reader["descrip_carr"].ToString()));
                }
                cmbCarrera.DisplayMember = "Value";
                cmbCarrera.ValueMember = "Key";
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar carreras: " + ex.Message);
            }
        }

        private void CargarSemestres()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT cod_sem, descrip_sem FROM semestre", conexion);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    cmbSem.Items.Add(new KeyValuePair<int, string>((int)reader["cod_sem"], reader["descrip_sem"].ToString()));
                }
                cmbSem.DisplayMember = "Value";
                cmbSem.ValueMember = "Key";
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar semestres: " + ex.Message);
            }
        }

        private void GenerarCodigoEstudiante()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                // Obtener el mayor valor del código registrado
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT MAX(cod_est) FROM estudiante", conexion);
                string ultimoCodigo = cmd.ExecuteScalar()?.ToString();
                conexion.Close();

                string nuevoCodigo;

                if (string.IsNullOrEmpty(ultimoCodigo))
                {
                    // Si no existe ningún código, se empieza desde C111001-1
                    nuevoCodigo = "C111001-1";
                }
                else
                {
                    // Dividir el código en dos partes: la parte antes y después del guion
                    string[] partes = ultimoCodigo.Split('-');
                    int numero = int.Parse(partes[0].Substring(1)) + 1;

                    // Obtener el dígito después del guion
                    int ultimoDigito = numero % 10;

                    // Generar el nuevo código con el mismo dígito después del guion
                    nuevoCodigo = "C" + numero.ToString("D6") + "-" + ultimoDigito;
                }

                // Asignar el nuevo código al campo de texto
                txtCod.Text = nuevoCodigo;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar el código de estudiante: " + ex.Message);
            }
        }


        private void btnINGRESAR_Click(object sender, EventArgs e)
        {

        }

        private string GenerarCorreo(string nombre, string apellidoPaterno)
        {
            return nombre[0].ToString().ToLower() + apellidoPaterno.ToLower() + "@emi.edu.bo";
        }

       

        private void ActualizarTablaEstudiantes()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }
                // Consulta que combina las tablas para mostrar las descripciones de carrera y semestre
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT cod_est AS \"CODIGO\", nombre_est AS \"NOMBRE\", apat_est AS \"APELLIDO PATERNO\", amat_est AS \"APELLIDO MATERNO\", ci_est AS \"C.I.\", correo_est AS \"CORREO\", (SELECT descrip_sem FROM semestre WHERE cod_sem = estudiante.cod_sem) AS \"SEMESTRE\", (SELECT descrip_carr FROM carrera WHERE cod_carr = estudiante.cod_carr) AS \"CARRERA\" FROM estudiante", conexion);
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvNUEVOESTUDIANTE.DataSource = dt;
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar la tabla de estudiantes: " + ex.Message);
            }
        }


        private void btnVolver_Click(object sender, EventArgs e)
        {
            FrmJEFATURA opcion = new FrmJEFATURA(codJef);
            opcion.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnMODIFICAR_Click(object sender, EventArgs e)
        {

        }

        private void btnMOSTRAR_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton4_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            GenerarCodigoEstudiante();

            // Habilitar los campos nuevamente
            txtCI.Enabled = true;
            cmbSem.Enabled = true;
            cmbCarrera.Enabled = true;
            txtCod.Enabled = false;
            txtCorreo.Enabled = true;

            // Configurar botones
            btnINGRESAR.Enabled = true;
            btnMODIFICAR.Enabled = false;
            btnELIMINAR.Enabled = false;
            btnMOSTRAR.Enabled = true;

        }

        private void btnVolver_Click_1(object sender, EventArgs e)
        {
            FrmJEFATURA opcion = new FrmJEFATURA(codJef);
            opcion.Show();
            this.Hide();
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        

        private void btnINGRESAR_Click_1(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string apellidoPaterno = txtApat.Text;
            string apellidoMaterno = txtAmat.Text;
            int ci;

            if (!int.TryParse(txtCI.Text, out ci))
            {
                MessageBox.Show("El CI debe ser un número entero.");
                return;
            }

            string codigoEstudiante = txtCod.Text;

            // Validar duplicados
            if (EstudianteYaRegistrado(codigoEstudiante, ci))
            {
                MessageBox.Show("El estudiante ya está registrado con el mismo CÓDIGO o CI.");
                return;
            }

            string correo = GenerarCorreo(nombre, apellidoPaterno);
            int semestreId = ((KeyValuePair<int, string>)cmbSem.SelectedItem).Key;
            int carreraId = ((KeyValuePair<int, string>)cmbCarrera.SelectedItem).Key;

            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                // Insertar en la tabla estudiante
                NpgsqlCommand cmdEstudiante = new NpgsqlCommand(@"
        INSERT INTO estudiante (
            cod_est, nombre_est, apat_est, amat_est, ci_est, correo_est, cod_sem, cod_carr
        ) VALUES (
            @cod_est, @nombre_est, @apat_est, @amat_est, @ci_est, @correo_est, @cod_sem, @cod_carr
        )", conexion);

                cmdEstudiante.Parameters.AddWithValue("@cod_est", codigoEstudiante);
                cmdEstudiante.Parameters.AddWithValue("@nombre_est", nombre);
                cmdEstudiante.Parameters.AddWithValue("@apat_est", apellidoPaterno);
                cmdEstudiante.Parameters.AddWithValue("@amat_est", apellidoMaterno);
                cmdEstudiante.Parameters.AddWithValue("@ci_est", ci);
                cmdEstudiante.Parameters.AddWithValue("@correo_est", correo);
                cmdEstudiante.Parameters.AddWithValue("@cod_sem", semestreId);
                cmdEstudiante.Parameters.AddWithValue("@cod_carr", carreraId);
                cmdEstudiante.ExecuteNonQuery();

                // Insertar en la tabla usuarios
                NpgsqlCommand cmdUsuario = new NpgsqlCommand(@"
        INSERT INTO usuarios (
            username, password, rol
        ) VALUES (
            @username, @password, @rol
        )", conexion);

                // Suponiendo que el username es el código del estudiante
                cmdUsuario.Parameters.AddWithValue("@username", codigoEstudiante);

                // Suponiendo que el password inicial será el CI del estudiante (deberías encriptarlo)
                cmdUsuario.Parameters.AddWithValue("@password", codigoEstudiante);

                // Asignar el rol correspondiente (e.g., "ESTUDIANTE")
                cmdUsuario.Parameters.AddWithValue("@rol", "ESTUDIANTE");

                cmdUsuario.ExecuteNonQuery();
                conexion.Close();

                MessageBox.Show("Estudiante y usuario registrados con éxito.");
                ActualizarTablaEstudiantes();
                LimpiarCampos();
                GenerarCodigoEstudiante();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar estudiante o usuario: " + ex.Message);
            }
        }
        private bool VerificarCamposVacios()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Por favor ingrese el nombre del estudiante.");
                txtNombre.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtApat.Text))
            {
                MessageBox.Show("Por favor ingrese el apellido paterno del estudiante.");
                txtApat.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtAmat.Text))
            {
                MessageBox.Show("Por favor ingrese el apellido materno del estudiante.");
                txtAmat.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtCI.Text))
            {
                MessageBox.Show("Por favor ingrese el CI del estudiante.");
                txtCI.Focus();
                return false;
            }
            if (cmbSem.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor seleccione el semestre.");
                cmbSem.Focus();
                return false;
            }
            if (cmbCarrera.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor seleccione la carrera.");
                cmbCarrera.Focus();
                return false;
            }
            return true; // Todos los campos están completos
        }

        private bool EstudianteYaRegistrado(string codigo, int ci)
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                NpgsqlCommand cmd = new NpgsqlCommand("SELECT COUNT(*) FROM estudiante WHERE cod_est = @codigo OR ci_est = @ci", conexion);
                cmd.Parameters.AddWithValue("@codigo", codigo);
                cmd.Parameters.AddWithValue("@ci", ci);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                conexion.Close();

                return count > 0; // Si hay registros, significa que ya existe
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar estudiante: " + ex.Message);
                return true; // Para evitar insertar duplicados si falla la validación
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtApat.Clear();
            txtAmat.Clear();
            txtCI.Clear();
            txtCorreo.Clear();
            cmbSem.SelectedIndex = -1;
            cmbCarrera.SelectedIndex = -1;
        }
        private void dgvNUEVOESTUDIANTE_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnMODIFICAR_Click_1(object sender, EventArgs e)
        {
            int ci;
            if (!int.TryParse(txtCI.Text, out ci))
            {
                MessageBox.Show("El CI debe ser un número entero.");
                return;
            }

            // Modificar en el árbol
            bool modificado = arbolEstudiantes.Modificar_EST(
                ci,
                txtNombre.Text,
                txtApat.Text,
                txtAmat.Text,
                txtCorreo.Text,
                cmbSem.Text,
                cmbCarrera.Text
            );

            if (modificado)
            {
                try
                {
                    if (conexion.State == ConnectionState.Closed)
                    {
                        conexion.Open();
                    }
                    NpgsqlCommand cmd = new NpgsqlCommand("UPDATE estudiante SET nombre_est = @nombre_est, apat_est = @apat_est, amat_est = @amat_est, ci_est = @ci_est, correo_est = @correo_est, cod_sem = @cod_sem, cod_carr = @cod_carr WHERE cod_est = @cod_est", conexion);
                    cmd.Parameters.AddWithValue("@cod_est", txtCod.Text);
                    cmd.Parameters.AddWithValue("@nombre_est", txtNombre.Text);
                    cmd.Parameters.AddWithValue("@apat_est", txtApat.Text);
                    cmd.Parameters.AddWithValue("@amat_est", txtAmat.Text);
                    cmd.Parameters.AddWithValue("@ci_est", ci);
                    cmd.Parameters.AddWithValue("@correo_est", txtCorreo.Text);
                    cmd.Parameters.AddWithValue("@cod_sem", ((KeyValuePair<int, string>)cmbSem.SelectedItem).Key);
                    cmd.Parameters.AddWithValue("@cod_carr", ((KeyValuePair<int, string>)cmbCarrera.SelectedItem).Key);
                    cmd.ExecuteNonQuery();
                    conexion.Close();

                    MessageBox.Show("Estudiante actualizado con éxito.");
                    ActualizarTablaEstudiantes();
                    LimpiarCampos();
                    GenerarCodigoEstudiante();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar estudiante: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Estudiante no encontrado en el árbol.");
            }
        }

        private void dgvNUEVOESTUDIANTE_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvNUEVOESTUDIANTE.Rows[e.RowIndex];
                txtCod.Text = row.Cells["CODIGO"].Value.ToString();
                txtNombre.Text = row.Cells["NOMBRE"].Value.ToString();
                txtApat.Text = row.Cells["APELLIDO PATERNO"].Value.ToString();
                txtAmat.Text = row.Cells["APELLIDO MATERNO"].Value.ToString();
                txtCI.Text = row.Cells["C.I."].Value.ToString();
                txtCorreo.Text = row.Cells["CORREO"].Value.ToString();

                // Seleccionar el semestre en el ComboBox
                string semestreDescripcion = row.Cells["SEMESTRE"].Value.ToString();
                foreach (KeyValuePair<int, string> item in cmbSem.Items)
                {
                    if (item.Value == semestreDescripcion)
                    {
                        cmbSem.SelectedItem = item;
                        break;
                    }
                }

                // Seleccionar la carrera en el ComboBox
                string carreraDescripcion = row.Cells["CARRERA"].Value.ToString();
                foreach (KeyValuePair<int, string> item in cmbCarrera.Items)
                {
                    if (item.Value == carreraDescripcion)
                    {
                        cmbCarrera.SelectedItem = item;
                        break;
                    }
                }

                // Deshabilitar campos
                txtCI.Enabled = false;
                cmbSem.Enabled = false;
                cmbCarrera.Enabled = false;
                txtCod.Enabled = false;
                txtCorreo.Enabled = false;

                // Configurar botones
                btnINGRESAR.Enabled = false;
                btnMODIFICAR.Enabled = true;
                btnELIMINAR.Enabled = true;
                btnMOSTRAR.Enabled = true;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            ActualizarTablaEstudiantes(txtFiltro.Text);
        }
        private void ActualizarTablaEstudiantes(string filtro = "")
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                // Base de la consulta
                string consulta = @"
        SELECT cod_est AS ""CODIGO"", 
               nombre_est AS ""NOMBRE"", 
               apat_est AS ""APELLIDO PATERNO"", 
               amat_est AS ""APELLIDO MATERNO"", 
               ci_est AS ""C.I."", 
               correo_est AS ""CORREO"", 
               (SELECT descrip_sem FROM semestre WHERE cod_sem = estudiante.cod_sem) AS ""SEMESTRE"", 
               (SELECT descrip_carr FROM carrera WHERE cod_carr = estudiante.cod_carr) AS ""CARRERA"" 
        FROM estudiante";

                // Agregar filtro si se proporciona
                if (!string.IsNullOrEmpty(filtro))
                {
                    consulta += " WHERE cod_est ILIKE @filtro OR nombre_est ILIKE @filtro OR apat_est ILIKE @filtro OR amat_est ILIKE @filtro";
                }

                NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);

                if (!string.IsNullOrEmpty(filtro))
                {
                    cmd.Parameters.AddWithValue("@filtro", "%" + filtro + "%");
                }

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvNUEVOESTUDIANTE.DataSource = dt;

                // Limpiar el árbol y llenarlo con los datos de los estudiantes
                arbolEstudiantes = new Arbol_ESTUDIANTE(); // Reiniciamos el árbol

                foreach (DataRow row in dt.Rows)
                {
                    // Insertar cada estudiante en el árbol
                    arbolEstudiantes.insertar_arbol(
                        row["CODIGO"].ToString(),
                        row["NOMBRE"].ToString(),
                        row["APELLIDO PATERNO"].ToString(),
                        row["APELLIDO MATERNO"].ToString(),
                        Convert.ToInt32(row["C.I."]),
                        row["CORREO"].ToString(),
                        row["SEMESTRE"].ToString(),
                        row["CARRERA"].ToString()
                    );
                }
                dgvNUEVOESTUDIANTE.DataSource = null; // Limpia datos antiguos
                dgvNUEVOESTUDIANTE.DataSource = dt;
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar la tabla de estudiantes: " + ex.Message);
            }
        }

        private void btnELIMINAR_Click(object sender, EventArgs e)
        {
    
                string codigoEstudiante = txtCod.Text;

                try
                {
                    if (conexion.State == ConnectionState.Closed)
                    {
                        conexion.Open();
                    }
                    NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM estudiante WHERE cod_est = @cod_est", conexion);
                    cmd.Parameters.AddWithValue("@cod_est", codigoEstudiante);
                    cmd.ExecuteNonQuery();
                    conexion.Close();

                    MessageBox.Show("Estudiante eliminado con éxito.");
                    ActualizarTablaEstudiantes();
                    LimpiarCampos();
                    GenerarCodigoEstudiante();  
                    btnINGRESAR.Enabled = true;
                    btnMODIFICAR.Enabled = false;
                    btnELIMINAR.Enabled = false;
                    btnMOSTRAR.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar estudiante: " + ex.Message);
                }
            
        }
    }
}