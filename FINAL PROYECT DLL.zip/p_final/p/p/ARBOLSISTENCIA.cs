﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    class Arbol_ASISTENCIA
    {
        NodoArbol_ASISTENCIA raiz, nuevo;

        public Arbol_ASISTENCIA()
        {
            raiz = null;
            nuevo = null;
        }

        public void crear_nodo(string id_asist, string cod_est, string cod_asig, DateTime fecha_asist, string estado_asist)
        {
            nuevo = new NodoArbol_ASISTENCIA(id_asist, cod_est, cod_asig, fecha_asist, estado_asist, null, null);
        }

        public void insertar_nodo(NodoArbol_ASISTENCIA punt, NodoArbol_ASISTENCIA nuevo)
        {
            if (string.Compare(nuevo.id_asist, punt.id_asist) < 0)
            {
                if (punt.enl_izq == null)
                {
                    punt.enl_izq = nuevo;
                }
                else
                {
                    insertar_nodo(punt.enl_izq, nuevo);
                }
            }
            else
            {
                if (punt.enl_der == null)
                {
                    punt.enl_der = nuevo;
                }
                else
                {
                    insertar_nodo(punt.enl_der, nuevo);
                }
            }
        }

        public void insertar_arbol(string id_asist, string cod_est, string cod_asig, DateTime fecha_asist, string estado_asist)
        {
            if (raiz == null)
            {
                crear_nodo(id_asist, cod_est, cod_asig, fecha_asist, estado_asist);
                raiz = nuevo;
            }
            else
            {
                insertar_nodo(raiz, nuevo);
            }
        }

        public NodoArbol_ASISTENCIA devolver_raiz()
        {
            return raiz;
        }


    }
}