﻿namespace p
{
    partial class FrmSOLICITUD_PERMISO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSOLICITUD_PERMISO));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.lblFechSoli = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblCodi = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblSem = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblNomComple = new System.Windows.Forms.Label();
            this.lblCarrera = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMotivoOtros = new System.Windows.Forms.TextBox();
            this.rbOtros = new System.Windows.Forms.RadioButton();
            this.rbFamiliares = new System.Windows.Forms.RadioButton();
            this.rbAtraso = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.rbSalud = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.lblJefat = new System.Windows.Forms.Label();
            this.pcbComprobante = new System.Windows.Forms.PictureBox();
            this.btnVolver = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnFoto = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnEnviar = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.lblArchivoCargado = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbMateria = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rdmateria = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpfechafaltante = new System.Windows.Forms.DateTimePicker();
            this.rddiaentero = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbComprobante)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFechSoli
            // 
            this.lblFechSoli.BackColor = System.Drawing.Color.White;
            this.lblFechSoli.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFechSoli.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechSoli.Location = new System.Drawing.Point(541, 388);
            this.lblFechSoli.Name = "lblFechSoli";
            this.lblFechSoli.Size = new System.Drawing.Size(150, 24);
            this.lblFechSoli.TabIndex = 128;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(369, 393);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(167, 18);
            this.label16.TabIndex = 127;
            this.label16.Text = "FECHA SOLICITUD";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(192, 27);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(266, 24);
            this.label12.TabIndex = 117;
            this.label12.Text = "MOTIVO DEL PERMISO";
            // 
            // lblCodi
            // 
            this.lblCodi.BackColor = System.Drawing.Color.White;
            this.lblCodi.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCodi.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodi.Location = new System.Drawing.Point(134, 93);
            this.lblCodi.Name = "lblCodi";
            this.lblCodi.Size = new System.Drawing.Size(130, 24);
            this.lblCodi.TabIndex = 116;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(22, 94);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 24);
            this.label10.TabIndex = 115;
            this.label10.Text = "CODIGO";
            // 
            // lblSem
            // 
            this.lblSem.BackColor = System.Drawing.Color.White;
            this.lblSem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSem.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSem.Location = new System.Drawing.Point(173, 161);
            this.lblSem.Name = "lblSem";
            this.lblSem.Size = new System.Drawing.Size(130, 25);
            this.lblSem.TabIndex = 114;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(22, 163);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 24);
            this.label7.TabIndex = 113;
            this.label7.Text = "SEMESTRE";
            // 
            // lblNomComple
            // 
            this.lblNomComple.BackColor = System.Drawing.Color.White;
            this.lblNomComple.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNomComple.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomComple.Location = new System.Drawing.Point(300, 128);
            this.lblNomComple.Name = "lblNomComple";
            this.lblNomComple.Size = new System.Drawing.Size(379, 24);
            this.lblNomComple.TabIndex = 112;
            // 
            // lblCarrera
            // 
            this.lblCarrera.BackColor = System.Drawing.Color.White;
            this.lblCarrera.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCarrera.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarrera.Location = new System.Drawing.Point(405, 93);
            this.lblCarrera.Name = "lblCarrera";
            this.lblCarrera.Size = new System.Drawing.Size(274, 24);
            this.lblCarrera.TabIndex = 111;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 128);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(263, 24);
            this.label3.TabIndex = 110;
            this.label3.Text = "NOMBRES APELLIDOS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(281, 94);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 24);
            this.label2.TabIndex = 109;
            this.label2.Text = "CARRERA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(532, 29);
            this.label1.TabIndex = 108;
            this.label1.Text = "SOLICITUD DE PERMISOS PARA ESTUDIANTES";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtMotivoOtros);
            this.groupBox1.Controls.Add(this.rbOtros);
            this.groupBox1.Controls.Add(this.rbFamiliares);
            this.groupBox1.Controls.Add(this.rbAtraso);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.rbSalud);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Location = new System.Drawing.Point(26, 203);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(653, 176);
            this.groupBox1.TabIndex = 129;
            this.groupBox1.TabStop = false;
            // 
            // txtMotivoOtros
            // 
            this.txtMotivoOtros.Location = new System.Drawing.Point(439, 133);
            this.txtMotivoOtros.Name = "txtMotivoOtros";
            this.txtMotivoOtros.Size = new System.Drawing.Size(185, 20);
            this.txtMotivoOtros.TabIndex = 129;
            // 
            // rbOtros
            // 
            this.rbOtros.AutoSize = true;
            this.rbOtros.Location = new System.Drawing.Point(370, 133);
            this.rbOtros.Name = "rbOtros";
            this.rbOtros.Size = new System.Drawing.Size(66, 17);
            this.rbOtros.TabIndex = 128;
            this.rbOtros.TabStop = true;
            this.rbOtros.Text = "OTROS:";
            this.rbOtros.UseVisualStyleBackColor = true;
            this.rbOtros.CheckedChanged += new System.EventHandler(this.rbOtros_CheckedChanged);
            // 
            // rbFamiliares
            // 
            this.rbFamiliares.AutoSize = true;
            this.rbFamiliares.Location = new System.Drawing.Point(468, 66);
            this.rbFamiliares.Name = "rbFamiliares";
            this.rbFamiliares.Size = new System.Drawing.Size(88, 17);
            this.rbFamiliares.TabIndex = 127;
            this.rbFamiliares.TabStop = true;
            this.rbFamiliares.Text = "FAMILIARES";
            this.rbFamiliares.UseVisualStyleBackColor = true;
            // 
            // rbAtraso
            // 
            this.rbAtraso.AutoSize = true;
            this.rbAtraso.Location = new System.Drawing.Point(122, 133);
            this.rbAtraso.Name = "rbAtraso";
            this.rbAtraso.Size = new System.Drawing.Size(95, 17);
            this.rbAtraso.TabIndex = 126;
            this.rbAtraso.TabStop = true;
            this.rbAtraso.Text = "POR ATRASO";
            this.rbAtraso.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(220, 66);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(113, 17);
            this.radioButton1.TabIndex = 125;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "POR PENSIONES";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rbSalud
            // 
            this.rbSalud.AutoSize = true;
            this.rbSalud.Location = new System.Drawing.Point(53, 66);
            this.rbSalud.Name = "rbSalud";
            this.rbSalud.Size = new System.Drawing.Size(87, 17);
            this.rbSalud.TabIndex = 124;
            this.rbSalud.TabStop = true;
            this.rbSalud.Text = "POR SALUD";
            this.rbSalud.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(318, 163);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 24);
            this.label4.TabIndex = 132;
            this.label4.Text = "JEFATURA";
            // 
            // lblJefat
            // 
            this.lblJefat.BackColor = System.Drawing.Color.White;
            this.lblJefat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblJefat.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJefat.Location = new System.Drawing.Point(459, 162);
            this.lblJefat.Name = "lblJefat";
            this.lblJefat.Size = new System.Drawing.Size(220, 25);
            this.lblJefat.TabIndex = 133;
            // 
            // pcbComprobante
            // 
            this.pcbComprobante.Location = new System.Drawing.Point(26, 598);
            this.pcbComprobante.Name = "pcbComprobante";
            this.pcbComprobante.Size = new System.Drawing.Size(185, 59);
            this.pcbComprobante.TabIndex = 136;
            this.pcbComprobante.TabStop = false;
            // 
            // btnVolver
            // 
            this.btnVolver.AllowAnimations = true;
            this.btnVolver.AllowMouseEffects = true;
            this.btnVolver.AllowToggling = false;
            this.btnVolver.AnimationSpeed = 200;
            this.btnVolver.AutoGenerateColors = false;
            this.btnVolver.AutoRoundBorders = true;
            this.btnVolver.AutoSizeLeftIcon = true;
            this.btnVolver.AutoSizeRightIcon = true;
            this.btnVolver.BackColor = System.Drawing.Color.Transparent;
            this.btnVolver.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnVolver.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVolver.BackgroundImage")));
            this.btnVolver.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.ButtonText = "REGRESAR";
            this.btnVolver.ButtonTextMarginLeft = 0;
            this.btnVolver.ColorContrastOnClick = 45;
            this.btnVolver.ColorContrastOnHover = 45;
            this.btnVolver.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.btnVolver.CustomizableEdges = borderEdges4;
            this.btnVolver.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnVolver.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnVolver.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnVolver.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnVolver.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnVolver.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnVolver.ForeColor = System.Drawing.Color.White;
            this.btnVolver.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolver.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnVolver.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnVolver.IconMarginLeft = 11;
            this.btnVolver.IconPadding = 10;
            this.btnVolver.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVolver.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnVolver.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnVolver.IconSize = 25;
            this.btnVolver.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.IdleBorderRadius = 37;
            this.btnVolver.IdleBorderThickness = 1;
            this.btnVolver.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.IdleIconLeftImage = null;
            this.btnVolver.IdleIconRightImage = null;
            this.btnVolver.IndicateFocus = false;
            this.btnVolver.Location = new System.Drawing.Point(529, 608);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnVolver.OnDisabledState.BorderRadius = 1;
            this.btnVolver.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.OnDisabledState.BorderThickness = 1;
            this.btnVolver.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnVolver.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnVolver.OnDisabledState.IconLeftImage = null;
            this.btnVolver.OnDisabledState.IconRightImage = null;
            this.btnVolver.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnVolver.onHoverState.BorderRadius = 1;
            this.btnVolver.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.onHoverState.BorderThickness = 1;
            this.btnVolver.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnVolver.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnVolver.onHoverState.IconLeftImage = null;
            this.btnVolver.onHoverState.IconRightImage = null;
            this.btnVolver.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.OnIdleState.BorderRadius = 1;
            this.btnVolver.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.OnIdleState.BorderThickness = 1;
            this.btnVolver.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnVolver.OnIdleState.IconLeftImage = null;
            this.btnVolver.OnIdleState.IconRightImage = null;
            this.btnVolver.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnVolver.OnPressedState.BorderRadius = 1;
            this.btnVolver.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.OnPressedState.BorderThickness = 1;
            this.btnVolver.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnVolver.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnVolver.OnPressedState.IconLeftImage = null;
            this.btnVolver.OnPressedState.IconRightImage = null;
            this.btnVolver.Size = new System.Drawing.Size(150, 39);
            this.btnVolver.TabIndex = 137;
            this.btnVolver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnVolver.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnVolver.TextMarginLeft = 0;
            this.btnVolver.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnVolver.UseDefaultRadiusAndThickness = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click_1);
            // 
            // btnFoto
            // 
            this.btnFoto.AllowAnimations = true;
            this.btnFoto.AllowMouseEffects = true;
            this.btnFoto.AllowToggling = false;
            this.btnFoto.AnimationSpeed = 200;
            this.btnFoto.AutoGenerateColors = false;
            this.btnFoto.AutoRoundBorders = false;
            this.btnFoto.AutoSizeLeftIcon = true;
            this.btnFoto.AutoSizeRightIcon = true;
            this.btnFoto.BackColor = System.Drawing.Color.Transparent;
            this.btnFoto.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnFoto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFoto.BackgroundImage")));
            this.btnFoto.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnFoto.ButtonText = "SUBIR COMPROBANTE";
            this.btnFoto.ButtonTextMarginLeft = 0;
            this.btnFoto.ColorContrastOnClick = 45;
            this.btnFoto.ColorContrastOnHover = 45;
            this.btnFoto.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.btnFoto.CustomizableEdges = borderEdges5;
            this.btnFoto.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnFoto.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnFoto.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnFoto.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnFoto.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnFoto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnFoto.ForeColor = System.Drawing.Color.White;
            this.btnFoto.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFoto.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnFoto.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnFoto.IconMarginLeft = 11;
            this.btnFoto.IconPadding = 10;
            this.btnFoto.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFoto.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnFoto.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnFoto.IconSize = 25;
            this.btnFoto.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnFoto.IdleBorderRadius = 1;
            this.btnFoto.IdleBorderThickness = 1;
            this.btnFoto.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnFoto.IdleIconLeftImage = null;
            this.btnFoto.IdleIconRightImage = null;
            this.btnFoto.IndicateFocus = false;
            this.btnFoto.Location = new System.Drawing.Point(209, 618);
            this.btnFoto.Name = "btnFoto";
            this.btnFoto.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnFoto.OnDisabledState.BorderRadius = 1;
            this.btnFoto.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnFoto.OnDisabledState.BorderThickness = 1;
            this.btnFoto.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnFoto.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnFoto.OnDisabledState.IconLeftImage = null;
            this.btnFoto.OnDisabledState.IconRightImage = null;
            this.btnFoto.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnFoto.onHoverState.BorderRadius = 1;
            this.btnFoto.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnFoto.onHoverState.BorderThickness = 1;
            this.btnFoto.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnFoto.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnFoto.onHoverState.IconLeftImage = null;
            this.btnFoto.onHoverState.IconRightImage = null;
            this.btnFoto.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnFoto.OnIdleState.BorderRadius = 1;
            this.btnFoto.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnFoto.OnIdleState.BorderThickness = 1;
            this.btnFoto.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnFoto.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnFoto.OnIdleState.IconLeftImage = null;
            this.btnFoto.OnIdleState.IconRightImage = null;
            this.btnFoto.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnFoto.OnPressedState.BorderRadius = 1;
            this.btnFoto.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnFoto.OnPressedState.BorderThickness = 1;
            this.btnFoto.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnFoto.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnFoto.OnPressedState.IconLeftImage = null;
            this.btnFoto.OnPressedState.IconRightImage = null;
            this.btnFoto.Size = new System.Drawing.Size(150, 39);
            this.btnFoto.TabIndex = 138;
            this.btnFoto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFoto.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnFoto.TextMarginLeft = 0;
            this.btnFoto.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnFoto.UseDefaultRadiusAndThickness = true;
            this.btnFoto.Click += new System.EventHandler(this.btnFoto_Click_1);
            // 
            // btnEnviar
            // 
            this.btnEnviar.AllowAnimations = true;
            this.btnEnviar.AllowMouseEffects = true;
            this.btnEnviar.AllowToggling = false;
            this.btnEnviar.AnimationSpeed = 200;
            this.btnEnviar.AutoGenerateColors = false;
            this.btnEnviar.AutoRoundBorders = true;
            this.btnEnviar.AutoSizeLeftIcon = true;
            this.btnEnviar.AutoSizeRightIcon = true;
            this.btnEnviar.BackColor = System.Drawing.Color.Transparent;
            this.btnEnviar.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnEnviar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEnviar.BackgroundImage")));
            this.btnEnviar.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEnviar.ButtonText = "ENVIAR";
            this.btnEnviar.ButtonTextMarginLeft = 0;
            this.btnEnviar.ColorContrastOnClick = 45;
            this.btnEnviar.ColorContrastOnHover = 45;
            this.btnEnviar.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.btnEnviar.CustomizableEdges = borderEdges6;
            this.btnEnviar.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEnviar.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnEnviar.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnEnviar.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnEnviar.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnEnviar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEnviar.ForeColor = System.Drawing.Color.White;
            this.btnEnviar.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEnviar.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnEnviar.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnEnviar.IconMarginLeft = 11;
            this.btnEnviar.IconPadding = 10;
            this.btnEnviar.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEnviar.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnEnviar.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnEnviar.IconSize = 25;
            this.btnEnviar.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnEnviar.IdleBorderRadius = 37;
            this.btnEnviar.IdleBorderThickness = 1;
            this.btnEnviar.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnEnviar.IdleIconLeftImage = null;
            this.btnEnviar.IdleIconRightImage = null;
            this.btnEnviar.IndicateFocus = false;
            this.btnEnviar.Location = new System.Drawing.Point(365, 618);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnEnviar.OnDisabledState.BorderRadius = 1;
            this.btnEnviar.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEnviar.OnDisabledState.BorderThickness = 1;
            this.btnEnviar.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnEnviar.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnEnviar.OnDisabledState.IconLeftImage = null;
            this.btnEnviar.OnDisabledState.IconRightImage = null;
            this.btnEnviar.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnEnviar.onHoverState.BorderRadius = 1;
            this.btnEnviar.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEnviar.onHoverState.BorderThickness = 1;
            this.btnEnviar.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnEnviar.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnEnviar.onHoverState.IconLeftImage = null;
            this.btnEnviar.onHoverState.IconRightImage = null;
            this.btnEnviar.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnEnviar.OnIdleState.BorderRadius = 1;
            this.btnEnviar.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEnviar.OnIdleState.BorderThickness = 1;
            this.btnEnviar.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnEnviar.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnEnviar.OnIdleState.IconLeftImage = null;
            this.btnEnviar.OnIdleState.IconRightImage = null;
            this.btnEnviar.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnEnviar.OnPressedState.BorderRadius = 1;
            this.btnEnviar.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEnviar.OnPressedState.BorderThickness = 1;
            this.btnEnviar.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnEnviar.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnEnviar.OnPressedState.IconLeftImage = null;
            this.btnEnviar.OnPressedState.IconRightImage = null;
            this.btnEnviar.Size = new System.Drawing.Size(150, 39);
            this.btnEnviar.TabIndex = 139;
            this.btnEnviar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEnviar.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnEnviar.TextMarginLeft = 0;
            this.btnEnviar.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnEnviar.UseDefaultRadiusAndThickness = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click_1);
            // 
            // lblArchivoCargado
            // 
            this.lblArchivoCargado.AutoSize = true;
            this.lblArchivoCargado.Location = new System.Drawing.Point(225, 435);
            this.lblArchivoCargado.Name = "lblArchivoCargado";
            this.lblArchivoCargado.Size = new System.Drawing.Size(0, 13);
            this.lblArchivoCargado.TabIndex = 140;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.rddiaentero);
            this.groupBox2.Controls.Add(this.rdmateria);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cmbMateria);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(44, 416);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(606, 153);
            this.groupBox2.TabIndex = 141;
            this.groupBox2.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(88, 108);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(159, 24);
            this.label8.TabIndex = 142;
            this.label8.Text = "ASIGNATURA";
            // 
            // cmbMateria
            // 
            this.cmbMateria.FormattingEnabled = true;
            this.cmbMateria.Location = new System.Drawing.Point(268, 108);
            this.cmbMateria.Name = "cmbMateria";
            this.cmbMateria.Size = new System.Drawing.Size(270, 21);
            this.cmbMateria.TabIndex = 123;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Ivory;
            this.label6.Location = new System.Drawing.Point(193, 26);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(247, 24);
            this.label6.TabIndex = 117;
            this.label6.Text = "MATERIA FALTANTE";
            // 
            // rdmateria
            // 
            this.rdmateria.AutoSize = true;
            this.rdmateria.Location = new System.Drawing.Point(114, 66);
            this.rdmateria.Name = "rdmateria";
            this.rdmateria.Size = new System.Drawing.Size(73, 17);
            this.rdmateria.TabIndex = 143;
            this.rdmateria.TabStop = true;
            this.rdmateria.Text = "MATERIA";
            this.rdmateria.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(21, 393);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 18);
            this.label5.TabIndex = 142;
            this.label5.Text = "FECHA PERMISO";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // dtpfechafaltante
            // 
            this.dtpfechafaltante.Location = new System.Drawing.Point(173, 392);
            this.dtpfechafaltante.Name = "dtpfechafaltante";
            this.dtpfechafaltante.Size = new System.Drawing.Size(186, 20);
            this.dtpfechafaltante.TabIndex = 143;
            // 
            // rddiaentero
            // 
            this.rddiaentero.AutoSize = true;
            this.rddiaentero.Location = new System.Drawing.Point(427, 66);
            this.rddiaentero.Name = "rddiaentero";
            this.rddiaentero.Size = new System.Drawing.Size(91, 17);
            this.rddiaentero.TabIndex = 144;
            this.rddiaentero.TabStop = true;
            this.rddiaentero.Text = "DIA ENTERO";
            this.rddiaentero.UseVisualStyleBackColor = true;
            // 
            // FrmSOLICITUD_PERMISO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(703, 656);
            this.Controls.Add(this.dtpfechafaltante);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblArchivoCargado);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.btnFoto);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.pcbComprobante);
            this.Controls.Add(this.lblJefat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblFechSoli);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lblCodi);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblSem);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblNomComple);
            this.Controls.Add(this.lblCarrera);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmSOLICITUD_PERMISO";
            this.Text = " ";
            this.Load += new System.EventHandler(this.FrmSOLICITUD_PERMISO_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbComprobante)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFechSoli;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblCodi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblSem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblNomComple;
        private System.Windows.Forms.Label lblCarrera;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblJefat;
        private System.Windows.Forms.PictureBox pcbComprobante;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnVolver;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnFoto;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnEnviar;
        private System.Windows.Forms.Label lblArchivoCargado;
        private System.Windows.Forms.RadioButton rbSalud;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton rbOtros;
        private System.Windows.Forms.RadioButton rbFamiliares;
        private System.Windows.Forms.RadioButton rbAtraso;
        private System.Windows.Forms.TextBox txtMotivoOtros;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbMateria;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rdmateria;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpfechafaltante;
        private System.Windows.Forms.RadioButton rddiaentero;
    }
}