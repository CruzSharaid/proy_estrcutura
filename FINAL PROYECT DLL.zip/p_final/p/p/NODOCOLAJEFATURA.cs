﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    class NodoCola_Jefatura
    {
        int cod_jef;
        string nombre_jef;
        string cargo_jef;
        int cod_carr;
        int cod_usuario;
        NodoCola_Jefatura enlace;

        public NodoCola_Jefatura(int cod_jef, string nombre_jef, string cargo_jef, int cod_carr, int cod_usuario, NodoCola_Jefatura enl)
        {
            this.cod_jef = cod_jef;
            this.nombre_jef = nombre_jef;
            this.cargo_jef = cargo_jef;
            this.cod_carr = cod_carr;
            this.cod_usuario = cod_usuario;
            this.enlace = enl;
        }

        public int Cod_jef { get => cod_jef; set => cod_jef = value; }
        public string Nombre_jef { get => nombre_jef; set => nombre_jef = value; }
        public string Cargo_jef { get => cargo_jef; set => cargo_jef = value; }
        public int Cod_carr { get => cod_carr; set => cod_carr = value; }
        public int Cod_usuario { get => cod_usuario; set => cod_usuario = value; }
        public NodoCola_Jefatura enl { get => enlace; set => enlace = value; }
    }
}