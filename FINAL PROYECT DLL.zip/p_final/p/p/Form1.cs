﻿using Npgsql; // Importar la librería Npgsql para conectarse a PostgreSQL
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices; // Importar para mover la ventana
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using p; // Importar el namespace donde está la clase PilaLogin

namespace p
{
    public partial class Form1 : Form
    {
        // Importamos las funciones de Windows para mover el formulario
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);


        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None; // Opcional: Remover la barra de título
          
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {

            string user, contra;
            user = txtUsuario.Text;
            contra = txtContraseña.Text;

            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Consulta para verificar el usuario y recuperar el rol y el ID del usuario
                    string queryUsuario = "SELECT rol, id FROM usuarios WHERE username = @user AND password = @contra";
                    using (NpgsqlCommand cmdUsuario = new NpgsqlCommand(queryUsuario, conn))
                    {
                        cmdUsuario.Parameters.AddWithValue("@user", user);
                        cmdUsuario.Parameters.AddWithValue("@contra", contra);

                        using (NpgsqlDataReader reader = cmdUsuario.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string rol = reader["rol"].ToString();
                                int usuarioId = Convert.ToInt32(reader["id"]);

                                // Registro del intento exitoso


                                switch (rol)
                                {
                                    case "ESTUDIANTE":
                                        FrmESTUDIANTE opcion1 = new FrmESTUDIANTE(user);
                                        opcion1.Show();
                                        this.Hide();
                                        break;

                                    case "ENCARGADO":
                                        reader.Close(); // Cerramos el reader antes de ejecutar otra consulta

                                        // Segunda consulta: obtener el código del estudiante asociado al usuarioId
                                        string queryEstudiante = "SELECT cod_est FROM estudiante WHERE id_usuario = @idUsuario";
                                        using (NpgsqlCommand cmdEstudiante = new NpgsqlCommand(queryEstudiante, conn))
                                        {
                                            cmdEstudiante.Parameters.AddWithValue("@idUsuario", usuarioId);

                                            object codEstObj = cmdEstudiante.ExecuteScalar();

                                            if (codEstObj != null)
                                            {
                                                string codEstudiante = codEstObj.ToString();
                                               

                                                // Pasar el codEstudiante al siguiente formulario
                                                FrmENCARGADO opcion2 = new FrmENCARGADO(codEstudiante);
                                                opcion2.Show();
                                                this.Hide();
                                            }
                                            else
                                            {
                                                MessageBox.Show("No se encontró un estudiante asociado a este usuario.", "Error");
                                            }
                                        }
                                        break;

                                    case "JEFATURA":
                                        FrmJEFATURA opcion3 = new FrmJEFATURA(usuarioId); // Pasar el ID de usuario a FrmJEFATURA
                                        opcion3.Show();
                                        this.Hide();
                                        break;

                                    default:
                                        MessageBox.Show("Error: rol no reconocido.");
                                        break;
                                }
                            }
                            else
                            {
                                // Registro del intento fallido
                          
                                MessageBox.Show("Error, no existe este usuario o la contraseña es incorrecta!!");
                                txtUsuario.Text = "";
                                txtContraseña.Text = "";
                                txtUsuario.Focus();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error");
                }
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtContraseña.Text = "";
            txtUsuario.Text = "";
            txtUsuario.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Este evento permite mover el formulario al arrastrar con el mouse en cualquier área del formulario
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            btnAceptar_Click(sender, e); // Llama a la misma lógica de autenticación que el botón 'Aceptar'
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            txtContraseña.Text = "";
            txtUsuario.Text = "";
            txtUsuario.Focus();
        }

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }
        private void btnMostrarIntentos_Click(object sender, EventArgs e)
        {
         
        }

        // Evento para mover el formulario al arrastrar el mouse en el BunifuGradientPanel
        private void bunifuGradientPanel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnMostrarIntentos_Click_1(object sender, EventArgs e)
        {
          
        }

        private void btnTareaPendiente_Click(object sender, EventArgs e)
        {
    

        }

        private void btnMostrarUsuarios_Click(object sender, EventArgs e)
        {
       
        }
    }
}
