﻿namespace p
{
    partial class FrmESTUDIANTE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmESTUDIANTE));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.btnCerrarSesionEstudiante = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnInforPerso = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnSoliciPermiso = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(166, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "BIENVENIDO ESTUDIANTE";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.btnSoliciPermiso);
            this.bunifuGradientPanel1.Controls.Add(this.btnInforPerso);
            this.bunifuGradientPanel1.Controls.Add(this.btnCerrarSesionEstudiante);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Purple;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(606, 283);
            this.bunifuGradientPanel1.TabIndex = 5;
            this.bunifuGradientPanel1.Click += new System.EventHandler(this.bunifuGradientPanel1_Click);
            // 
            // btnCerrarSesionEstudiante
            // 
            this.btnCerrarSesionEstudiante.AllowAnimations = true;
            this.btnCerrarSesionEstudiante.AllowMouseEffects = true;
            this.btnCerrarSesionEstudiante.AllowToggling = false;
            this.btnCerrarSesionEstudiante.AnimationSpeed = 200;
            this.btnCerrarSesionEstudiante.AutoGenerateColors = false;
            this.btnCerrarSesionEstudiante.AutoRoundBorders = true;
            this.btnCerrarSesionEstudiante.AutoSizeLeftIcon = true;
            this.btnCerrarSesionEstudiante.AutoSizeRightIcon = true;
            this.btnCerrarSesionEstudiante.BackColor = System.Drawing.Color.Transparent;
            this.btnCerrarSesionEstudiante.BackColor1 = System.Drawing.Color.Red;
            this.btnCerrarSesionEstudiante.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCerrarSesionEstudiante.BackgroundImage")));
            this.btnCerrarSesionEstudiante.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCerrarSesionEstudiante.ButtonText = "CERRAR SESION";
            this.btnCerrarSesionEstudiante.ButtonTextMarginLeft = 0;
            this.btnCerrarSesionEstudiante.ColorContrastOnClick = 45;
            this.btnCerrarSesionEstudiante.ColorContrastOnHover = 45;
            this.btnCerrarSesionEstudiante.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnCerrarSesionEstudiante.CustomizableEdges = borderEdges3;
            this.btnCerrarSesionEstudiante.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnCerrarSesionEstudiante.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnCerrarSesionEstudiante.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnCerrarSesionEstudiante.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnCerrarSesionEstudiante.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnCerrarSesionEstudiante.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCerrarSesionEstudiante.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesionEstudiante.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarSesionEstudiante.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnCerrarSesionEstudiante.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnCerrarSesionEstudiante.IconMarginLeft = 11;
            this.btnCerrarSesionEstudiante.IconPadding = 10;
            this.btnCerrarSesionEstudiante.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCerrarSesionEstudiante.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnCerrarSesionEstudiante.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnCerrarSesionEstudiante.IconSize = 25;
            this.btnCerrarSesionEstudiante.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnCerrarSesionEstudiante.IdleBorderRadius = 37;
            this.btnCerrarSesionEstudiante.IdleBorderThickness = 1;
            this.btnCerrarSesionEstudiante.IdleFillColor = System.Drawing.Color.Red;
            this.btnCerrarSesionEstudiante.IdleIconLeftImage = null;
            this.btnCerrarSesionEstudiante.IdleIconRightImage = null;
            this.btnCerrarSesionEstudiante.IndicateFocus = false;
            this.btnCerrarSesionEstudiante.Location = new System.Drawing.Point(444, 231);
            this.btnCerrarSesionEstudiante.Name = "btnCerrarSesionEstudiante";
            this.btnCerrarSesionEstudiante.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnCerrarSesionEstudiante.OnDisabledState.BorderRadius = 1;
            this.btnCerrarSesionEstudiante.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCerrarSesionEstudiante.OnDisabledState.BorderThickness = 1;
            this.btnCerrarSesionEstudiante.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnCerrarSesionEstudiante.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnCerrarSesionEstudiante.OnDisabledState.IconLeftImage = null;
            this.btnCerrarSesionEstudiante.OnDisabledState.IconRightImage = null;
            this.btnCerrarSesionEstudiante.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnCerrarSesionEstudiante.onHoverState.BorderRadius = 1;
            this.btnCerrarSesionEstudiante.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCerrarSesionEstudiante.onHoverState.BorderThickness = 1;
            this.btnCerrarSesionEstudiante.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnCerrarSesionEstudiante.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesionEstudiante.onHoverState.IconLeftImage = null;
            this.btnCerrarSesionEstudiante.onHoverState.IconRightImage = null;
            this.btnCerrarSesionEstudiante.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnCerrarSesionEstudiante.OnIdleState.BorderRadius = 1;
            this.btnCerrarSesionEstudiante.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCerrarSesionEstudiante.OnIdleState.BorderThickness = 1;
            this.btnCerrarSesionEstudiante.OnIdleState.FillColor = System.Drawing.Color.Red;
            this.btnCerrarSesionEstudiante.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesionEstudiante.OnIdleState.IconLeftImage = null;
            this.btnCerrarSesionEstudiante.OnIdleState.IconRightImage = null;
            this.btnCerrarSesionEstudiante.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnCerrarSesionEstudiante.OnPressedState.BorderRadius = 1;
            this.btnCerrarSesionEstudiante.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCerrarSesionEstudiante.OnPressedState.BorderThickness = 1;
            this.btnCerrarSesionEstudiante.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnCerrarSesionEstudiante.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesionEstudiante.OnPressedState.IconLeftImage = null;
            this.btnCerrarSesionEstudiante.OnPressedState.IconRightImage = null;
            this.btnCerrarSesionEstudiante.Size = new System.Drawing.Size(150, 39);
            this.btnCerrarSesionEstudiante.TabIndex = 6;
            this.btnCerrarSesionEstudiante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCerrarSesionEstudiante.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnCerrarSesionEstudiante.TextMarginLeft = 0;
            this.btnCerrarSesionEstudiante.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnCerrarSesionEstudiante.UseDefaultRadiusAndThickness = true;
            this.btnCerrarSesionEstudiante.Click += new System.EventHandler(this.btnCerrarSesionEstudiante_Click);
            // 
            // btnInforPerso
            // 
            this.btnInforPerso.AllowAnimations = true;
            this.btnInforPerso.AllowMouseEffects = true;
            this.btnInforPerso.AllowToggling = false;
            this.btnInforPerso.AnimationSpeed = 200;
            this.btnInforPerso.AutoGenerateColors = false;
            this.btnInforPerso.AutoRoundBorders = false;
            this.btnInforPerso.AutoSizeLeftIcon = true;
            this.btnInforPerso.AutoSizeRightIcon = true;
            this.btnInforPerso.BackColor = System.Drawing.Color.Transparent;
            this.btnInforPerso.BackColor1 = System.Drawing.Color.Blue;
            this.btnInforPerso.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInforPerso.BackgroundImage")));
            this.btnInforPerso.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Dot;
            this.btnInforPerso.ButtonText = "INFORMACION ESTUDIANTE";
            this.btnInforPerso.ButtonTextMarginLeft = 0;
            this.btnInforPerso.ColorContrastOnClick = 45;
            this.btnInforPerso.ColorContrastOnHover = 45;
            this.btnInforPerso.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnInforPerso.CustomizableEdges = borderEdges2;
            this.btnInforPerso.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnInforPerso.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnInforPerso.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnInforPerso.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnInforPerso.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnInforPerso.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnInforPerso.ForeColor = System.Drawing.Color.White;
            this.btnInforPerso.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInforPerso.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnInforPerso.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnInforPerso.IconMarginLeft = 11;
            this.btnInforPerso.IconPadding = 10;
            this.btnInforPerso.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnInforPerso.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnInforPerso.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnInforPerso.IconSize = 25;
            this.btnInforPerso.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnInforPerso.IdleBorderRadius = 2;
            this.btnInforPerso.IdleBorderThickness = 1;
            this.btnInforPerso.IdleFillColor = System.Drawing.Color.Blue;
            this.btnInforPerso.IdleIconLeftImage = null;
            this.btnInforPerso.IdleIconRightImage = null;
            this.btnInforPerso.IndicateFocus = false;
            this.btnInforPerso.Location = new System.Drawing.Point(66, 117);
            this.btnInforPerso.Name = "btnInforPerso";
            this.btnInforPerso.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnInforPerso.OnDisabledState.BorderRadius = 2;
            this.btnInforPerso.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnInforPerso.OnDisabledState.BorderThickness = 1;
            this.btnInforPerso.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnInforPerso.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnInforPerso.OnDisabledState.IconLeftImage = null;
            this.btnInforPerso.OnDisabledState.IconRightImage = null;
            this.btnInforPerso.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnInforPerso.onHoverState.BorderRadius = 2;
            this.btnInforPerso.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnInforPerso.onHoverState.BorderThickness = 1;
            this.btnInforPerso.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnInforPerso.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnInforPerso.onHoverState.IconLeftImage = null;
            this.btnInforPerso.onHoverState.IconRightImage = null;
            this.btnInforPerso.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnInforPerso.OnIdleState.BorderRadius = 2;
            this.btnInforPerso.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Dot;
            this.btnInforPerso.OnIdleState.BorderThickness = 1;
            this.btnInforPerso.OnIdleState.FillColor = System.Drawing.Color.Blue;
            this.btnInforPerso.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnInforPerso.OnIdleState.IconLeftImage = null;
            this.btnInforPerso.OnIdleState.IconRightImage = null;
            this.btnInforPerso.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnInforPerso.OnPressedState.BorderRadius = 2;
            this.btnInforPerso.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnInforPerso.OnPressedState.BorderThickness = 1;
            this.btnInforPerso.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnInforPerso.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnInforPerso.OnPressedState.IconLeftImage = null;
            this.btnInforPerso.OnPressedState.IconRightImage = null;
            this.btnInforPerso.Size = new System.Drawing.Size(218, 65);
            this.btnInforPerso.TabIndex = 7;
            this.btnInforPerso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInforPerso.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnInforPerso.TextMarginLeft = 0;
            this.btnInforPerso.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnInforPerso.UseDefaultRadiusAndThickness = true;
            this.btnInforPerso.Click += new System.EventHandler(this.btnInforPerso_Click);
            // 
            // btnSoliciPermiso
            // 
            this.btnSoliciPermiso.AllowAnimations = true;
            this.btnSoliciPermiso.AllowMouseEffects = true;
            this.btnSoliciPermiso.AllowToggling = false;
            this.btnSoliciPermiso.AnimationSpeed = 200;
            this.btnSoliciPermiso.AutoGenerateColors = false;
            this.btnSoliciPermiso.AutoRoundBorders = false;
            this.btnSoliciPermiso.AutoSizeLeftIcon = true;
            this.btnSoliciPermiso.AutoSizeRightIcon = true;
            this.btnSoliciPermiso.BackColor = System.Drawing.Color.Transparent;
            this.btnSoliciPermiso.BackColor1 = System.Drawing.Color.Blue;
            this.btnSoliciPermiso.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoliciPermiso.BackgroundImage")));
            this.btnSoliciPermiso.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Dot;
            this.btnSoliciPermiso.ButtonText = "SOLICITUD DE PERMISOS";
            this.btnSoliciPermiso.ButtonTextMarginLeft = 0;
            this.btnSoliciPermiso.ColorContrastOnClick = 45;
            this.btnSoliciPermiso.ColorContrastOnHover = 45;
            this.btnSoliciPermiso.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnSoliciPermiso.CustomizableEdges = borderEdges1;
            this.btnSoliciPermiso.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSoliciPermiso.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnSoliciPermiso.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnSoliciPermiso.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnSoliciPermiso.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnSoliciPermiso.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSoliciPermiso.ForeColor = System.Drawing.Color.White;
            this.btnSoliciPermiso.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSoliciPermiso.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnSoliciPermiso.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnSoliciPermiso.IconMarginLeft = 11;
            this.btnSoliciPermiso.IconPadding = 10;
            this.btnSoliciPermiso.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSoliciPermiso.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnSoliciPermiso.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnSoliciPermiso.IconSize = 25;
            this.btnSoliciPermiso.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnSoliciPermiso.IdleBorderRadius = 3;
            this.btnSoliciPermiso.IdleBorderThickness = 1;
            this.btnSoliciPermiso.IdleFillColor = System.Drawing.Color.Blue;
            this.btnSoliciPermiso.IdleIconLeftImage = null;
            this.btnSoliciPermiso.IdleIconRightImage = null;
            this.btnSoliciPermiso.IndicateFocus = false;
            this.btnSoliciPermiso.Location = new System.Drawing.Point(326, 117);
            this.btnSoliciPermiso.Name = "btnSoliciPermiso";
            this.btnSoliciPermiso.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnSoliciPermiso.OnDisabledState.BorderRadius = 3;
            this.btnSoliciPermiso.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSoliciPermiso.OnDisabledState.BorderThickness = 1;
            this.btnSoliciPermiso.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnSoliciPermiso.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnSoliciPermiso.OnDisabledState.IconLeftImage = null;
            this.btnSoliciPermiso.OnDisabledState.IconRightImage = null;
            this.btnSoliciPermiso.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnSoliciPermiso.onHoverState.BorderRadius = 3;
            this.btnSoliciPermiso.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSoliciPermiso.onHoverState.BorderThickness = 1;
            this.btnSoliciPermiso.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnSoliciPermiso.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnSoliciPermiso.onHoverState.IconLeftImage = null;
            this.btnSoliciPermiso.onHoverState.IconRightImage = null;
            this.btnSoliciPermiso.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnSoliciPermiso.OnIdleState.BorderRadius = 3;
            this.btnSoliciPermiso.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Dot;
            this.btnSoliciPermiso.OnIdleState.BorderThickness = 1;
            this.btnSoliciPermiso.OnIdleState.FillColor = System.Drawing.Color.Blue;
            this.btnSoliciPermiso.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnSoliciPermiso.OnIdleState.IconLeftImage = null;
            this.btnSoliciPermiso.OnIdleState.IconRightImage = null;
            this.btnSoliciPermiso.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnSoliciPermiso.OnPressedState.BorderRadius = 3;
            this.btnSoliciPermiso.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSoliciPermiso.OnPressedState.BorderThickness = 1;
            this.btnSoliciPermiso.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnSoliciPermiso.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnSoliciPermiso.OnPressedState.IconLeftImage = null;
            this.btnSoliciPermiso.OnPressedState.IconRightImage = null;
            this.btnSoliciPermiso.Size = new System.Drawing.Size(215, 64);
            this.btnSoliciPermiso.TabIndex = 8;
            this.btnSoliciPermiso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSoliciPermiso.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSoliciPermiso.TextMarginLeft = 0;
            this.btnSoliciPermiso.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnSoliciPermiso.UseDefaultRadiusAndThickness = true;
            this.btnSoliciPermiso.Click += new System.EventHandler(this.btnSoliciPermiso_Click);
            // 
            // FrmESTUDIANTE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 283);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmESTUDIANTE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AREA ESTUDIANTES";
            this.Load += new System.EventHandler(this.FrmESTUDIANTE_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnCerrarSesionEstudiante;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSoliciPermiso;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnInforPerso;
    }
}