﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p
{
    public partial class FrmENCARGADO : Form
    {
        private string codEstudiante;
        public FrmENCARGADO(string codEst)
        {
            InitializeComponent();
            this.codEstudiante = codEst;


        }

        private void cERRARSESIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 opcion = new Form1();
            opcion.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void cERRARSESIONToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form1 opcion = new Form1();
            opcion.Show();
            this.Hide();
        }

        private void btnLlenadoAsis_Click(object sender, EventArgs e)
        {
            FrmLLENARASISTENCIA opcion = new FrmLLENARASISTENCIA(codEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void btnNoti_Click(object sender, EventArgs e)
        {
           
                }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
