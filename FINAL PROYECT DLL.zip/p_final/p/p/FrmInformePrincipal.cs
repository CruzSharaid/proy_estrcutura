﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace p
{
    public partial class FrmInformePrincipal : Form
    {
        string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
        private NpgsqlConnection conexion;
        private string codigoEstudiante;

        // Constructor modificado para aceptar el código del estudiante
        public FrmInformePrincipal(string codigoEstudiante)
        {
            InitializeComponent();
            this.codigoEstudiante = codigoEstudiante;
            conexion = new NpgsqlConnection(connectionString);
            cmbAsignaturas.SelectedIndexChanged += cmbAsignaturas_SelectedIndexChanged;


        }

        private void FrmInformePrincipal_Load(object sender, EventArgs e)
        {
            MessageBox.Show(codigoEstudiante);
            CargarInformacionEstudiante();
            CargarAsignaturas();
            CargarPermisosSolicitados();
            dgvPermisos.AllowUserToAddRows = false;
            dgvPermisos.CellFormatting += dgvPermisos_CellFormatting;
            dgvPermisos.CellContentClick += dgvPermisos_CellContentClick;

        }
        private void CargarInformacionEstudiante()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                // Modificar la consulta para que obtenga toda la información del estudiante
                string consulta = @"
            SELECT nombre_est, apat_est, amat_est, correo_est, 
                   (SELECT descrip_sem FROM semestre WHERE cod_sem = estudiante.cod_sem) AS semestre,
                   (SELECT descrip_carr FROM carrera WHERE cod_carr = estudiante.cod_carr) AS carrera
            FROM estudiante
            WHERE cod_est = @cod_est";

                NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);
                NpgsqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    lblNombre.Text = $"{reader["nombre_est"]} {reader["apat_est"]} {reader["amat_est"]}";
                    lblSemestre.Text = reader["semestre"].ToString();
                    lblCarre.Text = reader["carrera"].ToString();
                    lblCorreo.Text = reader["correo_est"].ToString();
                }

                reader.Close(); // Cerrar el lector para evitar conflicto
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la información del estudiante: " + ex.Message);
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        private void CargarAsignaturas()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                string consulta = @"
        SELECT a.cod_asig, a.nom_asig
        FROM asignatura a
        JOIN estudiante e ON a.cod_sem = e.cod_sem AND a.cod_carr = e.cod_carr
        WHERE e.cod_est = @cod_est";

                NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);

                cmbAsignaturas.Items.Clear(); // Limpiar antes de cargar nuevas asignaturas

                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Agregar el código y el nombre como un KeyValuePair
                        cmbAsignaturas.Items.Add(new KeyValuePair<int, string>(
                            Convert.ToInt32(reader["cod_asig"]),
                            reader["nom_asig"].ToString()
                        ));
                    }
                }

                cmbAsignaturas.DisplayMember = "Value"; // Mostrar el nombre de la asignatura
                cmbAsignaturas.ValueMember = "Key"; // Obtener el código de la asignatura
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar asignaturas: " + ex.Message);
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }



        private void CargarPermisosSolicitados()
        {
            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                // Filtra los permisos del estudiante según su código
                string consulta = @"
        SELECT id_per AS ""ID PERMISO"",
               fecha_sol_per AS ""FECHA PERMISO"",
               motivo_per AS ""MOTIVO"",
               estado_per AS ""ESTADO"",
               'Descargar' AS ""COMPROBANTE""
        FROM permiso
        WHERE cod_est = @cod_est";

                NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);

                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgvPermisos.DataSource = dt;

                // Ajusta la configuración del DataGridView
                dgvPermisos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                // Establece el DataGridView como de solo lectura
                dgvPermisos.ReadOnly = true;

                // Si la columna de comprobante aún no ha sido agregada, agrégala
                if (!dgvPermisos.Columns.Contains("DescargarComprobante"))
                {
                    DataGridViewButtonColumn btnDescargar = new DataGridViewButtonColumn();
                    btnDescargar.Name = "DescargarComprobante";
                    btnDescargar.Text = "Descargar";
                    btnDescargar.UseColumnTextForButtonValue = true;
                    dgvPermisos.Columns.Add(btnDescargar);
                }

                // Permitir solo la columna de botón de descarga como interactiva
                dgvPermisos.Columns["DescargarComprobante"].ReadOnly = false;
                lblCantPermisos.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los permisos solicitados: " + ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        private void CalcularPorcentajeAsistencia()
        {
            if (cmbAsignaturas.SelectedItem == null)
            {
                MessageBox.Show("Por favor selecciona una asignatura.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obtener el código de asignatura seleccionado
            int codigoAsignatura = ((KeyValuePair<int, string>)cmbAsignaturas.SelectedItem).Key;

            try
            {
                if (conexion.State == ConnectionState.Closed)
                {
                    conexion.Open();
                }

                // Consulta para obtener los registros de asistencia
                string consulta = @"
        SELECT estado_asist
        FROM asistencia
        WHERE cod_asig = @codAsig AND cod_est = @codEst";

                NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                cmd.Parameters.AddWithValue("@codAsig", NpgsqlTypes.NpgsqlDbType.Integer, codigoAsignatura);
                cmd.Parameters.AddWithValue("@codEst", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);

                int totalRegistros = 0;
                double sumaTotal = 0;

                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        totalRegistros++;

                        string estado = reader["estado_asist"].ToString();

                        switch (estado)
                        {
                            case "Presente":
                            case "Guardia":
                                sumaTotal += 10;
                                break;
                            case "Permiso":
                                sumaTotal += 5;
                                break;
                            case "Falta":
                                sumaTotal += 0;
                                break;
                        }
                    }
                }

                if (totalRegistros > 0)
                {
                    double porcentajeAsistencia = (sumaTotal / (totalRegistros * 10)) * 100;
                    lblporcentaje.Text = $"{porcentajeAsistencia:F2}%";
                }
                else
                {
                    lblporcentaje.Text = "0.00%";
                    MessageBox.Show($"No se encontraron registros de asistencia para la asignatura seleccionada.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al calcular el porcentaje de asistencia: " + ex.Message);
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }



        private void dgvPermisos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvPermisos.Columns[e.ColumnIndex].Name == "DescargarComprobante")
            {
                int idPermiso = Convert.ToInt32(dgvPermisos.Rows[e.RowIndex].Cells["ID PERMISO"].Value);
                DescargarComprobante(idPermiso);
            }
        }

        private void DescargarComprobante(int idPermiso)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string consulta = "SELECT comprb FROM permiso WHERE id_per = @id_per";
                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@id_per", idPermiso);

                    object resultado = cmd.ExecuteScalar();
                    if (resultado != DBNull.Value && resultado is byte[] comprobanteBytes)
                    {
                        string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), $"comprobante_{idPermiso}.pdf");

                        try
                        {
                            // Intentar escribir el archivo
                            File.WriteAllBytes(filePath, comprobanteBytes);
                            MessageBox.Show($"Comprobante descargado correctamente en: {filePath}");

                            // Abrir el archivo
                            Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });
                        }
                        catch (Exception fileEx)
                        {
                            MessageBox.Show("Error al escribir el archivo: " + fileEx.Message);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No hay comprobante disponible para este permiso o el dato es inválido.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al descargar el comprobante: " + ex.Message);
                }
            }
        }
        private void dgvPermisos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvPermisos.Columns["ESTADO"] != null)
            {
                string estado = dgvPermisos.Rows[e.RowIndex].Cells["ESTADO"].Value?.ToString();

                if (!string.IsNullOrEmpty(estado))
                {
                    if (estado.Equals("Aprobado", StringComparison.OrdinalIgnoreCase))
                    {
                        dgvPermisos.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightGreen;
                    }
                    else if (estado.Equals("Rechazado", StringComparison.OrdinalIgnoreCase))
                    {
                        dgvPermisos.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightCoral;
                    }
                    else if (estado.Equals("Pendiente", StringComparison.OrdinalIgnoreCase))
                    {
                        dgvPermisos.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightYellow;
                    }
                }
            }
        }



        private void btnVolver_Click(object sender, EventArgs e)
        {
            FrmESTUDIANTE opcion = new FrmESTUDIANTE(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void btnVolver_Click_1(object sender, EventArgs e)
        {
            FrmESTUDIANTE opcion = new FrmESTUDIANTE(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnACCEDER_Click(object sender, EventArgs e)
        {

        }

        private void btnLIMPIAR_Click(object sender, EventArgs e)
        {

        }

        private void btnPorcentaje_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnPorcentaje_Click_1(object sender, EventArgs e)
        {
            CalcularPorcentajeAsistencia();
        }
        private bool isProcessing = false; // Bandera para evitar múltiples ejecuciones

        private void cmbAsignaturas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isProcessing) return; // Si ya se está procesando, no hacer nada
            isProcessing = true; // Inicia el proceso

            try
            {
                if (cmbAsignaturas.SelectedItem != null)
                {
                    // Obtener el código de asignatura seleccionado
                    var asignaturaSeleccionada = (KeyValuePair<int, string>)cmbAsignaturas.SelectedItem;
                    int codigoAsignatura = asignaturaSeleccionada.Key;
                    string nombreAsignatura = asignaturaSeleccionada.Value;

                    // Consulta SQL para obtener puntos ganados, puntos totales y porcentaje
                    string consultaResumen = @"
            SELECT
                SUM(CASE
                        WHEN estado_asist = 'Presente' THEN 10
                        WHEN estado_asist = 'Guardia' THEN 10
                        WHEN estado_asist = 'Permiso' THEN 5
                        ELSE 0
                    END) AS PuntosGanados,
                COUNT(*) * 10 AS TotalPuntos,
                ROUND((SUM(CASE
                            WHEN estado_asist = 'Presente' THEN 10
                            WHEN estado_asist = 'Guardia' THEN 10
                            WHEN estado_asist = 'Permiso' THEN 5
                            ELSE 0
                        END) * 100.0) / (COUNT(*) * 10), 2) AS PorcentajeAsistencia
            FROM
                asistencia AS asi
            WHERE
                asi.cod_est = @codEst
                AND asi.cod_asig = @codAsig";

                    // Consulta SQL para obtener las asistencias detalladas
                    string consultaAsistencias = @"
            SELECT
                a.nom_asig AS NombreAsignatura,
                asi.fecha_asist AS Fecha,
                asi.estado_asist AS Estado
            FROM
                asistencia AS asi
            JOIN
                asignatura AS a ON asi.cod_asig = a.cod_asig
            WHERE
                asi.cod_est = @codEst
                AND asi.cod_asig = @codAsig";

                    if (conexion.State == ConnectionState.Closed)
                    {
                        conexion.Open();
                    }

                    // Ejecutar consulta para el resumen
                    NpgsqlCommand cmdResumen = new NpgsqlCommand(consultaResumen, conexion);
                    cmdResumen.Parameters.AddWithValue("@codEst", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);
                    cmdResumen.Parameters.AddWithValue("@codAsig", NpgsqlTypes.NpgsqlDbType.Integer, codigoAsignatura);

                    using (NpgsqlDataReader reader = cmdResumen.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Asignar los valores a los labels
                            lblpuntosganados.Text = reader["PuntosGanados"].ToString();
                            lblpuntostotales.Text = reader["TotalPuntos"].ToString();
                            lblporcentaje.Text = $"{reader["PorcentajeAsistencia"]}%";
                        }
                        else
                        {
                            lblpuntosganados.Text = "0";
                            lblpuntostotales.Text = "0";
                            lblporcentaje.Text = "0%";
                            MessageBox.Show("No se encontraron registros para la asignatura seleccionada.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                    // Ejecutar consulta para las asistencias detalladas
                    NpgsqlCommand cmdAsistencias = new NpgsqlCommand(consultaAsistencias, conexion);
                    cmdAsistencias.Parameters.AddWithValue("@codEst", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);
                    cmdAsistencias.Parameters.AddWithValue("@codAsig", NpgsqlTypes.NpgsqlDbType.Integer, codigoAsignatura);

                    NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(cmdAsistencias);
                    DataTable dtAsistencias = new DataTable();
                    adapter.Fill(dtAsistencias);

                    // Asignar los datos al DataGridView
                    dgvasistencia.DataSource = dtAsistencias;
                }
                else
                {
                    lblpuntosganados.Text = "0";
                    lblpuntostotales.Text = "0";
                    lblporcentaje.Text = "0%";
                    dgvasistencia.DataSource = null; // Limpiar el DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                isProcessing = false; // Termina el proceso
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }

}
 