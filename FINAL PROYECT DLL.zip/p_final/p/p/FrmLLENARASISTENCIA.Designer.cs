﻿namespace p
{
    partial class FrmLLENARASISTENCIA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvLlenadoAsis = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnGenerarPDF = new System.Windows.Forms.Button();
            this.lblNombre = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblDocen = new System.Windows.Forms.Label();
            this.lblCurso = new System.Windows.Forms.Label();
            this.btnVolver = new System.Windows.Forms.Button();
            this.cmbasig = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblcarrera = new System.Windows.Forms.Label();
            this.dtfecha = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLlenadoAsis)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvLlenadoAsis
            // 
            this.dgvLlenadoAsis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLlenadoAsis.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column5,
            this.Column3});
            this.dgvLlenadoAsis.Location = new System.Drawing.Point(69, 206);
            this.dgvLlenadoAsis.Name = "dgvLlenadoAsis";
            this.dgvLlenadoAsis.Size = new System.Drawing.Size(866, 590);
            this.dgvLlenadoAsis.TabIndex = 0;
            this.dgvLlenadoAsis.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLlenadoAsis_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "CODIGO";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "APELLIDO PATERNO";
            this.Column2.Name = "Column2";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "APELLIDO MATERNO";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "NOMBRE COMPLETO";
            this.Column5.Name = "Column5";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "ESTADO";
            this.Column3.Items.AddRange(new object[] {
            "ASISTE",
            "FALTA",
            "PERMISO",
            "GUARDIA"});
            this.Column3.Name = "Column3";
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(339, 818);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(130, 51);
            this.btnGuardar.TabIndex = 1;
            this.btnGuardar.Text = "GUARDAR";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnGenerarPDF
            // 
            this.btnGenerarPDF.Location = new System.Drawing.Point(538, 818);
            this.btnGenerarPDF.Name = "btnGenerarPDF";
            this.btnGenerarPDF.Size = new System.Drawing.Size(130, 51);
            this.btnGenerarPDF.TabIndex = 2;
            this.btnGenerarPDF.Text = "GENERAR PDF";
            this.btnGenerarPDF.UseVisualStyleBackColor = true;
            this.btnGenerarPDF.Click += new System.EventHandler(this.btnGenerarPDF_Click);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(372, 30);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(259, 23);
            this.lblNombre.TabIndex = 4;
            this.lblNombre.Text = "LLENADO DE ASISTENCIA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(242, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "DOCENTE:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(242, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "SEMESTRE:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(242, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "FECHA:";
            // 
            // lblDocen
            // 
            this.lblDocen.BackColor = System.Drawing.Color.White;
            this.lblDocen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDocen.Location = new System.Drawing.Point(341, 133);
            this.lblDocen.Name = "lblDocen";
            this.lblDocen.Size = new System.Drawing.Size(221, 24);
            this.lblDocen.TabIndex = 12;
            // 
            // lblCurso
            // 
            this.lblCurso.BackColor = System.Drawing.Color.White;
            this.lblCurso.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCurso.Location = new System.Drawing.Point(341, 167);
            this.lblCurso.Name = "lblCurso";
            this.lblCurso.Size = new System.Drawing.Size(148, 19);
            this.lblCurso.TabIndex = 13;
            // 
            // btnVolver
            // 
            this.btnVolver.BackColor = System.Drawing.Color.Gold;
            this.btnVolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnVolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolver.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnVolver.Location = new System.Drawing.Point(700, 18);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(75, 46);
            this.btnVolver.TabIndex = 20;
            this.btnVolver.Text = "->";
            this.btnVolver.UseVisualStyleBackColor = false;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // cmbasig
            // 
            this.cmbasig.FormattingEnabled = true;
            this.cmbasig.Location = new System.Drawing.Point(376, 107);
            this.cmbasig.Name = "cmbasig";
            this.cmbasig.Size = new System.Drawing.Size(398, 21);
            this.cmbasig.TabIndex = 27;
            this.cmbasig.SelectedIndexChanged += new System.EventHandler(this.cmbasig_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(242, 105);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 19);
            this.label7.TabIndex = 24;
            this.label7.Text = "ASIGNATURA:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(495, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 19);
            this.label1.TabIndex = 28;
            this.label1.Text = "CARRERA:";
            // 
            // lblcarrera
            // 
            this.lblcarrera.BackColor = System.Drawing.Color.White;
            this.lblcarrera.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblcarrera.Location = new System.Drawing.Point(588, 167);
            this.lblcarrera.Name = "lblcarrera";
            this.lblcarrera.Size = new System.Drawing.Size(187, 19);
            this.lblcarrera.TabIndex = 29;
            // 
            // dtfecha
            // 
            this.dtfecha.Location = new System.Drawing.Point(327, 75);
            this.dtfecha.Name = "dtfecha";
            this.dtfecha.Size = new System.Drawing.Size(235, 20);
            this.dtfecha.TabIndex = 30;
            // 
            // FrmLLENARASISTENCIA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 881);
            this.Controls.Add(this.dtfecha);
            this.Controls.Add(this.lblcarrera);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbasig);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.lblCurso);
            this.Controls.Add(this.lblDocen);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.btnGenerarPDF);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.dgvLlenadoAsis);
            this.Name = "FrmLLENARASISTENCIA";
            this.Text = "FrmLLENARASISTENCIA";
            this.Load += new System.EventHandler(this.FrmLLENARASISTENCIA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLlenadoAsis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvLlenadoAsis;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnGenerarPDF;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column3;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblDocen;
        private System.Windows.Forms.Label lblCurso;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.ComboBox cmbasig;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblcarrera;
        private System.Windows.Forms.DateTimePicker dtfecha;
    }
}