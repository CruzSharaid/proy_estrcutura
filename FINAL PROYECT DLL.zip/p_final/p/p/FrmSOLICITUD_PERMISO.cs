﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p
{
    public partial class FrmSOLICITUD_PERMISO : Form
    {
        private string codigoEstudiante;
 
        byte[] fileData = null;

        public FrmSOLICITUD_PERMISO(string codigoEstudiante)
        {
            InitializeComponent();
            this.codigoEstudiante = codigoEstudiante;
        }

        private void FrmSOLICITUD_PERMISO_Load(object sender, EventArgs e)
        {
            lblCodi.Text = codigoEstudiante;
            lblFechSoli.Text = DateTime.Now.ToString("dd/MM/yyyy");
            CargarInformacionEstudiante();

            // Deshabilitar ComboBox de asignatura al inicio
            cmbMateria.Enabled = false;

            // Asociar eventos a los RadioButtons
            rdmateria.CheckedChanged += new EventHandler(RadioButton_CheckedChanged);
            rddiaentero.CheckedChanged += new EventHandler(RadioButton_CheckedChanged);

            // Asociar evento al DateTimePicker
            dtpfechafaltante.ValueChanged += new EventHandler(DateTimePickerFechaPermiso_ValueChanged);
        }
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (rdmateria.Checked)
            {
                // Si se selecciona "Materia", habilitar el ComboBox y cargar las materias de acuerdo a la fecha seleccionada
                cmbMateria.Enabled = true;
                CargarAsignaturasPorFecha(dtpfechafaltante.Value);
            }
            else if (rddiaentero.Checked)
            {
                // Si se selecciona "Día Entero", deshabilitar el ComboBox de asignatura
                cmbMateria.Enabled = false;
                cmbMateria.DataSource = null; // Limpiar las asignaturas cargadas
            }
        }
        private void DateTimePickerFechaPermiso_ValueChanged(object sender, EventArgs e)
        {
            if (rdmateria.Checked)
            {
                // Si el RadioButton "Materia" está seleccionado, cargar las asignaturas de la fecha seleccionada
                CargarAsignaturasPorFecha(dtpfechafaltante.Value);
            }
        }

        private void CargarAsignaturasPorFecha(DateTime fecha)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();

                    // Consulta para obtener las asignaturas del semestre y carrera del estudiante para el día seleccionado
                    string consulta = @"
                SELECT a.cod_asig, a.nom_asig 
                FROM asignatura a
                JOIN estudiante e ON e.cod_carr = a.cod_carr AND e.cod_sem = a.cod_sem
                JOIN asignatura_horario_dia ahd ON ahd.asignatura_id = a.cod_asig
                WHERE e.cod_est = @cod_est
                AND ahd.dia_id = @dia_id";

                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);
                    // Aquí asumimos que el día de la semana está representado como un número (1 para lunes, 2 para martes, etc.)
                    cmd.Parameters.AddWithValue("@dia_id", (int)fecha.DayOfWeek);

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Asignar las asignaturas al ComboBox
                    cmbMateria.DisplayMember = "nom_asig";
                    cmbMateria.ValueMember = "cod_asig";
                    cmbMateria.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar las asignaturas: " + ex.Message);
                }
                finally
                {
                    conexion.Close();
                }
            }
        }


        private void CargarAsignaturasEstudiante()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();

                    // Consulta para obtener las asignaturas del semestre y carrera del estudiante
                    string consulta = @"SELECT a.cod_asig, a.nom_asig 
                                FROM asignatura a
                                JOIN estudiante e ON e.cod_carr = a.cod_carr AND e.cod_sem = a.cod_sem
                                WHERE e.cod_est = @cod_est";

                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Asignar las asignaturas al ComboBox
                    cmbMateria.DisplayMember = "nom_asig";
                    cmbMateria.ValueMember = "cod_asig";
                    cmbMateria.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar las asignaturas: " + ex.Message);
                }
                finally
                {
                    conexion.Close();
                }
            }
        }
        private void CargarInformacionEstudiante()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    // Consulta para obtener la información del estudiante, semestre, carrera y jefe de carrera
                    string consulta = @"SELECT nombre_est, apat_est, amat_est, 
                                       (SELECT descrip_sem FROM semestre WHERE cod_sem = estudiante.cod_sem) AS semestre, 
                                       (SELECT descrip_carr FROM carrera WHERE cod_carr = estudiante.cod_carr) AS carrera,
                                       (SELECT nombre_jef FROM jefatura WHERE cod_carr = estudiante.cod_carr) AS jefe_carrera
                                FROM estudiante 
                                WHERE cod_est = @cod_est";
                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);
                    NpgsqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Asignar los valores obtenidos a las etiquetas correspondientes
                        lblNomComple.Text = reader["nombre_est"].ToString() + " " + reader["apat_est"].ToString() + " " + reader["amat_est"].ToString();
                        lblSem.Text = reader["semestre"].ToString();
                        lblCarrera.Text = reader["carrera"].ToString();
                        lblJefat.Text = reader["jefe_carrera"].ToString(); // Mostrar el jefe de carrera correspondiente
                    }
                    conexion.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar la información del estudiante: " + ex.Message);
                }
            }
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            FrmESTUDIANTE opcion = new FrmESTUDIANTE(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void btnVolver_Click_1(object sender, EventArgs e)
        {
            FrmESTUDIANTE opcion = new FrmESTUDIANTE(codigoEstudiante);
            opcion.Show();
            this.Hide();
        }

        private void btnFoto_Click(object sender, EventArgs e)
        {

        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {

        }

        private void btnEnviar_Click_1(object sender, EventArgs e)
        {
            // Verificar cuál motivo fue seleccionado
            string motivo = "";
            if (rbSalud.Checked)
            {
                motivo = "Por Salud";
            }
            else if (radioButton1.Checked)
            {
                motivo = "Por Pensiones";
            }
            else if (rbFamiliares.Checked)
            {
                motivo = "Familiares";
            }
            else if (rbAtraso.Checked)
            {
                motivo = "Por Atraso";
            }
            else if (rbOtros.Checked)
            {
                if (string.IsNullOrWhiteSpace(txtMotivoOtros.Text))
                {
                    MessageBox.Show("Por favor, ingrese el motivo en el campo de 'OTROS'.");
                    return; // No continuar si no se ha ingresado un motivo
                }
                motivo = txtMotivoOtros.Text;
            }

            // Fecha permitida (tomada del control DateTimePicker)
            DateTime fechaPermitida = dtpfechafaltante.Value;

            // Determinar si el permiso es para una asignatura o para todo el día
            int? codAsignatura = null; // Usaremos null para representar permiso para todas las asignaturas
            if (rdmateria.Checked)  // Si se selecciona la opción de "Solo para Materia"
            {
                if (cmbMateria.SelectedItem == null)
                {
                    MessageBox.Show("Por favor, seleccione una asignatura.");
                    return; // No continuar si no se ha seleccionado una asignatura
                }

                // Obtener el ID de la asignatura seleccionada
                DataRowView selectedRow = (DataRowView)cmbMateria.SelectedItem;
                codAsignatura = Convert.ToInt32(selectedRow["cod_asig"]);
            }

            // Insertar los datos en la base de datos, incluyendo el motivo
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string consulta = @"INSERT INTO permiso (fecha_sol_per, motivo_per, estado_per, fecha_permitida, comprb, cod_est, cod_jef, cod_asig) 
                                VALUES (@fecha_sol_per, @motivo_per, @estado_per, @fecha_permitida, @comprb, @cod_est, @cod_jef, @cod_asig)";

                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@fecha_sol_per", NpgsqlTypes.NpgsqlDbType.Date, DateTime.Now);
                    cmd.Parameters.AddWithValue("@motivo_per", NpgsqlTypes.NpgsqlDbType.Varchar, motivo);
                    cmd.Parameters.AddWithValue("@estado_per", NpgsqlTypes.NpgsqlDbType.Varchar, "Pendiente");
                    cmd.Parameters.AddWithValue("@fecha_permitida", NpgsqlTypes.NpgsqlDbType.Date, fechaPermitida);
                    cmd.Parameters.AddWithValue("@cod_est", NpgsqlTypes.NpgsqlDbType.Varchar, codigoEstudiante);

                    // Obtener el código del jefe de carrera según el estudiante
                    int codJef = ObtenerCodigoJefatura(codigoEstudiante, conexion);
                    cmd.Parameters.AddWithValue("@cod_jef", NpgsqlTypes.NpgsqlDbType.Integer, codJef);

                    // Si el permiso es para una asignatura específica, guardamos el código de la asignatura
                    if (codAsignatura.HasValue)
                    {
                        cmd.Parameters.AddWithValue("@cod_asig", NpgsqlTypes.NpgsqlDbType.Integer, codAsignatura.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@cod_asig", DBNull.Value); // Si no es para una asignatura específica, guardar null
                    }

                    if (fileData != null)
                    {
                        cmd.Parameters.AddWithValue("@comprb", NpgsqlTypes.NpgsqlDbType.Bytea, fileData);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@comprb", DBNull.Value);
                    }

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Solicitud enviada correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al guardar la solicitud en la base de datos: " + ex.Message);
                }
                finally
                {
                    conexion.Close();
                }
            }
        }

        private void btnFoto_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "PDF Files|*.pdf|Image Files|*.jpg;*.jpeg;*.png";
                openFileDialog.Title = "Seleccionar Comprobante";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string filePath = openFileDialog.FileName;

                        // Verifica si el archivo existe antes de intentar leerlo
                        if (File.Exists(filePath))
                        {
                            fileData = File.ReadAllBytes(filePath);
                            MessageBox.Show("Comprobante cargado correctamente.");
                        }
                        else
                        {
                            MessageBox.Show("El archivo seleccionado no existe.");
                        }
                    }
                    catch (UnauthorizedAccessException)
                    {
                        MessageBox.Show("No tienes permiso para acceder a este archivo.");
                    }
                    catch (IOException ioEx)
                    {
                        MessageBox.Show("El archivo está siendo utilizado por otro programa. Por favor, ciérralo e inténtalo nuevamente. Detalles: " + ioEx.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al cargar el comprobante: " + ex.Message);
                    }
                }
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbOtros_CheckedChanged(object sender, EventArgs e)
        {
            if (rbOtros.Checked)
            {
                txtMotivoOtros.Enabled = true; // Habilitar el TextBox si se selecciona "OTROS"
            }
            else
            {
                txtMotivoOtros.Enabled = false; // Deshabilitar el TextBox si no se selecciona "OTROS"
                txtMotivoOtros.Text = ""; // Limpiar el contenido del TextBox
            }
        }
        // Método para obtener el código del jefe de la carrera del estudiante
        private int ObtenerCodigoJefatura(string codigoEstudiante, NpgsqlConnection conexion)
        {
            try
            {
                string consulta = @"
            SELECT cod_jef 
            FROM jefatura j
            JOIN carrera c ON j.cod_carr = c.cod_carr
            JOIN estudiante e ON e.cod_carr = c.cod_carr
            WHERE e.cod_est = @cod_est";

                using (NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion))
                {
                    cmd.Parameters.AddWithValue("@cod_est", codigoEstudiante);

                    object resultado = cmd.ExecuteScalar();
                    if (resultado != null)
                    {
                        return Convert.ToInt32(resultado);
                    }
                    else
                    {
                        throw new Exception("No se pudo encontrar el jefe de la carrera para este estudiante.");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al obtener el código de jefatura: " + ex.Message);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}