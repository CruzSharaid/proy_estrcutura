﻿namespace p
{
    partial class FrmJEFATURA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmJEFATURA));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.label1 = new System.Windows.Forms.Label();
            this.cERRARSESIONToolStripMenuItem = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnEstu = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnPerm = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnReport = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(276, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(442, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "BIENVENIDOS JEFATURA DE CARRERA";
            // 
            // cERRARSESIONToolStripMenuItem
            // 
            this.cERRARSESIONToolStripMenuItem.AllowAnimations = true;
            this.cERRARSESIONToolStripMenuItem.AllowMouseEffects = true;
            this.cERRARSESIONToolStripMenuItem.AllowToggling = false;
            this.cERRARSESIONToolStripMenuItem.AnimationSpeed = 200;
            this.cERRARSESIONToolStripMenuItem.AutoGenerateColors = false;
            this.cERRARSESIONToolStripMenuItem.AutoRoundBorders = true;
            this.cERRARSESIONToolStripMenuItem.AutoSizeLeftIcon = true;
            this.cERRARSESIONToolStripMenuItem.AutoSizeRightIcon = true;
            this.cERRARSESIONToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.cERRARSESIONToolStripMenuItem.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cERRARSESIONToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cERRARSESIONToolStripMenuItem.BackgroundImage")));
            this.cERRARSESIONToolStripMenuItem.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.ButtonText = "CERRRAR SESION";
            this.cERRARSESIONToolStripMenuItem.ButtonTextMarginLeft = 0;
            this.cERRARSESIONToolStripMenuItem.ColorContrastOnClick = 45;
            this.cERRARSESIONToolStripMenuItem.ColorContrastOnHover = 45;
            this.cERRARSESIONToolStripMenuItem.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.cERRARSESIONToolStripMenuItem.CustomizableEdges = borderEdges1;
            this.cERRARSESIONToolStripMenuItem.DialogResult = System.Windows.Forms.DialogResult.None;
            this.cERRARSESIONToolStripMenuItem.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.cERRARSESIONToolStripMenuItem.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cERRARSESIONToolStripMenuItem.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.cERRARSESIONToolStripMenuItem.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.cERRARSESIONToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cERRARSESIONToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cERRARSESIONToolStripMenuItem.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.cERRARSESIONToolStripMenuItem.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.cERRARSESIONToolStripMenuItem.IconMarginLeft = 11;
            this.cERRARSESIONToolStripMenuItem.IconPadding = 10;
            this.cERRARSESIONToolStripMenuItem.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cERRARSESIONToolStripMenuItem.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.cERRARSESIONToolStripMenuItem.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.cERRARSESIONToolStripMenuItem.IconSize = 25;
            this.cERRARSESIONToolStripMenuItem.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cERRARSESIONToolStripMenuItem.IdleBorderRadius = 37;
            this.cERRARSESIONToolStripMenuItem.IdleBorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cERRARSESIONToolStripMenuItem.IdleIconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.IdleIconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.IndicateFocus = false;
            this.cERRARSESIONToolStripMenuItem.Location = new System.Drawing.Point(403, 202);
            this.cERRARSESIONToolStripMenuItem.Name = "cERRARSESIONToolStripMenuItem";
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cERRARSESIONToolStripMenuItem.onHoverState.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.onHoverState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.onHoverState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cERRARSESIONToolStripMenuItem.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.cERRARSESIONToolStripMenuItem.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.Size = new System.Drawing.Size(166, 39);
            this.cERRARSESIONToolStripMenuItem.TabIndex = 10;
            this.cERRARSESIONToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cERRARSESIONToolStripMenuItem.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.cERRARSESIONToolStripMenuItem.TextMarginLeft = 0;
            this.cERRARSESIONToolStripMenuItem.TextPadding = new System.Windows.Forms.Padding(0);
            this.cERRARSESIONToolStripMenuItem.UseDefaultRadiusAndThickness = true;
            this.cERRARSESIONToolStripMenuItem.Click += new System.EventHandler(this.cERRARSESIONToolStripMenuItem_Click_1);
            // 
            // btnEstu
            // 
            this.btnEstu.AllowAnimations = true;
            this.btnEstu.AllowMouseEffects = true;
            this.btnEstu.AllowToggling = false;
            this.btnEstu.AnimationSpeed = 200;
            this.btnEstu.AutoGenerateColors = false;
            this.btnEstu.AutoRoundBorders = false;
            this.btnEstu.AutoSizeLeftIcon = true;
            this.btnEstu.AutoSizeRightIcon = true;
            this.btnEstu.BackColor = System.Drawing.Color.Transparent;
            this.btnEstu.BackColor1 = System.Drawing.Color.Blue;
            this.btnEstu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEstu.BackgroundImage")));
            this.btnEstu.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEstu.ButtonText = "ESTUDIANTE";
            this.btnEstu.ButtonTextMarginLeft = 0;
            this.btnEstu.ColorContrastOnClick = 45;
            this.btnEstu.ColorContrastOnHover = 45;
            this.btnEstu.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnEstu.CustomizableEdges = borderEdges2;
            this.btnEstu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEstu.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnEstu.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnEstu.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnEstu.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnEstu.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEstu.ForeColor = System.Drawing.Color.White;
            this.btnEstu.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEstu.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnEstu.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnEstu.IconMarginLeft = 11;
            this.btnEstu.IconPadding = 10;
            this.btnEstu.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEstu.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnEstu.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnEstu.IconSize = 25;
            this.btnEstu.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnEstu.IdleBorderRadius = 1;
            this.btnEstu.IdleBorderThickness = 1;
            this.btnEstu.IdleFillColor = System.Drawing.Color.Blue;
            this.btnEstu.IdleIconLeftImage = null;
            this.btnEstu.IdleIconRightImage = null;
            this.btnEstu.IndicateFocus = true;
            this.btnEstu.Location = new System.Drawing.Point(205, 120);
            this.btnEstu.Name = "btnEstu";
            this.btnEstu.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnEstu.OnDisabledState.BorderRadius = 1;
            this.btnEstu.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEstu.OnDisabledState.BorderThickness = 1;
            this.btnEstu.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnEstu.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnEstu.OnDisabledState.IconLeftImage = null;
            this.btnEstu.OnDisabledState.IconRightImage = null;
            this.btnEstu.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnEstu.onHoverState.BorderRadius = 1;
            this.btnEstu.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEstu.onHoverState.BorderThickness = 1;
            this.btnEstu.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnEstu.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnEstu.onHoverState.IconLeftImage = null;
            this.btnEstu.onHoverState.IconRightImage = null;
            this.btnEstu.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnEstu.OnIdleState.BorderRadius = 1;
            this.btnEstu.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEstu.OnIdleState.BorderThickness = 1;
            this.btnEstu.OnIdleState.FillColor = System.Drawing.Color.Blue;
            this.btnEstu.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnEstu.OnIdleState.IconLeftImage = null;
            this.btnEstu.OnIdleState.IconRightImage = null;
            this.btnEstu.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnEstu.OnPressedState.BorderRadius = 1;
            this.btnEstu.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnEstu.OnPressedState.BorderThickness = 1;
            this.btnEstu.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnEstu.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnEstu.OnPressedState.IconLeftImage = null;
            this.btnEstu.OnPressedState.IconRightImage = null;
            this.btnEstu.Size = new System.Drawing.Size(166, 48);
            this.btnEstu.TabIndex = 14;
            this.btnEstu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEstu.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnEstu.TextMarginLeft = 0;
            this.btnEstu.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnEstu.UseDefaultRadiusAndThickness = true;
            this.btnEstu.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // btnPerm
            // 
            this.btnPerm.AllowAnimations = true;
            this.btnPerm.AllowMouseEffects = true;
            this.btnPerm.AllowToggling = false;
            this.btnPerm.AnimationSpeed = 200;
            this.btnPerm.AutoGenerateColors = false;
            this.btnPerm.AutoRoundBorders = false;
            this.btnPerm.AutoSizeLeftIcon = true;
            this.btnPerm.AutoSizeRightIcon = true;
            this.btnPerm.BackColor = System.Drawing.Color.Transparent;
            this.btnPerm.BackColor1 = System.Drawing.Color.Blue;
            this.btnPerm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPerm.BackgroundImage")));
            this.btnPerm.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPerm.ButtonText = "PERMISOS";
            this.btnPerm.ButtonTextMarginLeft = 0;
            this.btnPerm.ColorContrastOnClick = 45;
            this.btnPerm.ColorContrastOnHover = 45;
            this.btnPerm.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnPerm.CustomizableEdges = borderEdges3;
            this.btnPerm.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnPerm.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnPerm.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnPerm.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnPerm.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnPerm.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPerm.ForeColor = System.Drawing.Color.White;
            this.btnPerm.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPerm.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnPerm.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnPerm.IconMarginLeft = 11;
            this.btnPerm.IconPadding = 10;
            this.btnPerm.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPerm.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnPerm.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnPerm.IconSize = 25;
            this.btnPerm.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnPerm.IdleBorderRadius = 1;
            this.btnPerm.IdleBorderThickness = 1;
            this.btnPerm.IdleFillColor = System.Drawing.Color.Blue;
            this.btnPerm.IdleIconLeftImage = null;
            this.btnPerm.IdleIconRightImage = null;
            this.btnPerm.IndicateFocus = false;
            this.btnPerm.Location = new System.Drawing.Point(403, 120);
            this.btnPerm.Name = "btnPerm";
            this.btnPerm.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnPerm.OnDisabledState.BorderRadius = 1;
            this.btnPerm.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPerm.OnDisabledState.BorderThickness = 1;
            this.btnPerm.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnPerm.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnPerm.OnDisabledState.IconLeftImage = null;
            this.btnPerm.OnDisabledState.IconRightImage = null;
            this.btnPerm.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnPerm.onHoverState.BorderRadius = 1;
            this.btnPerm.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPerm.onHoverState.BorderThickness = 1;
            this.btnPerm.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnPerm.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnPerm.onHoverState.IconLeftImage = null;
            this.btnPerm.onHoverState.IconRightImage = null;
            this.btnPerm.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnPerm.OnIdleState.BorderRadius = 1;
            this.btnPerm.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPerm.OnIdleState.BorderThickness = 1;
            this.btnPerm.OnIdleState.FillColor = System.Drawing.Color.Blue;
            this.btnPerm.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnPerm.OnIdleState.IconLeftImage = null;
            this.btnPerm.OnIdleState.IconRightImage = null;
            this.btnPerm.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnPerm.OnPressedState.BorderRadius = 1;
            this.btnPerm.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPerm.OnPressedState.BorderThickness = 1;
            this.btnPerm.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnPerm.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnPerm.OnPressedState.IconLeftImage = null;
            this.btnPerm.OnPressedState.IconRightImage = null;
            this.btnPerm.Size = new System.Drawing.Size(166, 48);
            this.btnPerm.TabIndex = 15;
            this.btnPerm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPerm.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnPerm.TextMarginLeft = 0;
            this.btnPerm.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnPerm.UseDefaultRadiusAndThickness = true;
            this.btnPerm.Click += new System.EventHandler(this.bunifuButton1_Click_1);
            // 
            // btnReport
            // 
            this.btnReport.AllowAnimations = true;
            this.btnReport.AllowMouseEffects = true;
            this.btnReport.AllowToggling = false;
            this.btnReport.AnimationSpeed = 200;
            this.btnReport.AutoGenerateColors = false;
            this.btnReport.AutoRoundBorders = false;
            this.btnReport.AutoSizeLeftIcon = true;
            this.btnReport.AutoSizeRightIcon = true;
            this.btnReport.BackColor = System.Drawing.Color.Transparent;
            this.btnReport.BackColor1 = System.Drawing.Color.Blue;
            this.btnReport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReport.BackgroundImage")));
            this.btnReport.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnReport.ButtonText = "REPORTES";
            this.btnReport.ButtonTextMarginLeft = 0;
            this.btnReport.ColorContrastOnClick = 45;
            this.btnReport.ColorContrastOnHover = 45;
            this.btnReport.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.btnReport.CustomizableEdges = borderEdges4;
            this.btnReport.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnReport.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnReport.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnReport.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnReport.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnReport.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnReport.ForeColor = System.Drawing.Color.White;
            this.btnReport.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnReport.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnReport.IconMarginLeft = 11;
            this.btnReport.IconPadding = 10;
            this.btnReport.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReport.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnReport.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnReport.IconSize = 25;
            this.btnReport.IdleBorderColor = System.Drawing.Color.Yellow;
            this.btnReport.IdleBorderRadius = 1;
            this.btnReport.IdleBorderThickness = 1;
            this.btnReport.IdleFillColor = System.Drawing.Color.Blue;
            this.btnReport.IdleIconLeftImage = null;
            this.btnReport.IdleIconRightImage = null;
            this.btnReport.IndicateFocus = true;
            this.btnReport.Location = new System.Drawing.Point(601, 120);
            this.btnReport.Name = "btnReport";
            this.btnReport.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnReport.OnDisabledState.BorderRadius = 1;
            this.btnReport.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnReport.OnDisabledState.BorderThickness = 1;
            this.btnReport.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnReport.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnReport.OnDisabledState.IconLeftImage = null;
            this.btnReport.OnDisabledState.IconRightImage = null;
            this.btnReport.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnReport.onHoverState.BorderRadius = 1;
            this.btnReport.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnReport.onHoverState.BorderThickness = 1;
            this.btnReport.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnReport.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnReport.onHoverState.IconLeftImage = null;
            this.btnReport.onHoverState.IconRightImage = null;
            this.btnReport.OnIdleState.BorderColor = System.Drawing.Color.Yellow;
            this.btnReport.OnIdleState.BorderRadius = 1;
            this.btnReport.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnReport.OnIdleState.BorderThickness = 1;
            this.btnReport.OnIdleState.FillColor = System.Drawing.Color.Blue;
            this.btnReport.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnReport.OnIdleState.IconLeftImage = null;
            this.btnReport.OnIdleState.IconRightImage = null;
            this.btnReport.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnReport.OnPressedState.BorderRadius = 1;
            this.btnReport.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnReport.OnPressedState.BorderThickness = 1;
            this.btnReport.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnReport.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnReport.OnPressedState.IconLeftImage = null;
            this.btnReport.OnPressedState.IconRightImage = null;
            this.btnReport.Size = new System.Drawing.Size(166, 48);
            this.btnReport.TabIndex = 16;
            this.btnReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReport.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnReport.TextMarginLeft = 0;
            this.btnReport.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnReport.UseDefaultRadiusAndThickness = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.cERRARSESIONToolStripMenuItem);
            this.bunifuGradientPanel1.Controls.Add(this.btnReport);
            this.bunifuGradientPanel1.Controls.Add(this.btnEstu);
            this.bunifuGradientPanel1.Controls.Add(this.btnPerm);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(906, 264);
            this.bunifuGradientPanel1.TabIndex = 17;
            this.bunifuGradientPanel1.Click += new System.EventHandler(this.bunifuGradientPanel1_Click);
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.AutoSizeHeight = true;
            this.bunifuPictureBox1.BorderRadius = 50;
            this.bunifuPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuPictureBox1.Image")));
            this.bunifuPictureBox1.IsCircle = true;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(140, 0);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(100, 100);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 17;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            // 
            // FrmJEFATURA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 264);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmJEFATURA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADMINISTRACION JEFATURA";
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton cERRARSESIONToolStripMenuItem;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnEstu;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnPerm;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnReport;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
    }
}