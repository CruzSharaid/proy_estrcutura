﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    class NodoArbol_ASISTENCIA
    {
        string Id_asist;
        DateTime Fecha_asist;
        string Estado_asist;
        string Cod_est;
        string Cod_asig;
        NodoArbol_ASISTENCIA Enl_izq;
        NodoArbol_ASISTENCIA Enl_der;

        public NodoArbol_ASISTENCIA(string id_asist, string cod_est, string cod_asig, DateTime fecha_asist, string estado_asist, NodoArbol_ASISTENCIA enl_izq, NodoArbol_ASISTENCIA enl_der)
        {
            Id_asist = id_asist;
            Cod_est = cod_est;
            Cod_asig = cod_asig;
            Fecha_asist = fecha_asist;
            Estado_asist = estado_asist;
            Enl_izq = enl_izq;
            Enl_der = enl_der;
        }

        public string id_asist { get => Id_asist; set => Id_asist = value; }
        public string cod_est { get => Cod_est; set => Cod_est = value; }
        public string cod_asig { get => Cod_asig; set => Cod_asig = value; }
        public DateTime fecha_asist { get => Fecha_asist; set => Fecha_asist = value; }
        public string estado_asist { get => Estado_asist; set => Estado_asist = value; }
        internal NodoArbol_ASISTENCIA enl_izq { get => Enl_izq; set => Enl_izq = value; }
        internal NodoArbol_ASISTENCIA enl_der { get => Enl_der; set => Enl_der = value; }
    }
}