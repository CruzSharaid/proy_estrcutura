﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; // Importar para manejo de archivos
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.Diagnostics;

namespace p
{
    public partial class FrmAPROBAR_PERMISO : Form
    {
        private int idUsuarioActual;
        private int codJefActual;
        Cola_Permiso colaPermisos = new Cola_Permiso();
        public FrmAPROBAR_PERMISO(int idUsuarioActual)
        {
            InitializeComponent();
            this.idUsuarioActual = idUsuarioActual;

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FrmAPROBAR_PERMISO_Load(object sender, EventArgs e)
        {
            ObtenerCodJefActual();
            CargarPermisosPendientes();
            CargarPermisosEstado();
            dgvPermEspera.CellContentClick += dgvPermEspera_CellContentClick;
            dgvPermAcep.CellContentClick += dgvPermAcep_CellContentClick;
            dgvPermAcep.CellFormatting += dgvPermAcep_CellFormatting;
            dgvPermEspera.AllowUserToAddRows = false;
            dgvPermAcep.AllowUserToAddRows = false;
            ConfigurarDataGridViews();


        }
        private void ConfigurarDataGridViews()
        {
            // Configurar dgvPermEspera: todas las columnas en modo solo lectura excepto acciones, aprobar, rechazar
            foreach (DataGridViewColumn column in dgvPermEspera.Columns)
            {
                if (column.Name != "Acciones" && column.Name != "Aprobar" && column.Name != "Rechazar")
                {
                    column.ReadOnly = true;
                }
            }

            // Configurar dgvPermAcep: todas las columnas en modo solo lectura excepto acciones
            foreach (DataGridViewColumn column in dgvPermAcep.Columns)
            {
                if (column.Name != "Acciones")
                {
                    column.ReadOnly = true;
                }
            }
        }
        private void ObtenerCodJefActual()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();

                    string consultaCodJef = @"SELECT j.cod_jef 
                                              FROM usuarios u
                                              JOIN jefatura j ON u.id = j.cod_usuario
                                              WHERE u.id = @id_usuario";

                    NpgsqlCommand cmdCodJef = new NpgsqlCommand(consultaCodJef, conexion);
                    cmdCodJef.Parameters.AddWithValue("@id_usuario", idUsuarioActual);
                    object resultado = cmdCodJef.ExecuteScalar();

                    if (resultado != null)
                    {
                        codJefActual = Convert.ToInt32(resultado);
                    }
                    else
                    {
                        MessageBox.Show("Código de jefatura no encontrado. No se puede cargar permisos.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al obtener el código del jefe: " + ex.Message);
                }
            }
        }
        private void CargarPermisosPendientes()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();

                    string consultaPermisos = @"
            SELECT 
                   p.id_per AS ""ID PERMISO"",
                   p.cod_est AS ""CÓDIGO DEL ESTUDIANTE"",
                   CONCAT(e.nombre_est, ' ', e.apat_est, ' ', e.amat_est) AS ""NOMBRE COMPLETO"",
                   s.descrip_sem AS ""SEMESTRE"",
                   p.fecha_sol_per AS ""FECHA DE SOLICITUD"",
                   p.fecha_permitida AS ""FECHA DE PERMISO"",
                   CASE 
                        WHEN p.cod_asig IS NULL THEN 'Todo el Día'
                        ELSE a.nom_asig
                   END AS ""ASIGNATURA"",
                   p.motivo_per AS ""MOTIVO DEL PERMISO"",
                   p.comprb AS ""COMPROBANTE""
            FROM permiso p
            JOIN estudiante e ON p.cod_est = e.cod_est
            JOIN semestre s ON e.cod_sem = s.cod_sem
            LEFT JOIN asignatura a ON p.cod_asig = a.cod_asig
            WHERE p.cod_jef = @cod_jef AND p.estado_per = 'Pendiente'";

                    NpgsqlCommand cmdPermisos = new NpgsqlCommand(consultaPermisos, conexion);
                    cmdPermisos.Parameters.AddWithValue("@cod_jef", codJefActual);

                    NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(cmdPermisos);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvPermEspera.DataSource = dt;

                    // Ocultar la columna COMPROBANTE
                    if (dgvPermEspera.Columns.Contains("COMPROBANTE"))
                    {
                        dgvPermEspera.Columns["COMPROBANTE"].Visible = false;
                    }

                    dgvPermEspera.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    // Verificar si la columna "Descargar Comprobante" ya existe
                    if (!dgvPermEspera.Columns.Contains("DescargarComprobante"))
                    {
                        DataGridViewButtonColumn btnDescargar = new DataGridViewButtonColumn();
                        btnDescargar.Name = "DescargarComprobante";
                        btnDescargar.HeaderText = "Acciones";
                        btnDescargar.Text = "Descargar Comprobante";
                        btnDescargar.UseColumnTextForButtonValue = true;
                        dgvPermEspera.Columns.Add(btnDescargar);
                    }

                    // Agregar columnas para aprobar y rechazar el permiso si no están añadidas
                    if (!dgvPermEspera.Columns.Contains("Aprobar"))
                    {
                        DataGridViewButtonColumn btnAprobar = new DataGridViewButtonColumn();
                        btnAprobar.Name = "Aprobar";
                        btnAprobar.Text = "Aprobar";
                        btnAprobar.UseColumnTextForButtonValue = true;
                        btnAprobar.DefaultCellStyle.BackColor = Color.LightGreen;
                        dgvPermEspera.Columns.Add(btnAprobar);
                    }

                    if (!dgvPermEspera.Columns.Contains("Rechazar"))
                    {
                        DataGridViewButtonColumn btnRechazar = new DataGridViewButtonColumn();
                        btnRechazar.Name = "Rechazar";
                        btnRechazar.Text = "Rechazar";
                        btnRechazar.UseColumnTextForButtonValue = true;
                        btnRechazar.DefaultCellStyle.BackColor = Color.LightCoral;
                        dgvPermEspera.Columns.Add(btnRechazar);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar los permisos: " + ex.Message);
                }
            }
        }

        private void CargarPermisosEstado()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();

                    string consulta = @"
                SELECT 
                       p.id_per AS ""ID"",
                       p.estado_per AS ""ESTADO DEL PERMISO"", 
                       p.cod_est AS ""CÓDIGO DEL ESTUDIANTE"",
                       CONCAT(e.nombre_est, ' ', e.apat_est, ' ', e.amat_est) AS ""NOMBRE COMPLETO"",
                       s.descrip_sem AS ""SEMESTRE"",
                       p.fecha_permitida AS ""FECHA DE PERMISO"",
                       CASE 
                            WHEN p.cod_asig IS NULL THEN 'Todo el Día'
                            ELSE a.nom_asig
                       END AS ""ASIGNATURA"",
                       p.motivo_per AS ""MOTIVO DEL PERMISO""
                FROM permiso p
                JOIN estudiante e ON p.cod_est = e.cod_est
                JOIN semestre s ON e.cod_sem = s.cod_sem
                LEFT JOIN asignatura a ON p.cod_asig = a.cod_asig
                WHERE p.estado_per IN ('Aprobado', 'Rechazado') AND p.cod_jef = @cod_jef";

                    NpgsqlCommand cmdPermisos = new NpgsqlCommand(consulta, conexion);
                    cmdPermisos.Parameters.AddWithValue("@cod_jef", codJefActual);

                    NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(cmdPermisos);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvPermAcep.DataSource = dt;

                    dgvPermAcep.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    if (!dgvPermAcep.Columns.Contains("Acciones"))
                    {
                        DataGridViewButtonColumn btnDescargar = new DataGridViewButtonColumn();
                        btnDescargar.Name = "Acciones";
                        btnDescargar.Text = "Descargar Comprobante";
                        btnDescargar.UseColumnTextForButtonValue = true;
                        dgvPermAcep.Columns.Add(btnDescargar);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar el estado de los permisos: " + ex.Message);
                }
            }
        }





        private void dgvPermEspera_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          if (e.RowIndex >= 0)
    {
        int idPermiso = Convert.ToInt32(dgvPermEspera.Rows[e.RowIndex].Cells["ID PERMISO"].Value);

        // Verificar si la columna clickeada es la de descargar el comprobante
        if (dgvPermEspera.Columns[e.ColumnIndex].Name == "DescargarComprobante")
        {
            DescargarComprobante(idPermiso);
        }
        else if (dgvPermEspera.Columns[e.ColumnIndex].Name == "Aprobar")
        {
            ActualizarEstadoPermiso(idPermiso, "Aprobado", e.RowIndex);
        }
        else if (dgvPermEspera.Columns[e.ColumnIndex].Name == "Rechazar")
        {
            ActualizarEstadoPermiso(idPermiso, "Rechazado", e.RowIndex);
        }
    }
        }
        // Descargar y ver el comprobante del permiso seleccionado
        private void dgvPermEspera_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void GenerarPDFPermiso(int idPermiso, string estadoPermiso)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string consulta = @"
SELECT 
    CONCAT(e.nombre_est, ' ', e.apat_est, ' ', e.amat_est) AS nombre_completo,
    s.descrip_sem AS semestre,
    p.cod_est AS codigo_est,
    p.motivo_per AS motivo,
    p.fecha_permitida AS fecha_desde,
    p.fecha_permitida AS fecha_hasta,
    p.fecha_sol_per AS fecha_solicitud,
    CASE 
        WHEN p.cod_asig IS NULL THEN 'Todo el Día'
        ELSE a.nom_asig
    END AS asignatura,
    c.descrip_carr AS nombre_carrera
FROM permiso p
JOIN estudiante e ON p.cod_est = e.cod_est
JOIN semestre s ON e.cod_sem = s.cod_sem
LEFT JOIN asignatura a ON p.cod_asig = a.cod_asig
JOIN carrera c ON e.cod_carr = c.cod_carr
WHERE p.id_per = @id_per";

                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@id_per", idPermiso);

                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Datos del permiso
                            string nombreCompleto = reader["nombre_completo"].ToString();
                            string semestre = reader["semestre"].ToString();
                            string codigoEst = reader["codigo_est"].ToString();
                            string motivo = reader["motivo"].ToString();
                            DateTime fechaDesde = Convert.ToDateTime(reader["fecha_desde"]);
                            DateTime fechaHasta = Convert.ToDateTime(reader["fecha_hasta"]);
                            DateTime fechaSolicitud = Convert.ToDateTime(reader["fecha_solicitud"]);
                            string asignatura = reader["asignatura"].ToString();
                            string nombreCarrera = reader["nombre_carrera"].ToString();

                            // Crear PDF
                            string fileName = $"Permiso_{idPermiso}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
                            string rutaPdf = Path.Combine(@"C:\Users\Public\PERMIS", fileName);

                            using (FileStream stream = new FileStream(rutaPdf, FileMode.Create))
                            {
                                Document doc = new Document(PageSize.A4);
                                PdfWriter.GetInstance(doc, stream);
                                doc.Open();
                                // Ruta al archivo del logo
                                string rutaLogo = @"C:\Users\carlo\Downloads\EMI.png"; // Cambiá esta ruta según dónde esté tu logo

                                if (File.Exists(rutaLogo))
                                {
                                    // Crear la imagen del logo
                                    iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(rutaLogo);

                                    // Ajustar el tamaño del logo
                                    logo.ScaleToFit(100f, 100f); // Cambiá las dimensiones según necesites

                                    // Posicionar el logo en la esquina superior izquierda
                                    logo.SetAbsolutePosition(doc.LeftMargin, doc.PageSize.Height - logo.ScaledHeight - doc.TopMargin);

                                    // Añadir el logo al documento
                                    doc.Add(logo);
                                }
                                else
                                {
                                    MessageBox.Show($"No se encontró el logo en la ruta especificada: {rutaLogo}", "Advertencia");
                                }

                                // Añadir encabezado
                                doc.Add(new Paragraph(" "));
                                doc.Add(new Paragraph("PAPELETA DE PERMISO PARA ESTUDIANTES", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16, iTextSharp.text.Font.BOLD)) { Alignment = Element.ALIGN_CENTER });
                                doc.Add(new Paragraph(" "));
                                doc.Add(new Paragraph($"N° PAPELETA: {idPermiso}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD)) { Alignment = Element.ALIGN_RIGHT });

                                doc.Add(new Paragraph(" "));

                                // Carrera y nombre del estudiante
                                doc.Add(new Paragraph("CARRERA:", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                PdfPTable tableCarreraNombre = new PdfPTable(1);
                                tableCarreraNombre.WidthPercentage = 100;

                                PdfPCell cellCarrera = new PdfPCell(new Phrase(nombreCarrera, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellCarrera.Border = iTextSharp.text.Rectangle.BOX;
                                tableCarreraNombre.AddCell(cellCarrera);

                                doc.Add(tableCarreraNombre);

                                doc.Add(new Paragraph("NOMBRES Y APELLIDOS:", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                PdfPTable tableNombre = new PdfPTable(1);
                                tableNombre.WidthPercentage = 100;

                                PdfPCell cellNombre = new PdfPCell(new Phrase(nombreCompleto, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellNombre.Border = iTextSharp.text.Rectangle.BOX;
                                tableNombre.AddCell(cellNombre);

                                doc.Add(tableNombre);

                                // Información del semestre, código y fecha de solicitud
                                doc.Add(new Paragraph(" ")); // Espaciado adicional
                                PdfPTable tableInfoEstudiante = new PdfPTable(6); // 6 columnas
                                tableInfoEstudiante.WidthPercentage = 100;

                                PdfPCell cellSemestreLabel = new PdfPCell(new Phrase("SEMESTRE:", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL))) { Border = iTextSharp.text.Rectangle.NO_BORDER };
                                tableInfoEstudiante.AddCell(cellSemestreLabel);
                                PdfPCell cellSemestre = new PdfPCell(new Phrase(semestre, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellSemestre.Border = iTextSharp.text.Rectangle.BOX;
                                tableInfoEstudiante.AddCell(cellSemestre);

                                PdfPCell cellCodigoLabel = new PdfPCell(new Phrase("CÓDIGO:", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL))) { Border = iTextSharp.text.Rectangle.NO_BORDER };
                                tableInfoEstudiante.AddCell(cellCodigoLabel);
                                PdfPCell cellCodigo = new PdfPCell(new Phrase(codigoEst, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellCodigo.Border = iTextSharp.text.Rectangle.BOX;
                                tableInfoEstudiante.AddCell(cellCodigo);

                                PdfPCell cellFechaSolicitudLabel = new PdfPCell(new Phrase("FECHA SOLICITUD:", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL))) { Border = iTextSharp.text.Rectangle.NO_BORDER };
                                tableInfoEstudiante.AddCell(cellFechaSolicitudLabel);
                                PdfPCell cellFechaSolicitud = new PdfPCell(new Phrase(fechaSolicitud.ToString("dd/MM/yyyy"), new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellFechaSolicitud.Border = iTextSharp.text.Rectangle.BOX;
                                tableInfoEstudiante.AddCell(cellFechaSolicitud);

                                // Añadir la tabla al documento
                                doc.Add(tableInfoEstudiante);

                                doc.Add(new Paragraph(" "));
                                doc.Add(new Paragraph("MOTIVO DEL PERMISO:", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD)));

                                // Crear una tabla con motivos y un espacio para "OTROS"
                                PdfPTable tableMotivos = new PdfPTable(2); // 2 columnas
                                tableMotivos.WidthPercentage = 100;
                                tableMotivos.SpacingBefore = 10f;

                                // Primera fila: Por Salud y Por Pensiones
                                tableMotivos.AddCell(CreateCheckboxCell("POR SALUD", motivo == "Por Salud"));
                                tableMotivos.AddCell(CreateCheckboxCell("POR PENSIONES", motivo == "Por Pensiones"));

                                // Segunda fila: Por Atraso y Familiares
                                tableMotivos.AddCell(CreateCheckboxCell("POR ATRASO", motivo == "Por Atraso"));
                                tableMotivos.AddCell(CreateCheckboxCell("FAMILIARES", motivo == "Familiares"));

                                // Tercera fila: Otros con campo para especificar
                                PdfPCell cellOtros = new PdfPCell();
                                cellOtros.Border = iTextSharp.text.Rectangle.NO_BORDER;
                                Phrase otrosPhrase = new Phrase();
                                otrosPhrase.Add(new Chunk("[ ] OTROS: ", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                if (!new[] { "Por Salud", "Por Pensiones", "Por Atraso", "Familiares" }.Contains(motivo))
                                {
                                    otrosPhrase = new Phrase();
                                    otrosPhrase.Add(new Chunk("[X] OTROS: ", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                    otrosPhrase.Add(new Chunk(motivo, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL, BaseColor.BLUE)));
                                }
                                cellOtros.AddElement(otrosPhrase);
                                tableMotivos.AddCell(cellOtros);

                                // Añadir la tabla al documento
                                doc.Add(tableMotivos);

                                // Función auxiliar para crear celdas de checkbox
                                PdfPCell CreateCheckboxCell(string label, bool isChecked)
                                {
                                    PdfPCell cell = new PdfPCell();
                                    cell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                                    Phrase phrase = new Phrase();
                                    if (isChecked)
                                    {
                                        phrase.Add(new Chunk("[X] ", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                    }
                                    else
                                    {
                                        phrase.Add(new Chunk("[ ] ", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                    }
                                    phrase.Add(new Chunk(label, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                    cell.AddElement(phrase);
                                    return cell;
                                }

                          

                                // Fechas
                                doc.Add(new Paragraph(" "));
                                doc.Add(new Paragraph($"FEHA VALIDA DEL PERMISO: {fechaHasta:dd 'de' MMMM 'de' yyyy}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));

                                // Estado
                                doc.Add(new Paragraph(" "));
                                doc.Add(new Paragraph($"ESTADO DEL PERMISO: {estadoPermiso.ToUpper()}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD)));

                                // Firma y sello
                                // Firma y sello
                                doc.Add(new Paragraph(" ")); // Espacio antes de la tabla
                                PdfPTable tableFirmaSello = new PdfPTable(2);
                                tableFirmaSello.WidthPercentage = 100;
                                doc.Add(new Paragraph(" ")); //
                                doc.Add(new Paragraph(" ")); //

                                // Celda para la línea de la firma del estudiante
                                PdfPCell cellLineaEstudiante = new PdfPCell(new Phrase("")); // Celda vacía
                                cellLineaEstudiante.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER; // Solo el borde inferior
                                cellLineaEstudiante.BorderWidth = 1f; // Grosor de la línea
                                cellLineaEstudiante.HorizontalAlignment = Element.ALIGN_CENTER;
                                tableFirmaSello.AddCell(cellLineaEstudiante);

                                // Celda para la línea de la firma del jefe de carrera
                                PdfPCell cellLineaJefe = new PdfPCell(new Phrase("")); // Celda vacía
                                cellLineaJefe.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER; // Solo el borde inferior
                                cellLineaJefe.BorderWidth = 1f; // Grosor de la línea
                                cellLineaJefe.HorizontalAlignment = Element.ALIGN_CENTER;
                                tableFirmaSello.AddCell(cellLineaJefe);

                                // Celda para la firma del estudiante
                                PdfPCell cellFirmaEstudiante = new PdfPCell(new Phrase("FIRMA DEL ESTUDIANTE", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellFirmaEstudiante.Border = iTextSharp.text.Rectangle.NO_BORDER; // Sin bordes para el texto
                                cellFirmaEstudiante.HorizontalAlignment = Element.ALIGN_CENTER;
                                tableFirmaSello.AddCell(cellFirmaEstudiante);

                                // Celda para el sello y firma del jefe de carrera
                                PdfPCell cellFirmaJefe = new PdfPCell(new Phrase("SELLO Y FIRMA DEL JEFE DE CARRERA", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
                                cellFirmaJefe.Border = iTextSharp.text.Rectangle.NO_BORDER; // Sin bordes para el texto
                                cellFirmaJefe.HorizontalAlignment = Element.ALIGN_CENTER;
                                tableFirmaSello.AddCell(cellFirmaJefe);

                                // Añadir la tabla al documento (UNA SOLA VEZ)
                                doc.Add(tableFirmaSello);


                                doc.Close();
                            }

                            // Intentar abrir el archivo generado
                            try
                            {
                                Process.Start(new ProcessStartInfo
                                {
                                    FileName = rutaPdf,
                                    UseShellExecute = true
                                });
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"El archivo PDF se generó correctamente, pero no se pudo abrir automáticamente. Por favor, ábrelo manualmente desde: {rutaPdf}. Error: {ex.Message}");
                            }

                            // Confirmar al usuario que el archivo PDF se creó correctamente
                            MessageBox.Show($"PDF generado correctamente: {rutaPdf}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al generar el PDF: {ex.Message}", "Error");
                }
            }
        }


        // Función para guardar los detalles del documento en la base de datos
        private void GuardarDetallesDocumento(int idPermiso, string rutaPdf)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string consulta = "INSERT INTO documento_permiso (id_per, ruta_pdf, fecha_creacion) VALUES (@id_per, @ruta_pdf, @fecha_creacion)";
                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@id_per", idPermiso);
                    cmd.Parameters.AddWithValue("@ruta_pdf", rutaPdf);
                    cmd.Parameters.AddWithValue("@fecha_creacion", DateTime.Now);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al guardar los detalles del documento en la base de datos: {ex.Message}", "Error");
                }
            }
        }


        private void ActualizarEstadoPermiso(int idPermiso, string nuevoEstado, int rowIndex)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string consulta = "UPDATE permiso SET estado_per = @estado_per WHERE id_per = @id_per AND cod_jef = @cod_jef";
                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@estado_per", nuevoEstado);
                    cmd.Parameters.AddWithValue("@id_per", idPermiso);
                    cmd.Parameters.AddWithValue("@cod_jef", codJefActual);

                    int filasAfectadas = cmd.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        MessageBox.Show($"Permiso {idPermiso} ha sido {nuevoEstado.ToLower()} correctamente.");

                        // Generar PDF después de aprobar o rechazar
                        GenerarPDFPermiso(idPermiso, nuevoEstado);

                        // Desencolar el permiso correspondiente
                        colaPermisos.Desencolar();

                        // Mover la fila del `dgvPermEspera` al `dgvPermAcep`
                        DataRow row = ((DataTable)dgvPermEspera.DataSource).Rows[rowIndex];
                        DataTable dtAccepted = dgvPermAcep.DataSource as DataTable;

                        if (dtAccepted == null)
                        {
                            // Crear una nueva tabla con las columnas necesarias
                            dtAccepted = new DataTable();
                            dtAccepted.Columns.Add("ID", typeof(int));
                            dtAccepted.Columns.Add("ESTADO DEL PERMISO", typeof(string));
                            dtAccepted.Columns.Add("CÓDIGO DEL ESTUDIANTE", typeof(string));
                            dtAccepted.Columns.Add("NOMBRE COMPLETO", typeof(string));
                            dtAccepted.Columns.Add("SEMESTRE", typeof(string));
                            dtAccepted.Columns.Add("FECHA DE PERMISO", typeof(DateTime));
                            dtAccepted.Columns.Add("ASIGNATURA", typeof(string));
                            dtAccepted.Columns.Add("MOTIVO DEL PERMISO", typeof(string));
                            dgvPermAcep.DataSource = dtAccepted;
                        }

                        // Crear una nueva fila con las columnas necesarias
                        DataRow newRow = dtAccepted.NewRow();
                        newRow["ID"] = row["ID PERMISO"];
                        newRow["ESTADO DEL PERMISO"] = nuevoEstado;
                        newRow["CÓDIGO DEL ESTUDIANTE"] = row["CÓDIGO DEL ESTUDIANTE"];
                        newRow["NOMBRE COMPLETO"] = row["NOMBRE COMPLETO"];
                        newRow["SEMESTRE"] = row["SEMESTRE"];
                        newRow["FECHA DE PERMISO"] = row["FECHA DE PERMISO"];
                        newRow["ASIGNATURA"] = row["ASIGNATURA"];
                        newRow["MOTIVO DEL PERMISO"] = row["MOTIVO DEL PERMISO"];

                        // Añadir la fila a la tabla de permisos aceptados
                        dtAccepted.Rows.Add(newRow);

                        // Eliminar la fila de la tabla de permisos pendientes
                        ((DataTable)dgvPermEspera.DataSource).Rows.Remove(row);
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el estado del permiso. Verifique que el jefe tenga permiso para aprobar/rechazar este permiso.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar el estado del permiso: " + ex.Message);
                }
            }
        }



        private void DescargarComprobante(int idPermiso)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string consulta = "SELECT comprb FROM permiso WHERE id_per = @id_per";
                    NpgsqlCommand cmd = new NpgsqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@id_per", idPermiso);

                    object resultado = cmd.ExecuteScalar();

                    // Verificar si el resultado es nulo o DBNull
                    if (resultado == DBNull.Value || resultado == null)
                    {
                        MessageBox.Show("No hay comprobante disponible para este permiso.");
                        return;
                    }

                    // Verificar si el resultado es un byte[]
                    if (resultado is byte[] comprobanteBytes)
                    {
                        // Definir la ruta de guardado del archivo
                        string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), $"comprobante_{idPermiso}.pdf");

                        // Guardar el archivo en el sistema
                        File.WriteAllBytes(filePath, comprobanteBytes);

                        // Confirmar al usuario que el archivo se descargó correctamente
                        MessageBox.Show($"Comprobante descargado correctamente en: {filePath}");

                        // Intentar abrir el archivo descargado utilizando un método más confiable
                        try
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo()
                            {
                                FileName = filePath,
                                UseShellExecute = true
                            });
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"El archivo se ha guardado correctamente pero no se pudo abrir automáticamente. Por favor, ábrelo manualmente desde: {filePath}. Error: {ex.Message}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("El comprobante no tiene un formato válido.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al descargar el comprobante: {ex.Message}", "Error");
                }
            }
        }




        private void dgvPermAcep_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvPermAcep.Columns[e.ColumnIndex].Name == "Acciones")       
            {
                int idPermiso = Convert.ToInt32(dgvPermAcep.Rows[e.RowIndex].Cells["ID PERMISO"].Value);
                DescargarComprobante(idPermiso);
            }
        }
        private void dgvPermAcep_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // Asegurarse de que estamos en una fila válida y en la columna "ESTADO DEL PERMISO"
            if (e.RowIndex >= 0 && dgvPermAcep.Columns[e.ColumnIndex].Name == "ESTADO DEL PERMISO")
            {
                var cellValue = dgvPermAcep.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;

                if (cellValue != null)
                {
                    string estado = cellValue.ToString();

                    // Cambiar el color de fondo según el estado del permiso
                    if (estado == "Aprobado")
                    {
                        dgvPermAcep.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightGreen;
                    }
                    else if (estado == "Rechazado")
                    {
                        dgvPermAcep.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightCoral;
                    }
                    else {
                        dgvPermAcep.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightYellow;
                    }
                }
            }
        }
        private void btnVolver_Click(object sender, EventArgs e)
        {
            FrmJEFATURA opcion = new FrmJEFATURA(idUsuarioActual);
            opcion.Show();
            this.Hide();
        }

        private void dgvPermiRechazad_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnEnviarNotiEncar_Click(object sender, EventArgs e)
        {

        }

        private void btnNotificar_Click(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click_1(object sender, EventArgs e)
        {
          
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuGradientPanel1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click_2(object sender, EventArgs e)
        {
            FrmJEFATURA opcion = new FrmJEFATURA(idUsuarioActual);
            opcion.Show();
            this.Hide();
        }
    }
}
