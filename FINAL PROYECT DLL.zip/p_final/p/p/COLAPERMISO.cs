﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    class Cola_Permiso
    {
        NodoCola_PERMISO Frente;
        NodoCola_PERMISO Final;
        NodoCola_PERMISO nuevo;

        public Cola_Permiso()
        {
            Frente = null;
            Final = null;
            nuevo = null;
        }

        public void crear_nodo(string id_permiso, string cod_est, DateTime fech_s_a_per, string motivo_per, string cod_asig, string estado_per, byte[] comprb_per, string id_jefatura)
        {
            nuevo = new NodoCola_PERMISO(id_permiso, cod_est, fech_s_a_per, motivo_per, cod_asig, estado_per, comprb_per, id_jefatura, null);

        }

        public void Encolar(string id_permiso, string cod_est, DateTime fech_s_a_per, string motivo_per, string cod_asig, string estado_per, byte[] comprb_per, string id_jefatura)
        {
            crear_nodo(id_permiso, cod_est, fech_s_a_per, motivo_per, cod_asig, estado_per, comprb_per, id_jefatura);
            if (Frente == null)
            {
                Frente = nuevo;
                Final = nuevo;
            }
            else
            {
                Final.enl = nuevo;
                Final = nuevo;
            }
        }

        public NodoCola_PERMISO Desencolar()
        {
            if (Frente != null)
            {
                NodoCola_PERMISO temp = Frente;
                Frente = Frente.enl;
                if (Frente == null)
                {
                    Final = null;
                }
                return temp;
            }
            else
            {
                return null;
            }
        }

        public bool ColaVacia()
        {
            return Frente == null;
        }

        public NodoCola_PERMISO Devolver_Frente()
        {
            return Frente;
        }
    }
}