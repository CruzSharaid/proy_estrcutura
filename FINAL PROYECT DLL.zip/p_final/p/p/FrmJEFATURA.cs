﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Npgsql;
using System.IO;
namespace p
{
    public partial class FrmJEFATURA : Form
    {
        private int usuarioId;

        public FrmJEFATURA(int usuarioId)
        {
            InitializeComponent();
            this.usuarioId = usuarioId;
     
        }

        private void cERRARSESIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 opcion = new Form1();
            opcion.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmINGRESAR_ESTUDIANTE opcion1 = new FrmINGRESAR_ESTUDIANTE(usuarioId);
            opcion1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmAPROBAR_PERMISO opcion2 = new FrmAPROBAR_PERMISO(usuarioId);
            opcion2.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }

        private void cERRARSESIONToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form1 opcion = new Form1();
            opcion.Show();
            this.Hide();
        }

        private void btnEstu_Click(object sender, EventArgs e)
        {
            FrmINGRESAR_ESTUDIANTE opcion1 = new FrmINGRESAR_ESTUDIANTE(usuarioId);
            opcion1.Show();
            this.Hide();
        }

        private void btnPerm_Click(object sender, EventArgs e)
        {
            FrmAPROBAR_PERMISO opcion2 = new FrmAPROBAR_PERMISO(usuarioId);
            opcion2.Show();
            this.Hide();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            FrmINGRESAR_ESTUDIANTE opcion1 = new FrmINGRESAR_ESTUDIANTE(usuarioId);
            opcion1.Show();
            this.Hide();
        }

        private void bunifuButton1_Click_1(object sender, EventArgs e)
        {
            FrmAPROBAR_PERMISO opcion2 = new FrmAPROBAR_PERMISO(usuarioId);
            opcion2.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            GenerarPDFPermisos();
        }

        private void GenerarPDFPermisos()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";

            using (NpgsqlConnection conexion = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();

                    string consulta = @"
            SELECT 
                   p.id_per AS ""ID PERMISO"",
                   p.estado_per AS ""ESTADO DEL PERMISO"", 
                   p.cod_est AS ""CÓDIGO DEL ESTUDIANTE"",
                   CONCAT(e.nombre_est, ' ', e.apat_est, ' ', e.amat_est) AS ""NOMBRE COMPLETO"",
                   c.descrip_carr AS ""CARRERA"",
                   s.descrip_sem AS ""SEMESTRE"",
                   p.fecha_sol_per AS ""FECHA DE SOLICITUD DEL PERMISO"", 
                   p.motivo_per AS ""MOTIVO DEL PERMISO""
            FROM permiso p
            JOIN estudiante e ON p.cod_est = e.cod_est
            JOIN carrera c ON e.cod_carr = c.cod_carr
            JOIN semestre s ON e.cod_sem = s.cod_sem
            WHERE p.estado_per IN ('Aprobado', 'Rechazado')";

                    using (NpgsqlCommand cmdPermisos = new NpgsqlCommand(consulta, conexion))
                    {
                        cmdPermisos.Parameters.AddWithValue("@cod_jef", usuarioId); // asegúrate de que codJefActual tenga el valor correcto

                        using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(cmdPermisos))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            if (dt.Rows.Count == 0)
                            {
                                MessageBox.Show("No se encontraron permisos aprobados o rechazados.");
                            }
                            else
                            {
                                // Código para generar PDF utilizando iTextSharp
                                Document doc = new Document();
                                string path = @"C:\Users\Public\reporte_permisos.pdf";
                                PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
                                doc.Open();

                                // Añadir encabezado
                                doc.Add(new Paragraph("REPORTE DE PERMISOS"));
                                doc.Add(new Paragraph($"Fecha de Generación: {DateTime.Now.ToString("dd/MM/yyyy")}"));
                                doc.Add(new Paragraph(" "));

                                // Crear tabla
                                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                                pdfTable.WidthPercentage = 100;

                                // Añadir encabezados de columna
                                foreach (DataColumn column in dt.Columns)
                                {
                                    PdfPCell cell = new PdfPCell(new Phrase(column.ColumnName));
                                    cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                                    pdfTable.AddCell(cell);
                                }

                                // Añadir datos de la tabla
                                foreach (DataRow row in dt.Rows)
                                {
                                    foreach (var cellValue in row.ItemArray)
                                    {
                                        pdfTable.AddCell(cellValue.ToString());
                                    }
                                }

                                doc.Add(pdfTable);
                                doc.Close();

                                MessageBox.Show($"PDF generado con éxito en: {path}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al generar el PDF: " + ex.Message);
                }
            }
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }

        private void btnENCARGADO_Click(object sender, EventArgs e)
        {

        }
    }
}
