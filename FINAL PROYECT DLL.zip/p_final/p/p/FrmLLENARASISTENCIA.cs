﻿    using Npgsql;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using iTextSharp.text;
    using iTextSharp.text.pdf;
    using PdfParagraph = iTextSharp.text.Paragraph;
    using System.IO;
    using Npgsql.Internal;
    using System.Windows.Documents;
    using System.Xml.Linq;

namespace p
{
    public partial class FrmLLENARASISTENCIA : Form
    {
        private string codEstudiante;
        private int codCarr;  // Variables a nivel de clase para carrera y semestre
        private int codSem;
        private Arbol_ASISTENCIA arbolAsistencia = new Arbol_ASISTENCIA();
        private string codEst;
        public FrmLLENARASISTENCIA(string codEst)
        {
            InitializeComponent();
            this.codEstudiante = codEst;


            dgvLlenadoAsis.CellClick += dgvLlenadoAsis_CellClick;
            dtfecha.ValueChanged += Dtfecha_ValueChanged;
            dtfecha.Value = DateTime.Now;

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
          
            FrmENCARGADO opcion = new FrmENCARGADO(codEstudiante);
            opcion.Show();
            this.Hide(); 
        }

        private void dgvLlenadoAsis_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FrmLLENARASISTENCIA_Load(object sender, EventArgs e)
        {
            dgvLlenadoAsis.AllowUserToAddRows = false;
            dgvLlenadoAsis.RowHeadersVisible = false;

            dgvLlenadoAsis.AllowUserToAddRows = false;
            dgvLlenadoAsis.ReadOnly = false; // Habilitar edición para las celdas con checkbox

            // Limpiar columnas anteriores si existen
            dgvLlenadoAsis.Columns.Clear();

            // Añadir las columnas para mostrar información del estudiante
            DataGridViewTextBoxColumn colCodigo = new DataGridViewTextBoxColumn();
            colCodigo.Name = "Codigo";
            colCodigo.HeaderText = "CODIGO";
            colCodigo.ReadOnly = true;

            DataGridViewTextBoxColumn colApellidoPaterno = new DataGridViewTextBoxColumn();
            colApellidoPaterno.Name = "ApellidoPaterno";
            colApellidoPaterno.HeaderText = "APELLIDO PATERNO";
            colApellidoPaterno.ReadOnly = true;

            DataGridViewTextBoxColumn colApellidoMaterno = new DataGridViewTextBoxColumn();
            colApellidoMaterno.Name = "ApellidoMaterno";
            colApellidoMaterno.HeaderText = "APELLIDO MATERNO";
            colApellidoMaterno.ReadOnly = true;

            DataGridViewTextBoxColumn colNombreCompleto = new DataGridViewTextBoxColumn();
            colNombreCompleto.Name = "NombreCompleto";
            colNombreCompleto.HeaderText = "NOMBRE COMPLETO";
            colNombreCompleto.ReadOnly = true;

            // Añadir columnas al DataGridView
            dgvLlenadoAsis.Columns.AddRange(new DataGridViewColumn[] { colCodigo, colApellidoPaterno, colApellidoMaterno, colNombreCompleto });

            // Añadir columnas de checkboxes para marcar la asistencia
            DataGridViewCheckBoxColumn chkPresente = new DataGridViewCheckBoxColumn();
            chkPresente.Name = "Presente";
            chkPresente.HeaderText = "PRESENTE";

            DataGridViewCheckBoxColumn chkFalta = new DataGridViewCheckBoxColumn();
            chkFalta.Name = "Falta";
            chkFalta.HeaderText = "FALTA";

            DataGridViewCheckBoxColumn chkGuardia = new DataGridViewCheckBoxColumn();
            chkGuardia.Name = "Guardia";
            chkGuardia.HeaderText = "GUARDIA";

            DataGridViewCheckBoxColumn chkPermiso = new DataGridViewCheckBoxColumn();
            chkPermiso.Name = "Permiso";
            chkPermiso.HeaderText = "PERMISO";

            // Agregar las columnas de checkboxes al DataGridView
            dgvLlenadoAsis.Columns.Add(chkPresente);
            dgvLlenadoAsis.Columns.Add(chkFalta);
            dgvLlenadoAsis.Columns.Add(chkGuardia);
            dgvLlenadoAsis.Columns.Add(chkPermiso);

            // Llamar a los métodos para cargar los datos
            CargarDatosEstudiante();
            CargarEstudiantes();

            // Establecer la fecha actual y cargar asignaturas automáticamente
            dtfecha.Value = DateTime.Now;
            Dtfecha_ValueChanged(null, null); // Llamar al evento para cargar las asignaturas del día actual
            cmbasig.SelectedIndexChanged += cmbasig_SelectedIndexChanged;


        }
        private void Dtfecha_ValueChanged(object sender, EventArgs e)
        {
            DateTime fechaSeleccionada = dtfecha.Value;
            string diaSemana = fechaSeleccionada.ToString("dddd", new System.Globalization.CultureInfo("es-ES")).ToLower();

            // Convertir el día a un valor entre 1 y 5 (asumiendo que lunes=1, martes=2, etc.)
            int idDia = ObtenerIdDiaSemana(diaSemana);

            // Cargar las asignaturas correspondientes a ese día
            CargarAsignaturasPorDia(idDia);

        }
        private void ActualizarTabla()
        {
            DateTime fechaSeleccionada = dtfecha.Value;
            string asignaturaSeleccionada = cmbasig.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(asignaturaSeleccionada))
            {
                MessageBox.Show("Por favor, seleccione una asignatura antes de continuar.", "Información");
                return;
            }

            int codigoAsignatura = ObtenerCodigoAsignatura(asignaturaSeleccionada);

            if (codigoAsignatura == -1)
            {
                return; // No continuar si no se encontró el código de asignatura
            }

   
        
            ActualizarPermisosEstudiantes(fechaSeleccionada, codigoAsignatura);
        }



        private int ObtenerCodigoAsignatura(string asignatura)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT cod_asig FROM asignatura WHERE nom_asig = @asignatura";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@asignatura", asignatura);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return Convert.ToInt32(reader["cod_asig"]); // Convertir el valor a entero
                            }
                            else
                            {
                                MessageBox.Show("No se encontró el código de la asignatura seleccionada.", "Error");
                                return -1; // Devolver un valor inválido para identificar que no se encontró
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error en ObtenerCodigoAsignatura");
                    return -1;
                }
            }
        }


        private int ObtenerIdDiaSemana(string diaSemana)
        {
            switch (diaSemana)
            {
                case "lunes": return 1;
                case "martes": return 2;
                case "miércoles": return 3;
                case "jueves": return 4;
                case "viernes": return 5;
                default: return 0; // Para los fines de semana o días no válidos
            }
        }
        private void dgvLlenadoAsis_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvLlenadoAsis.Columns[e.ColumnIndex] is DataGridViewCheckBoxColumn)
            {
                // Desmarcar otros checkboxes en la misma fila
                foreach (DataGridViewCell cell in dgvLlenadoAsis.Rows[e.RowIndex].Cells)
                {
                    if (cell is DataGridViewCheckBoxCell && cell.ColumnIndex != e.ColumnIndex)
                    {
                        ((DataGridViewCheckBoxCell)cell).Value = false;
                    }
                }
            }
        }

        private void CargarEstudiantes()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                SELECT e.cod_est, e.apat_est, e.amat_est, e.nombre_est
                FROM estudiante e
                WHERE e.cod_carr = @codCarr AND e.cod_sem = @codSem";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@codCarr", codCarr);
                        cmd.Parameters.AddWithValue("@codSem", codSem);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int rowIndex = dgvLlenadoAsis.Rows.Add(
                                    reader["cod_est"].ToString(),
                                    reader["apat_est"].ToString(),
                                    reader["amat_est"].ToString(),
                                    reader["nombre_est"].ToString()
                                );

                                // Verificar si el estudiante tiene permisos
                                string codigoEstudiante = reader["cod_est"].ToString();
                                VerificarPermisoEstudiante(codigoEstudiante, rowIndex);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error al cargar estudiantes");
                }
            }
        }
        private void VerificarPermisoEstudiante(string codigoEstudiante, int rowIndex)
        {
            if (cmbasig.SelectedItem == null)
            {
                return; // Si no hay ninguna asignatura seleccionada, no continuar con la verificación
            }

            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = @"
SELECT cod_est, cod_asig
FROM permiso
WHERE TRIM(cod_est) = TRIM(@codigoEstudiante)
AND fecha_permitida = @fechaSeleccionada
AND (cod_asig = @codigoAsignatura OR cod_asig IS NULL)
AND estado_per = 'Aprobado'";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        DateTime fechaSeleccionada = dtfecha.Value.Date; // Asegurarnos de que estamos comparando solo la fecha sin hora
                        int codigoAsignatura = ObtenerCodigoAsignatura(cmbasig.SelectedItem.ToString());

                        cmd.Parameters.AddWithValue("@codigoEstudiante", codigoEstudiante);
                        cmd.Parameters.AddWithValue("@fechaSeleccionada", fechaSeleccionada);
                        cmd.Parameters.AddWithValue("@codigoAsignatura", codigoAsignatura);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            bool permisoAsignatura = false; // Verifica si es un permiso específico para la asignatura
                            bool permisoGeneral = false; // Verifica si es un permiso general

                            while (reader.Read())
                            {
                                if (reader["cod_asig"] == DBNull.Value)
                                {
                                    permisoGeneral = true;
                                }
                                else
                                {
                                    permisoAsignatura = true;
                                }
                            }

                            // Bloquear fila si tiene permiso general o para la asignatura seleccionada
                            if (permisoGeneral || permisoAsignatura)
                            {
                                dgvLlenadoAsis.Rows[rowIndex].ReadOnly = true;
                                dgvLlenadoAsis.Rows[rowIndex].Cells["Permiso"].Value = true;
                                dgvLlenadoAsis.Rows[rowIndex].Cells["Permiso"].Style.BackColor = Color.Yellow; // Resaltar la celda "Permiso"
                                dgvLlenadoAsis.Rows[rowIndex].DefaultCellStyle.BackColor = Color.LightGray; // Resaltar la fila
                                dgvLlenadoAsis.Rows[rowIndex].DefaultCellStyle.SelectionBackColor = Color.LightGray; // Evitar que se resalte al seleccionar
                                dgvLlenadoAsis.Rows[rowIndex].DefaultCellStyle.SelectionForeColor = dgvLlenadoAsis.Rows[rowIndex].DefaultCellStyle.ForeColor;

                                // Eliminar checkbox de las celdas excepto "Permiso" para estudiantes con permiso
                                foreach (DataGridViewCell cell in dgvLlenadoAsis.Rows[rowIndex].Cells)
                                {
                                    if (cell.OwningColumn.Name != "Permiso")
                                    {
                                        cell.ReadOnly = true;
                                        cell.Style = dgvLlenadoAsis.Rows[rowIndex].DefaultCellStyle;
                                    }
                                }
                            }
                            else
                            {
                                // Permitir checkbox solo en las celdas de Presente, Falta, Guardia para los estudiantes sin permiso
                                foreach (DataGridViewCell cell in dgvLlenadoAsis.Rows[rowIndex].Cells)
                                {
                                    if (cell.OwningColumn.Name == "Permiso")
                                    {
                                        cell.Value = false;
                                        cell.ReadOnly = true;
                                        cell.Style.BackColor = Color.LightGray;
                                    }
                                    else if (cell.OwningColumn.Name == "Presente" || cell.OwningColumn.Name == "Falta" || cell.OwningColumn.Name == "Guardia")
                                    {
                                        cell.ReadOnly = false;
                                    }
                                    else
                                    {
                                        cell.ReadOnly = true;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error en VerificarPermisoEstudiante");
                }
            }
        }



        private void ActualizarPermisosEstudiantes(DateTime fechaSeleccionada, int codigoAsignatura)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            int permisosAprobados = 0;

            foreach (DataGridViewRow row in dgvLlenadoAsis.Rows)
            {
                if (row.IsNewRow) continue; // Evitar la fila nueva

                string codigoEstudiante = row.Cells["Codigo"].Value.ToString();

                using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();
                        string query = @"
                    SELECT cod_est 
                    FROM permiso 
                    WHERE cod_est = @codigoEstudiante 
                    AND fecha_permitida = @fechaSeleccionada 
                    AND cod_asig = @codigoAsignatura 
                    AND estado_per = 'Aprobado'";

                        using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@codigoEstudiante", codigoEstudiante);
                            cmd.Parameters.AddWithValue("@fechaSeleccionada", fechaSeleccionada);
                            cmd.Parameters.AddWithValue("@codigoAsignatura", codigoAsignatura);

                            using (NpgsqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.HasRows)
                                {
                                    row.Cells["Permiso"].Value = true;
                                    row.Cells["Permiso"].ReadOnly = true; // Marcar como no editable
                                    row.DefaultCellStyle.BackColor = Color.Yellow; // Resaltar la fila
                                    permisosAprobados++;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}", "Error en ActualizarPermisosEstudiantes");
                    }
                }
            }

        }

        private void GuardarAsistencia(string codigoEstudiante, string estado)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                INSERT INTO asistencia (cod_est, cod_asig, fecha_asist, estado_asist)
                VALUES (@codEst, @codAsig, @fechaAsist, @estadoAsist)";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@codEst", codigoEstudiante);
                        cmd.Parameters.AddWithValue("@codAsig", ObtenerCodigoAsignatura(cmbasig.SelectedItem.ToString()));
                        cmd.Parameters.AddWithValue("@fechaAsist", dtfecha.Value.Date);
                        cmd.Parameters.AddWithValue("@estadoAsist", estado);

                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error al guardar la asistencia");
                }
            }
        }

        private void VerificarAsistenciaCompletada()
        {
            bool asistenciaCompletada = true;

            foreach (DataGridViewRow row in dgvLlenadoAsis.Rows)
            {
                bool tieneEstado = false;

                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell is DataGridViewButtonCell && cell.ReadOnly)
                    {
                        tieneEstado = true;
                        break;
                    }
                }

                if (!tieneEstado)
                {
                    asistenciaCompletada = false;
                    break;
                }
            }

            if (asistenciaCompletada)
            {

            }
        }
        private void CargarDatosEstudiante()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT e.cod_carr, e.cod_sem, c.descrip_carr, s.descrip_sem
                        FROM estudiante e
                        JOIN carrera c ON e.cod_carr = c.cod_carr
                        JOIN semestre s ON e.cod_sem = s.cod_sem
                        WHERE e.cod_est = @codEst";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@codEst", codEstudiante);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows && reader.Read())
                            {
                                lblcarrera.Text = reader["descrip_carr"].ToString();
                                lblCurso.Text = reader["descrip_sem"].ToString();

                                // Asignar los valores a las variables a nivel de clase
                                codCarr = Convert.ToInt32(reader["cod_carr"]);
                                codSem = Convert.ToInt32(reader["cod_sem"]);
                            }
                            else
                            {
                                MessageBox.Show("No se encontraron registros para el código de estudiante proporcionado.", "Información");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error en CargarDatosEstudiante");
                }
            }
        }
        private void GenerarReportePDFYMostrar()
        {
            string fileName = $"Reporte_Asistencia_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.pdf";

            using (FileStream stream = new FileStream(fileName, FileMode.Create))
            {
                Document doc = new Document(PageSize.A4);
                PdfWriter.GetInstance(doc, stream);
                doc.Open();
                try
                {
                    iTextSharp.text.Image logoIzquierda = iTextSharp.text.Image.GetInstance(@"C:\Users\carlo\Downloads\EMI.png");
                    logoIzquierda.ScaleAbsolute(100f, 50f);
                    logoIzquierda.SetAbsolutePosition(20f, PageSize.A4.Height - 60f); // Posicionar en la parte superior izquierda
                    doc.Add(logoIzquierda);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"No se pudo cargar el logo izquierdo: {ex.Message}", "Error al cargar imagen");
                }

                // Añadir el logo superior derecho
                try
                {
                    iTextSharp.text.Image logoDerecha = iTextSharp.text.Image.GetInstance(@"C:\Users\carlo\Downloads\EMI.png");
                    logoDerecha.ScaleAbsolute(100f, 50f);
                    logoDerecha.SetAbsolutePosition(PageSize.A4.Width - 120f, PageSize.A4.Height - 60f); // Posicionar en la parte superior derecha
                    doc.Add(logoDerecha);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"No se pudo cargar el logo derecho: {ex.Message}", "Error al cargar imagen");
                }
                // Añadir encabezado
                doc.Add(new iTextSharp.text.Paragraph(lblcarrera.Text, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 18, iTextSharp.text.Font.BOLD)) { Alignment = Element.ALIGN_CENTER });
                doc.Add(new iTextSharp.text.Paragraph($"{lblCurso.Text} SEMESTRE", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 14)) { Alignment = Element.ALIGN_CENTER });
                doc.Add(new iTextSharp.text.Paragraph($"Asignatura: {cmbasig.Text} (Código de asignatura: {ObtenerCodigoAsignatura(cmbasig.Text)})", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12)) { Alignment = Element.ALIGN_LEFT });
                doc.Add(new iTextSharp.text.Paragraph($"Docente: {lblDocen.Text}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12)) { Alignment = Element.ALIGN_LEFT });
                doc.Add(new iTextSharp.text.Paragraph($"Fecha: {dtfecha.Value.ToString("dd/MM/yyyy")}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12)) { Alignment = Element.ALIGN_LEFT });
                doc.Add(new iTextSharp.text.Paragraph(" ")); // Espacio en blanco

                // Crear la tabla con las columnas necesarias
                PdfPTable pdfTable = new PdfPTable(3);
                pdfTable.WidthPercentage = 100;
                pdfTable.SetWidths(new float[] { 20f, 40f, 40f });

                // Añadir encabezados de la tabla
                pdfTable.AddCell(new PdfPCell(new Phrase("Código Estudiante", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD))) { BackgroundColor = BaseColor.LIGHT_GRAY });
                pdfTable.AddCell(new PdfPCell(new Phrase("Nombre Completo", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD))) { BackgroundColor = BaseColor.LIGHT_GRAY });
                pdfTable.AddCell(new PdfPCell(new Phrase("Estado de Asistencia", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD))) { BackgroundColor = BaseColor.LIGHT_GRAY });

                // Añadir filas de la tabla con datos de estudiantes
                foreach (DataGridViewRow row in dgvLlenadoAsis.Rows)
                {
                    if (row.IsNewRow) continue;

                    string codigoEstudiante = row.Cells["Codigo"].Value?.ToString() ?? string.Empty;
                    string nombreCompleto = $"{row.Cells["ApellidoPaterno"].Value} {row.Cells["ApellidoMaterno"].Value} {row.Cells["NombreCompleto"].Value}";
                    string estadoAsistencia = "";

                    if (Convert.ToBoolean(row.Cells["Presente"].Value) == true)
                    {
                        estadoAsistencia = "Presente";
                    }
                    else if (Convert.ToBoolean(row.Cells["Falta"].Value) == true)
                    {
                        estadoAsistencia = "Falta";
                    }
                    else if (Convert.ToBoolean(row.Cells["Guardia"].Value) == true)
                    {
                        estadoAsistencia = "Guardia";
                    }
                    else if (Convert.ToBoolean(row.Cells["Permiso"].Value) == true)
                    {
                        estadoAsistencia = "Permiso";
                    }

                    pdfTable.AddCell(new PdfPCell(new Phrase(codigoEstudiante)));
                    pdfTable.AddCell(new PdfPCell(new Phrase(nombreCompleto)));
                    pdfTable.AddCell(new PdfPCell(new Phrase(estadoAsistencia)));
                }

                // Añadir la tabla al documento
                doc.Add(pdfTable);
                doc.Close();
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(fileName) { UseShellExecute = true });
            }
        }
        private void CargarAsignaturasPorDia(string dia)
        {
            cmbasig.Items.Clear();

            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT a.nom_asig, d.nom_doc
                        FROM asignatura a
                        JOIN docente d ON a.cod_doc = d.cod_doc
                        JOIN asignatura_horario_dia ahd ON a.cod_asig = ahd.asignatura_id
                        JOIN dias di ON ahd.dia_id = di.id
                        WHERE di.nombre_dia = @dia AND a.cod_carr = @codCarr AND a.cod_sem = @codSem";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@dia", dia);
                        cmd.Parameters.AddWithValue("@codCarr", codCarr);
                        cmd.Parameters.AddWithValue("@codSem", codSem);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cmbasig.Items.Add(reader["nom_asig"].ToString());
                                lblDocen.Text = reader["nom_doc"].ToString();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error en CargarAsignaturasPorDia");
                }
            }
        }



        private void label3_Click(object sender, EventArgs e)
        {

        }




        private void CargarAsignaturasPorDia(int idDia)
        {
            cmbasig.Items.Clear(); // Limpiar ComboBox antes de agregar nuevas asignaturas

            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
            SELECT a.nom_asig, d.nom_doc
            FROM asignatura a
            JOIN docente d ON a.cod_doc = d.cod_doc
            JOIN asignatura_horario_dia ahd ON a.cod_asig = ahd.asignatura_id
            JOIN dias di ON ahd.dia_id = di.id
            WHERE di.id = @idDia AND a.cod_carr = @codCarr AND a.cod_sem = @codSem";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@idDia", idDia);
                        cmd.Parameters.AddWithValue("@codCarr", codCarr);
                        cmd.Parameters.AddWithValue("@codSem", codSem);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Añadir solo los nombres de las asignaturas al ComboBox
                                cmbasig.Items.Add(reader["nom_asig"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error en CargarAsignaturasPorDia");
                }
            }
        }

        private bool ExisteRegistroAsistencia(string codigoEstudiante, DateTime fechaAsistencia, int codigoAsignatura)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT COUNT(*) FROM asistencia WHERE cod_est = @codEst AND fecha_asist = @fechaAsist AND cod_asig = @codAsig";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@codEst", codigoEstudiante);
                        cmd.Parameters.AddWithValue("@fechaAsist", fechaAsistencia);
                        cmd.Parameters.AddWithValue("@codAsig", codigoAsignatura);

                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count > 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error al verificar la existencia del registro de asistencia");
                    return true; // Asumir que existe un registro para prevenir duplicados en caso de error
                }
            }
        }

        private void CargarAsistenciaExistente(DateTime fecha, int codigoAsignatura)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                SELECT asistencia.cod_est, estudiante.apat_est, estudiante.amat_est, estudiante.nombre_est, asistencia.estado_asist
                FROM asistencia
                JOIN estudiante ON asistencia.cod_est = estudiante.cod_est
                WHERE asistencia.fecha_asist = @fechaAsist AND asistencia.cod_asig = @codAsig";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@fechaAsist", fecha);
                        cmd.Parameters.AddWithValue("@codAsig", codigoAsignatura);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int rowIndex = dgvLlenadoAsis.Rows.Add(
                                    reader["cod_est"].ToString(),
                                    reader["apat_est"].ToString(),
                                    reader["amat_est"].ToString(),
                                    reader["nombre_est"].ToString()
                                );

                                // Marcar el estado de asistencia basado en la base de datos
                                string estadoAsistencia = reader["estado_asist"].ToString();

                                switch (estadoAsistencia)
                                {
                                    case "Presente":
                                        dgvLlenadoAsis.Rows[rowIndex].Cells["Presente"].Value = true;
                                        break;
                                    case "Falta":
                                        dgvLlenadoAsis.Rows[rowIndex].Cells["Falta"].Value = true;
                                        break;
                                    case "Guardia":
                                        dgvLlenadoAsis.Rows[rowIndex].Cells["Guardia"].Value = true;
                                        break;
                                    case "Permiso":
                                        dgvLlenadoAsis.Rows[rowIndex].Cells["Permiso"].Value = true;
                                        break;
                                }

                                // Hacer la fila de solo lectura
                                dgvLlenadoAsis.Rows[rowIndex].ReadOnly = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error al cargar la asistencia existente");
                }
            }
        }
        private void cmbasig_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbasig.SelectedItem != null)
            {
                dgvLlenadoAsis.Rows.Clear();
                string asignaturaSeleccionada = cmbasig.SelectedItem.ToString();
                CargarDocente(asignaturaSeleccionada);

                // Verificar si ya existe asistencia registrada para la materia y la fecha seleccionadas
                if (ExisteRegistroAsistenciaPorFechaAsignatura(dtfecha.Value.Date, ObtenerCodigoAsignatura(cmbasig.SelectedItem.ToString())))
                {
                    // Si existe, cargar la asistencia existente
                    CargarAsistenciaExistente(dtfecha.Value.Date, ObtenerCodigoAsignatura(asignaturaSeleccionada));
                    btnGuardar.Enabled = false;
                    btnGenerarPDF.Enabled = true;
                    dgvLlenadoAsis.ReadOnly = true;
                }
                else
                {
                    // Si no existe asistencia previa, actualizar la tabla con los estudiantes
                    ActualizarTabla();
                    CargarEstudiantes();
                    btnGuardar.Enabled = true;
                    btnGenerarPDF.Enabled = false;
                    dgvLlenadoAsis.ReadOnly = false;
                }
            }
            else
            {
                lblDocen.Text = string.Empty;
            }

        }

       

        private void btnMostrarAsistencias_Click(object sender, EventArgs e)
        {
            dgvLlenadoAsis.Rows.Clear();  // Limpiar las filas previas del DataGridView
                                          // Llenar el DataGridView desde el árbol
        }

        private void CargarDocente(string asignatura)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                SELECT d.nom_doc, d.apat_doc, d.amat_doc
                FROM asignatura a
                JOIN docente d ON a.cod_doc = d.cod_doc
                WHERE a.nom_asig = @asignatura";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@asignatura", asignatura);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                lblDocen.Text = $"{reader["nom_doc"]} {reader["apat_doc"]} {reader["amat_doc"]}";
                            }
                            else
                            {
                                lblDocen.Text = "No encontrado";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error en CargarDocente");
                }
            }
        }


        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // Verificar si todas las filas tienen un estado seleccionado
            foreach (DataGridViewRow row in dgvLlenadoAsis.Rows)
            {
                if (row.IsNewRow) continue; // Saltar la fila nueva

                // Verificar si la fila tiene un código de estudiante
                string codigoEstudiante = row.Cells["Codigo"].Value?.ToString();
                if (string.IsNullOrEmpty(codigoEstudiante))
                {
                    MessageBox.Show("Hay filas sin código de estudiante. Verifique los datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Verificar si se seleccionó un estado de asistencia
                bool presente = Convert.ToBoolean(row.Cells["Presente"].Value) == true;
                bool falta = Convert.ToBoolean(row.Cells["Falta"].Value) == true;
                bool guardia = Convert.ToBoolean(row.Cells["Guardia"].Value) == true;
                bool permiso = Convert.ToBoolean(row.Cells["Permiso"].Value) == true;

                if (!presente && !falta && !guardia && !permiso)
                {
                    MessageBox.Show($"La asistencia para el estudiante con código {codigoEstudiante} no está completamente marcada.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Detener el proceso si alguna fila no está completa
                }
            }

            // Si pasa la validación, proceder a guardar
            try
            {
                foreach (DataGridViewRow row in dgvLlenadoAsis.Rows)
                {
                    if (row.IsNewRow) continue; // Saltar la fila nueva

                    // Obtener el código del estudiante y el estado de asistencia
                    string codigoEstudiante = row.Cells["Codigo"].Value.ToString();
                    string estadoAsistencia = string.Empty;

                    if (Convert.ToBoolean(row.Cells["Presente"].Value) == true)
                    {
                        estadoAsistencia = "Presente";
                    }
                    else if (Convert.ToBoolean(row.Cells["Falta"].Value) == true)
                    {
                        estadoAsistencia = "Falta";
                    }
                    else if (Convert.ToBoolean(row.Cells["Guardia"].Value) == true)
                    {
                        estadoAsistencia = "Guardia";
                    }
                    else if (Convert.ToBoolean(row.Cells["Permiso"].Value) == true)
                    {
                        estadoAsistencia = "Permiso";
                    }

                    // Guardar la asistencia en la base de datos
                    GuardarAsistencia(codigoEstudiante, estadoAsistencia);
                }

                MessageBox.Show("Asistencia guardada exitosamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GenerarReportePDFYMostrar();
                btnGuardar.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar la asistencia: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private bool ExisteRegistroAsistenciaPorFechaAsignatura(DateTime fechaAsistencia, int codigoAsignatura)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=ASISTENCIA";
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT COUNT(*) FROM asistencia WHERE fecha_asist = @fechaAsist AND cod_asig = @codAsig";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@fechaAsist", fechaAsistencia);
                        cmd.Parameters.AddWithValue("@codAsig", codigoAsignatura);

                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count > 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error al verificar la existencia del registro de asistencia por fecha y asignatura");
                    return false; // Asumir que no existe un registro en caso de error
                }
            }
        }

        private void GenerarReportePDFYMostrarDesdeBD()
        {
            string fileName = $"Reporte_Asistencia_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.pdf";

            using (FileStream stream = new FileStream(fileName, FileMode.Create))
            {
                Document doc = new Document(PageSize.A4);
                PdfWriter.GetInstance(doc, stream);
                doc.Open();
                try
                {
                    iTextSharp.text.Image logoIzquierda = iTextSharp.text.Image.GetInstance(@"C:\Users\carlo\Downloads\EMI.png");
                    logoIzquierda.ScaleAbsolute(100f, 50f);
                    logoIzquierda.SetAbsolutePosition(20f, PageSize.A4.Height - 60f); // Posicionar en la parte superior izquierda
                    doc.Add(logoIzquierda);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"No se pudo cargar el logo izquierdo: {ex.Message}", "Error al cargar imagen");
                }

                // Añadir el logo superior derecho
                try
                {
                    iTextSharp.text.Image logoDerecha = iTextSharp.text.Image.GetInstance(@"C:\Users\carlo\Downloads\EMI.png");
                    logoDerecha.ScaleAbsolute(100f, 50f);
                    logoDerecha.SetAbsolutePosition(PageSize.A4.Width - 120f, PageSize.A4.Height - 60f); // Posicionar en la parte superior derecha
                    doc.Add(logoDerecha);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"No se pudo cargar el logo derecho: {ex.Message}", "Error al cargar imagen");
                }
                // Añadir encabezado
                doc.Add(new iTextSharp.text.Paragraph(lblcarrera.Text, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 18, iTextSharp.text.Font.BOLD)) { Alignment = Element.ALIGN_CENTER });
                doc.Add(new iTextSharp.text.Paragraph($"{lblCurso.Text} SEMESTRE", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 14)) { Alignment = Element.ALIGN_CENTER });
                doc.Add(new iTextSharp.text.Paragraph($"Asignatura: {cmbasig.Text} (Código de asignatura: {ObtenerCodigoAsignatura(cmbasig.Text)})", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12)) { Alignment = Element.ALIGN_LEFT });
                doc.Add(new iTextSharp.text.Paragraph($"Docente: {lblDocen.Text}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12)) { Alignment = Element.ALIGN_LEFT });
                doc.Add(new iTextSharp.text.Paragraph($"Fecha: {dtfecha.Value.ToString("dd/MM/yyyy")}", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12)) { Alignment = Element.ALIGN_LEFT });
                doc.Add(new iTextSharp.text.Paragraph(" ")); // Espacio en blanco

                // Crear la tabla con las columnas necesarias
                PdfPTable pdfTable = new PdfPTable(3);
                pdfTable.WidthPercentage = 100;
                pdfTable.SetWidths(new float[] { 20f, 40f, 40f });

                // Añadir encabezados de la tabla
                pdfTable.AddCell(new PdfPCell(new Phrase("Código Estudiante", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD))) { BackgroundColor = BaseColor.LIGHT_GRAY });
                pdfTable.AddCell(new PdfPCell(new Phrase("Nombre Completo", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD))) { BackgroundColor = BaseColor.LIGHT_GRAY });
                pdfTable.AddCell(new PdfPCell(new Phrase("Estado de Asistencia", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD))) { BackgroundColor = BaseColor.LIGHT_GRAY });

                // Añadir filas de la tabla con datos de estudiantes desde la base de datos
                string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=123456;Database=posss";
                using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();
                        string query = @"SELECT asistencia.cod_est, CONCAT(apat_est, ' ', amat_est, ' ', nombre_est) AS nombre_completo, estado_asist FROM asistencia JOIN estudiante ON asistencia.cod_est = estudiante.cod_est WHERE fecha_asist = @fechaAsist AND cod_asig = @codAsig";

                        using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@fechaAsist", dtfecha.Value.Date);
                            cmd.Parameters.AddWithValue("@codAsig", ObtenerCodigoAsignatura(cmbasig.Text));

                            using (NpgsqlDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    pdfTable.AddCell(new PdfPCell(new Phrase(reader["cod_est"].ToString())));
                                    pdfTable.AddCell(new PdfPCell(new Phrase(reader["nombre_completo"].ToString())));
                                    pdfTable.AddCell(new PdfPCell(new Phrase(reader["estado_asist"].ToString())));
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}", "Error al generar el reporte PDF desde la base de datos");
                    }
                }

                // Añadir la tabla al documento
                doc.Add(pdfTable);
                doc.Close();
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(fileName) { UseShellExecute = true });
            }
        }

        private void btnGenerarPDF_Click(object sender, EventArgs e)
        {
            if (cmbasig.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una asignatura antes de continuar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!ExisteRegistroAsistenciaPorFechaAsignatura(dtfecha.Value.Date, ObtenerCodigoAsignatura(cmbasig.SelectedItem.ToString())))
            {
                MessageBox.Show("No existe un registro de asistencia para la asignatura seleccionada en la fecha indicada.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            GenerarReportePDFYMostrarDesdeBD();
        }
    }


}