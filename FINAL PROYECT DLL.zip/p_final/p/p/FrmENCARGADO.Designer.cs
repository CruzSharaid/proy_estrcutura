﻿namespace p
{
    partial class FrmENCARGADO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmENCARGADO));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLlenadoAsis = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.cERRARSESIONToolStripMenuItem = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(139, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "BIENVENIDO ENCARGADO";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnLlenadoAsis
            // 
            this.btnLlenadoAsis.AllowAnimations = true;
            this.btnLlenadoAsis.AllowMouseEffects = true;
            this.btnLlenadoAsis.AllowToggling = false;
            this.btnLlenadoAsis.AnimationSpeed = 200;
            this.btnLlenadoAsis.AutoGenerateColors = false;
            this.btnLlenadoAsis.AutoRoundBorders = false;
            this.btnLlenadoAsis.AutoSizeLeftIcon = true;
            this.btnLlenadoAsis.AutoSizeRightIcon = true;
            this.btnLlenadoAsis.BackColor = System.Drawing.Color.Transparent;
            this.btnLlenadoAsis.BackColor1 = System.Drawing.Color.Blue;
            this.btnLlenadoAsis.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLlenadoAsis.BackgroundImage")));
            this.btnLlenadoAsis.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLlenadoAsis.ButtonText = "ASISTENCIA";
            this.btnLlenadoAsis.ButtonTextMarginLeft = 0;
            this.btnLlenadoAsis.ColorContrastOnClick = 45;
            this.btnLlenadoAsis.ColorContrastOnHover = 45;
            this.btnLlenadoAsis.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.btnLlenadoAsis.CustomizableEdges = borderEdges5;
            this.btnLlenadoAsis.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnLlenadoAsis.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnLlenadoAsis.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnLlenadoAsis.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnLlenadoAsis.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnLlenadoAsis.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnLlenadoAsis.ForeColor = System.Drawing.Color.White;
            this.btnLlenadoAsis.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLlenadoAsis.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnLlenadoAsis.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnLlenadoAsis.IconMarginLeft = 11;
            this.btnLlenadoAsis.IconPadding = 10;
            this.btnLlenadoAsis.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLlenadoAsis.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnLlenadoAsis.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnLlenadoAsis.IconSize = 25;
            this.btnLlenadoAsis.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnLlenadoAsis.IdleBorderRadius = 1;
            this.btnLlenadoAsis.IdleBorderThickness = 1;
            this.btnLlenadoAsis.IdleFillColor = System.Drawing.Color.Blue;
            this.btnLlenadoAsis.IdleIconLeftImage = null;
            this.btnLlenadoAsis.IdleIconRightImage = null;
            this.btnLlenadoAsis.IndicateFocus = false;
            this.btnLlenadoAsis.Location = new System.Drawing.Point(205, 102);
            this.btnLlenadoAsis.Name = "btnLlenadoAsis";
            this.btnLlenadoAsis.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnLlenadoAsis.OnDisabledState.BorderRadius = 1;
            this.btnLlenadoAsis.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLlenadoAsis.OnDisabledState.BorderThickness = 1;
            this.btnLlenadoAsis.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnLlenadoAsis.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnLlenadoAsis.OnDisabledState.IconLeftImage = null;
            this.btnLlenadoAsis.OnDisabledState.IconRightImage = null;
            this.btnLlenadoAsis.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnLlenadoAsis.onHoverState.BorderRadius = 1;
            this.btnLlenadoAsis.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLlenadoAsis.onHoverState.BorderThickness = 1;
            this.btnLlenadoAsis.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnLlenadoAsis.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnLlenadoAsis.onHoverState.IconLeftImage = null;
            this.btnLlenadoAsis.onHoverState.IconRightImage = null;
            this.btnLlenadoAsis.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnLlenadoAsis.OnIdleState.BorderRadius = 1;
            this.btnLlenadoAsis.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLlenadoAsis.OnIdleState.BorderThickness = 1;
            this.btnLlenadoAsis.OnIdleState.FillColor = System.Drawing.Color.Blue;
            this.btnLlenadoAsis.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnLlenadoAsis.OnIdleState.IconLeftImage = null;
            this.btnLlenadoAsis.OnIdleState.IconRightImage = null;
            this.btnLlenadoAsis.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnLlenadoAsis.OnPressedState.BorderRadius = 1;
            this.btnLlenadoAsis.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLlenadoAsis.OnPressedState.BorderThickness = 1;
            this.btnLlenadoAsis.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnLlenadoAsis.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnLlenadoAsis.OnPressedState.IconLeftImage = null;
            this.btnLlenadoAsis.OnPressedState.IconRightImage = null;
            this.btnLlenadoAsis.Size = new System.Drawing.Size(150, 58);
            this.btnLlenadoAsis.TabIndex = 4;
            this.btnLlenadoAsis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLlenadoAsis.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnLlenadoAsis.TextMarginLeft = 0;
            this.btnLlenadoAsis.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnLlenadoAsis.UseDefaultRadiusAndThickness = true;
            this.btnLlenadoAsis.Click += new System.EventHandler(this.btnLlenadoAsis_Click);
            // 
            // cERRARSESIONToolStripMenuItem
            // 
            this.cERRARSESIONToolStripMenuItem.AllowAnimations = true;
            this.cERRARSESIONToolStripMenuItem.AllowMouseEffects = true;
            this.cERRARSESIONToolStripMenuItem.AllowToggling = false;
            this.cERRARSESIONToolStripMenuItem.AnimationSpeed = 200;
            this.cERRARSESIONToolStripMenuItem.AutoGenerateColors = false;
            this.cERRARSESIONToolStripMenuItem.AutoRoundBorders = true;
            this.cERRARSESIONToolStripMenuItem.AutoSizeLeftIcon = true;
            this.cERRARSESIONToolStripMenuItem.AutoSizeRightIcon = true;
            this.cERRARSESIONToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.cERRARSESIONToolStripMenuItem.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.cERRARSESIONToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cERRARSESIONToolStripMenuItem.BackgroundImage")));
            this.cERRARSESIONToolStripMenuItem.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.ButtonText = "CERRAR SESION";
            this.cERRARSESIONToolStripMenuItem.ButtonTextMarginLeft = 0;
            this.cERRARSESIONToolStripMenuItem.ColorContrastOnClick = 45;
            this.cERRARSESIONToolStripMenuItem.ColorContrastOnHover = 45;
            this.cERRARSESIONToolStripMenuItem.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.cERRARSESIONToolStripMenuItem.CustomizableEdges = borderEdges6;
            this.cERRARSESIONToolStripMenuItem.DialogResult = System.Windows.Forms.DialogResult.None;
            this.cERRARSESIONToolStripMenuItem.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.cERRARSESIONToolStripMenuItem.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cERRARSESIONToolStripMenuItem.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.cERRARSESIONToolStripMenuItem.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.cERRARSESIONToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cERRARSESIONToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cERRARSESIONToolStripMenuItem.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.cERRARSESIONToolStripMenuItem.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.cERRARSESIONToolStripMenuItem.IconMarginLeft = 11;
            this.cERRARSESIONToolStripMenuItem.IconPadding = 10;
            this.cERRARSESIONToolStripMenuItem.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cERRARSESIONToolStripMenuItem.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.cERRARSESIONToolStripMenuItem.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.cERRARSESIONToolStripMenuItem.IconSize = 25;
            this.cERRARSESIONToolStripMenuItem.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.cERRARSESIONToolStripMenuItem.IdleBorderRadius = 40;
            this.cERRARSESIONToolStripMenuItem.IdleBorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.cERRARSESIONToolStripMenuItem.IdleIconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.IdleIconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.IndicateFocus = false;
            this.cERRARSESIONToolStripMenuItem.Location = new System.Drawing.Point(424, 210);
            this.cERRARSESIONToolStripMenuItem.Name = "cERRARSESIONToolStripMenuItem";
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.OnDisabledState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.onHoverState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cERRARSESIONToolStripMenuItem.onHoverState.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.onHoverState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.onHoverState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.OnIdleState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderRadius = 1;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.BorderThickness = 1;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.cERRARSESIONToolStripMenuItem.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.IconLeftImage = null;
            this.cERRARSESIONToolStripMenuItem.OnPressedState.IconRightImage = null;
            this.cERRARSESIONToolStripMenuItem.Size = new System.Drawing.Size(150, 42);
            this.cERRARSESIONToolStripMenuItem.TabIndex = 6;
            this.cERRARSESIONToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cERRARSESIONToolStripMenuItem.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.cERRARSESIONToolStripMenuItem.TextMarginLeft = 0;
            this.cERRARSESIONToolStripMenuItem.TextPadding = new System.Windows.Forms.Padding(0);
            this.cERRARSESIONToolStripMenuItem.UseDefaultRadiusAndThickness = true;
            this.cERRARSESIONToolStripMenuItem.Click += new System.EventHandler(this.cERRARSESIONToolStripMenuItem_Click_1);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.btnLlenadoAsis);
            this.bunifuGradientPanel1.Controls.Add(this.cERRARSESIONToolStripMenuItem);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Yellow;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(577, 264);
            this.bunifuGradientPanel1.TabIndex = 7;
            this.bunifuGradientPanel1.Click += new System.EventHandler(this.bunifuGradientPanel1_Click);
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.AutoSizeHeight = true;
            this.bunifuPictureBox1.BorderRadius = 37;
            this.bunifuPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuPictureBox1.Image")));
            this.bunifuPictureBox1.IsCircle = true;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(2, 0);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(75, 75);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 74;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            // 
            // FrmENCARGADO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 264);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmENCARGADO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CONTROL DE ASISTENCIA";
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnLlenadoAsis;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton cERRARSESIONToolStripMenuItem;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
    }
}