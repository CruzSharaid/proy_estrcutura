﻿namespace p
{
    partial class FrmInformePrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInformePrincipal));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblSemestre = new System.Windows.Forms.Label();
            this.lblCarre = new System.Windows.Forms.Label();
            this.lblGestion = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblporcentaje = new System.Windows.Forms.Label();
            this.dgvPermisos = new System.Windows.Forms.DataGridView();
            this.lblCantPermisos = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnVolver = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnPorcentaje = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.cmbAsignaturas = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblpuntostotales = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblpuntosganados = new System.Windows.Forms.Label();
            this.dgvasistencia = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPermisos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvasistencia)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(19, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nombre:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(19, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Semestre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(19, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 23);
            this.label4.TabIndex = 5;
            this.label4.Text = "Carrera:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(19, 244);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 23);
            this.label6.TabIndex = 7;
            this.label6.Text = "Asignaturas";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(273, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 23);
            this.label7.TabIndex = 8;
            this.label7.Text = "Gestion:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Gold;
            this.label8.Font = new System.Drawing.Font("Tahoma", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label8.Location = new System.Drawing.Point(35, 412);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(164, 23);
            this.label8.TabIndex = 9;
            this.label8.Text = "N° de Permisos:";
            // 
            // lblNombre
            // 
            this.lblNombre.BackColor = System.Drawing.Color.White;
            this.lblNombre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNombre.Location = new System.Drawing.Point(133, 90);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(406, 24);
            this.lblNombre.TabIndex = 10;
            // 
            // lblSemestre
            // 
            this.lblSemestre.BackColor = System.Drawing.Color.White;
            this.lblSemestre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSemestre.Location = new System.Drawing.Point(133, 128);
            this.lblSemestre.Name = "lblSemestre";
            this.lblSemestre.Size = new System.Drawing.Size(114, 24);
            this.lblSemestre.TabIndex = 11;
            // 
            // lblCarre
            // 
            this.lblCarre.BackColor = System.Drawing.Color.White;
            this.lblCarre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCarre.Location = new System.Drawing.Point(133, 167);
            this.lblCarre.Name = "lblCarre";
            this.lblCarre.Size = new System.Drawing.Size(406, 24);
            this.lblCarre.TabIndex = 12;
            // 
            // lblGestion
            // 
            this.lblGestion.BackColor = System.Drawing.Color.White;
            this.lblGestion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGestion.Location = new System.Drawing.Point(374, 127);
            this.lblGestion.Name = "lblGestion";
            this.lblGestion.Size = new System.Drawing.Size(165, 24);
            this.lblGestion.TabIndex = 15;
            this.lblGestion.Text = "II - 2024";
            // 
            // lblCorreo
            // 
            this.lblCorreo.BackColor = System.Drawing.Color.White;
            this.lblCorreo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCorreo.Location = new System.Drawing.Point(236, 202);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(303, 24);
            this.lblCorreo.TabIndex = 17;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(19, 203);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(209, 23);
            this.label16.TabIndex = 16;
            this.label16.Text = "Correo Institucional:";
            // 
            // lblporcentaje
            // 
            this.lblporcentaje.BackColor = System.Drawing.Color.White;
            this.lblporcentaje.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblporcentaje.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblporcentaje.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblporcentaje.Location = new System.Drawing.Point(667, 401);
            this.lblporcentaje.Name = "lblporcentaje";
            this.lblporcentaje.Size = new System.Drawing.Size(216, 48);
            this.lblporcentaje.TabIndex = 1;
            this.lblporcentaje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvPermisos
            // 
            this.dgvPermisos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPermisos.Location = new System.Drawing.Point(554, 58);
            this.dgvPermisos.Name = "dgvPermisos";
            this.dgvPermisos.Size = new System.Drawing.Size(640, 108);
            this.dgvPermisos.TabIndex = 21;
            // 
            // lblCantPermisos
            // 
            this.lblCantPermisos.BackColor = System.Drawing.Color.White;
            this.lblCantPermisos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCantPermisos.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantPermisos.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblCantPermisos.Location = new System.Drawing.Point(217, 391);
            this.lblCantPermisos.Name = "lblCantPermisos";
            this.lblCantPermisos.Size = new System.Drawing.Size(72, 58);
            this.lblCantPermisos.TabIndex = 2;
            this.lblCantPermisos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Tahoma", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(550, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(261, 23);
            this.label18.TabIndex = 22;
            this.label18.Text = "PERMISOS SOLICITADOS:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Tahoma", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(19, 44);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(266, 23);
            this.label19.TabIndex = 23;
            this.label19.Text = "INFORMACION PERSONAL";
            // 
            // btnVolver
            // 
            this.btnVolver.AllowAnimations = true;
            this.btnVolver.AllowMouseEffects = true;
            this.btnVolver.AllowToggling = false;
            this.btnVolver.AnimationSpeed = 200;
            this.btnVolver.AutoGenerateColors = false;
            this.btnVolver.AutoRoundBorders = true;
            this.btnVolver.AutoSizeLeftIcon = true;
            this.btnVolver.AutoSizeRightIcon = true;
            this.btnVolver.BackColor = System.Drawing.Color.Transparent;
            this.btnVolver.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnVolver.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVolver.BackgroundImage")));
            this.btnVolver.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.ButtonText = "REGERSAR";
            this.btnVolver.ButtonTextMarginLeft = 0;
            this.btnVolver.ColorContrastOnClick = 45;
            this.btnVolver.ColorContrastOnHover = 45;
            this.btnVolver.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.btnVolver.CustomizableEdges = borderEdges11;
            this.btnVolver.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnVolver.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnVolver.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnVolver.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnVolver.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnVolver.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnVolver.ForeColor = System.Drawing.Color.White;
            this.btnVolver.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolver.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnVolver.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnVolver.IconMarginLeft = 11;
            this.btnVolver.IconPadding = 10;
            this.btnVolver.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVolver.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnVolver.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnVolver.IconSize = 25;
            this.btnVolver.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.IdleBorderRadius = 48;
            this.btnVolver.IdleBorderThickness = 1;
            this.btnVolver.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.IdleIconLeftImage = null;
            this.btnVolver.IdleIconRightImage = null;
            this.btnVolver.IndicateFocus = false;
            this.btnVolver.Location = new System.Drawing.Point(1118, 412);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnVolver.OnDisabledState.BorderRadius = 1;
            this.btnVolver.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.OnDisabledState.BorderThickness = 1;
            this.btnVolver.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnVolver.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnVolver.OnDisabledState.IconLeftImage = null;
            this.btnVolver.OnDisabledState.IconRightImage = null;
            this.btnVolver.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnVolver.onHoverState.BorderRadius = 1;
            this.btnVolver.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.onHoverState.BorderThickness = 1;
            this.btnVolver.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnVolver.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnVolver.onHoverState.IconLeftImage = null;
            this.btnVolver.onHoverState.IconRightImage = null;
            this.btnVolver.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.OnIdleState.BorderRadius = 1;
            this.btnVolver.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.OnIdleState.BorderThickness = 1;
            this.btnVolver.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnVolver.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnVolver.OnIdleState.IconLeftImage = null;
            this.btnVolver.OnIdleState.IconRightImage = null;
            this.btnVolver.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnVolver.OnPressedState.BorderRadius = 1;
            this.btnVolver.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnVolver.OnPressedState.BorderThickness = 1;
            this.btnVolver.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnVolver.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnVolver.OnPressedState.IconLeftImage = null;
            this.btnVolver.OnPressedState.IconRightImage = null;
            this.btnVolver.Size = new System.Drawing.Size(111, 50);
            this.btnVolver.TabIndex = 25;
            this.btnVolver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnVolver.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnVolver.TextMarginLeft = 0;
            this.btnVolver.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnVolver.UseDefaultRadiusAndThickness = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click_1);
            // 
            // btnPorcentaje
            // 
            this.btnPorcentaje.AllowAnimations = true;
            this.btnPorcentaje.AllowMouseEffects = true;
            this.btnPorcentaje.AllowToggling = false;
            this.btnPorcentaje.AnimationSpeed = 200;
            this.btnPorcentaje.AutoGenerateColors = false;
            this.btnPorcentaje.AutoRoundBorders = false;
            this.btnPorcentaje.AutoSizeLeftIcon = true;
            this.btnPorcentaje.AutoSizeRightIcon = true;
            this.btnPorcentaje.BackColor = System.Drawing.Color.Transparent;
            this.btnPorcentaje.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnPorcentaje.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPorcentaje.BackgroundImage")));
            this.btnPorcentaje.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPorcentaje.ButtonText = "CALCULAR PORCENTAJE";
            this.btnPorcentaje.ButtonTextMarginLeft = 0;
            this.btnPorcentaje.ColorContrastOnClick = 45;
            this.btnPorcentaje.ColorContrastOnHover = 45;
            this.btnPorcentaje.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.btnPorcentaje.CustomizableEdges = borderEdges12;
            this.btnPorcentaje.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnPorcentaje.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnPorcentaje.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnPorcentaje.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnPorcentaje.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnPorcentaje.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPorcentaje.ForeColor = System.Drawing.Color.White;
            this.btnPorcentaje.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPorcentaje.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnPorcentaje.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnPorcentaje.IconMarginLeft = 11;
            this.btnPorcentaje.IconPadding = 10;
            this.btnPorcentaje.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPorcentaje.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnPorcentaje.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnPorcentaje.IconSize = 25;
            this.btnPorcentaje.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnPorcentaje.IdleBorderRadius = 1;
            this.btnPorcentaje.IdleBorderThickness = 1;
            this.btnPorcentaje.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnPorcentaje.IdleIconLeftImage = null;
            this.btnPorcentaje.IdleIconRightImage = null;
            this.btnPorcentaje.IndicateFocus = false;
            this.btnPorcentaje.Location = new System.Drawing.Point(39, 293);
            this.btnPorcentaje.Name = "btnPorcentaje";
            this.btnPorcentaje.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnPorcentaje.OnDisabledState.BorderRadius = 1;
            this.btnPorcentaje.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPorcentaje.OnDisabledState.BorderThickness = 1;
            this.btnPorcentaje.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnPorcentaje.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnPorcentaje.OnDisabledState.IconLeftImage = null;
            this.btnPorcentaje.OnDisabledState.IconRightImage = null;
            this.btnPorcentaje.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnPorcentaje.onHoverState.BorderRadius = 1;
            this.btnPorcentaje.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPorcentaje.onHoverState.BorderThickness = 1;
            this.btnPorcentaje.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnPorcentaje.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnPorcentaje.onHoverState.IconLeftImage = null;
            this.btnPorcentaje.onHoverState.IconRightImage = null;
            this.btnPorcentaje.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnPorcentaje.OnIdleState.BorderRadius = 1;
            this.btnPorcentaje.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPorcentaje.OnIdleState.BorderThickness = 1;
            this.btnPorcentaje.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnPorcentaje.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnPorcentaje.OnIdleState.IconLeftImage = null;
            this.btnPorcentaje.OnIdleState.IconRightImage = null;
            this.btnPorcentaje.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnPorcentaje.OnPressedState.BorderRadius = 1;
            this.btnPorcentaje.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnPorcentaje.OnPressedState.BorderThickness = 1;
            this.btnPorcentaje.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnPorcentaje.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnPorcentaje.OnPressedState.IconLeftImage = null;
            this.btnPorcentaje.OnPressedState.IconRightImage = null;
            this.btnPorcentaje.Size = new System.Drawing.Size(173, 29);
            this.btnPorcentaje.TabIndex = 28;
            this.btnPorcentaje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPorcentaje.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnPorcentaje.TextMarginLeft = 0;
            this.btnPorcentaje.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnPorcentaje.UseDefaultRadiusAndThickness = true;
            this.btnPorcentaje.Click += new System.EventHandler(this.btnPorcentaje_Click_1);
            // 
            // cmbAsignaturas
            // 
            this.cmbAsignaturas.FormattingEnabled = true;
            this.cmbAsignaturas.Location = new System.Drawing.Point(148, 246);
            this.cmbAsignaturas.Name = "cmbAsignaturas";
            this.cmbAsignaturas.Size = new System.Drawing.Size(284, 21);
            this.cmbAsignaturas.TabIndex = 29;
            this.cmbAsignaturas.SelectedIndexChanged += new System.EventHandler(this.cmbAsignaturas_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(708, 379);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "PORCENTAJE";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(546, 379);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "PUNTOS TOTALES";
            // 
            // lblpuntostotales
            // 
            this.lblpuntostotales.BackColor = System.Drawing.Color.White;
            this.lblpuntostotales.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblpuntostotales.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpuntostotales.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblpuntostotales.Location = new System.Drawing.Point(567, 401);
            this.lblpuntostotales.Name = "lblpuntostotales";
            this.lblpuntostotales.Size = new System.Drawing.Size(60, 48);
            this.lblpuntostotales.TabIndex = 31;
            this.lblpuntostotales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(404, 379);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "PUNTOS GANADOS";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // lblpuntosganados
            // 
            this.lblpuntosganados.BackColor = System.Drawing.Color.White;
            this.lblpuntosganados.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblpuntosganados.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpuntosganados.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblpuntosganados.Location = new System.Drawing.Point(423, 401);
            this.lblpuntosganados.Name = "lblpuntosganados";
            this.lblpuntosganados.Size = new System.Drawing.Size(89, 48);
            this.lblpuntosganados.TabIndex = 33;
            this.lblpuntosganados.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvasistencia
            // 
            this.dgvasistencia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvasistencia.Location = new System.Drawing.Point(554, 214);
            this.dgvasistencia.Name = "dgvasistencia";
            this.dgvasistencia.ReadOnly = true;
            this.dgvasistencia.Size = new System.Drawing.Size(640, 131);
            this.dgvasistencia.TabIndex = 35;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Tahoma", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(550, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(226, 23);
            this.label9.TabIndex = 36;
            this.label9.Text = "ASISTENCIA MATERIA";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // FrmInformePrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1237, 483);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dgvasistencia);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblpuntosganados);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblpuntostotales);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbAsignaturas);
            this.Controls.Add(this.btnPorcentaje);
            this.Controls.Add(this.lblporcentaje);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lblCantPermisos);
            this.Controls.Add(this.dgvPermisos);
            this.Controls.Add(this.lblCorreo);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lblGestion);
            this.Controls.Add(this.lblCarre);
            this.Controls.Add(this.lblSemestre);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmInformePrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.FrmInformePrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPermisos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvasistencia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblSemestre;
        private System.Windows.Forms.Label lblCarre;
        private System.Windows.Forms.Label lblGestion;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblporcentaje;
        private System.Windows.Forms.DataGridView dgvPermisos;
        private System.Windows.Forms.Label lblCantPermisos;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnVolver;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnPorcentaje;
        private System.Windows.Forms.ComboBox cmbAsignaturas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblpuntostotales;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblpuntosganados;
        private System.Windows.Forms.DataGridView dgvasistencia;
        private System.Windows.Forms.Label label9;
    }
}