﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p
{
    class NodoCola_PERMISO
    {
        string ID_PERMISO;
        DateTime Fech_s_a_per;
        string Motivo_per;
        string Estado_per;
        byte[] Comprb_per;
        string Cod_est;
        string Cod_asig;
        string Id_jefatura;
        NodoCola_PERMISO Enl;

        public NodoCola_PERMISO(string iD_PERMISO, string cod_est, DateTime fech_s_a_per, string motivo_per, string cod_asig, string estado_per, byte[] comprb_per, string id_jefatura, NodoCola_PERMISO enl)
        {
            ID_PERMISO = iD_PERMISO;
            Cod_est = cod_est;
            Fech_s_a_per = fech_s_a_per;
            Motivo_per = motivo_per;
            Cod_asig = cod_asig;
            Estado_per = estado_per;
            Comprb_per = comprb_per;
            Id_jefatura = id_jefatura;
            Enl = enl;
        }

        public string id_per { get => ID_PERMISO; set => ID_PERMISO = value; }
        public string cod_est { get => Cod_est; set => Cod_est = value; }
        public DateTime fech_s_a_per { get => Fech_s_a_per; set => Fech_s_a_per = value; }
        public string motivo_per { get => Motivo_per; set => Motivo_per = value; }
        public string cod_asig { get => Cod_asig; set => Cod_asig = value; }
        public string estado_per { get => Estado_per; set => Estado_per = value; }
        public byte[] comprb_per { get => Comprb_per; set => Comprb_per = value; }
        public string id_jefatura { get => Id_jefatura; set => Id_jefatura = value; }
        internal NodoCola_PERMISO enl { get => Enl; set => Enl = value; }
    }
}